# Clock Widget

Xiaomi-style clock theme (zip, jisme `manifest.xml` + `images/`) ko import karke Android home screen widget banata hai.

## APK kaise banaye (GitHub Actions)
1. Is poore folder ko apni GitHub repo me push karo (branch `main`).
2. Repo ke **Actions** tab me "Build APK" run hoga (ya "Run workflow" dabao).
3. Run khatam hone par neeche **Artifacts** se `ClockWidget-apk` download karo, zip kholo, `app-debug.apk` phone me install karo.

## Use kaise kare
1. App kholo > **Theme import karo** > `clock_3x4` file chuno.
2. **Widget home screen par lagao** (ya home screen long-press > Widgets > Clock Widget).
3. ColorOS: Settings > Battery > Clock Widget > Unrestricted, aur Auto-launch ON.

## Limits
- Sirf ye MAML tags chalte hain: Var, Group, Image, Text, DateTime. Dusre themes ke animations/buttons nahi chalenge.
- Xiaomi weather provider ColorOS me nahi hota, isliye temperature `--°` dikhega.
