# Aurum Clock

Premium clock-widget app for Android.
- 7 built-in luxury clocks (digital + analog) with accent colours and 12/24h.
- Includes a built-in Xiaomi Classic clock theme (no import needed).
- Import any number of Xiaomi / MIUI / HyperOS clock themes (.zip with manifest.xml).
- Resizable widgets: the clock scales to the widget size, plus a Size slider (30-150%).
- Per-widget editing: tap a widget (or open "Active") to change clock / size / colour.

## Build the APK with GitHub Actions
Put `ClockWidget.zip` (as is) and `.github/workflows/build.yml` in your repo, push to `main`,
then download `ClockWidget-apk` from the Actions run's Artifacts.

## Limits
Supported theme tags: Var, Group, Image (srcid, rotation, pivot), ImageNumber, Text, DateTime, Rectangle, Circle.
Buttons, animations, music controls and the Xiaomi weather provider are not supported (weather shows `--°`).
