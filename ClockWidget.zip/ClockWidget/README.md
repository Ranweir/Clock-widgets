# Aurum Clock

Made by **Ranweir** · Telegram: https://t.me/ranweirsinventory

Premium clock-widget app for Android.
- 7 built-in luxury clocks (digital + analog) with accent colours and 12/24h.
- Includes a built-in Xiaomi Classic clock theme (no import needed).
- Import any number of Xiaomi / MIUI / HyperOS clock themes (.zip with manifest.xml).
- Resizable widgets: the clock scales to the widget size, plus a Size slider (30-150%).
- App theme: System / Dark / Light (Settings › Appearance).
- iOS-style floating bar: tap or press-and-slide; labels optional (off by default).
- Per-widget editing: tap a widget (or open "Active") to change clock / size / colour.

## Build the APK with GitHub Actions
Put `ClockWidget.zip` (as is) and `.github/workflows/build.yml` in your repo, push to `main`,
then download `ClockWidget-apk` from the Actions run's Artifacts.

- ColorOS 17 clock (built-in): wide row ↔ tall 2×2 stack; it morphs smoothly as you resize the widget.
- KWGT tab: import any `.kwgt` widget (text, shapes, images, fonts, layers, time/date/battery, globals) and use it on the home screen.

## Limits
Supported theme tags: Var, Group, Image (srcid, rotation, pivot), ImageNumber, Text, DateTime, Rectangle, Circle.
Buttons, animations, music controls and the Xiaomi weather provider are not supported (weather shows `--°`).

KWGT: weather, music, notifications, icon fonts, touch actions and animations are not supported yet; very complex presets may differ from the real KWGT.
