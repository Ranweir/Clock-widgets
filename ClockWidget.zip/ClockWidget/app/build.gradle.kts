plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.clockwidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.clockwidget"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "5.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
