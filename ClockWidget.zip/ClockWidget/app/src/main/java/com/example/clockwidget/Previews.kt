package com.example.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

/**
 * Clock previews ko UI thread se bahar render karta hai (pehle har tab switch par
 * saare 24 clocks main thread par ban rahe the = lag). Cache + latest-wins editor worker.
 */
object Previews {
    private val gallery = Executors.newSingleThreadExecutor()
    private val editor = Executors.newSingleThreadExecutor()
    private val persistEx = Executors.newSingleThreadExecutor()
    private val pendingPersist = AtomicReference<Pair<Cfg, (Cfg) -> Unit>?>(null)
    private val main = Handler(Looper.getMainLooper())
    /** Koi preview ready hone par (bar ka blur refresh karne ke liye). */
    @Volatile var onReady: (() -> Unit)? = null

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private fun key(cfg: Cfg, w: Int, h: Int) = "${cfg.enc()}|$w|$h|${System.currentTimeMillis() / 60000}"

    /** Gallery / Active cards: cache hit = instant, warna background me render. */
    fun load(ctx: Context, iv: ImageView, cfg: Cfg, w: Int, h: Int) {
        val app = ctx.applicationContext
        val k = key(cfg, w, h)
        iv.tag = k
        val hit = cache.get(k)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageDrawable(null)
        gallery.execute {
            if (iv.tag != k) return@execute          // card scroll/tab se hat chuka, skip
            val bmp = runCatching { ClockEngine.render(app, cfg, w, h) }.getOrNull() ?: return@execute
            cache.put(k, bmp)
            main.post { if (iv.tag == k) { iv.setImageBitmap(bmp); onReady?.invoke() } }
        }
    }

    private val pending = AtomicReference<Pair<Cfg, (Cfg) -> Unit>?>(null)

    /**
     * Editor sliders: har drag-event par render nahi; sirf sabse naya cfg render hota hai.
     * persist() (prefs + widget refresh) bhi background me chalta hai.
     */
    fun live(ctx: Context, iv: ImageView, cfg: Cfg, w: Int, h: Int, persist: (Cfg) -> Unit) {
        val app = ctx.applicationContext
        pending.set(Pair(cfg, persist))
        editor.execute {
            val job = pending.getAndSet(null) ?: return@execute   // koi aur run already le chuka
            val bmp = runCatching { ClockEngine.render(app, job.first, w, h) }.getOrNull()
            if (bmp != null) main.post { iv.setImageBitmap(bmp) }       // preview pehle: save / widget refresh ka intezaar nahi
            pendingPersist.set(job)
            persistEx.execute {
                val pj = pendingPersist.getAndSet(null) ?: return@execute
                runCatching { pj.second(pj.first) }
            }
        }
    }
}
