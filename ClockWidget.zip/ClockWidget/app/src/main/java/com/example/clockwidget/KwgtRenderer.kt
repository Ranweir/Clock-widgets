package com.example.clockwidget

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.IdentityHashMap

/**
 * KWGT (.kwgt) preset ko Bitmap me draw karta hai (best effort).
 * Supported modules: Text, Shape, Bitmap, Progress, Overlap / Stack layers, Komponent.
 * Fonts (fonts/), bitmaps (bitmaps/), globals (gv) aur zyaadatar time/date/battery formulas chalte hain.
 * Weather, music, notifications, touch actions, animations aur font-icons abhi support nahi (chhod diye jaate hain).
 */
object KwgtRenderer {

    private class Doc(val root: JSONObject, val info: JSONObject?, val dir: File, val globals: Map<String, String>)

    private val docs = HashMap<String, Pair<Long, Doc>>()
    private val fonts = HashMap<String, Typeface?>()
    private val bitmaps = object : android.util.LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private fun load(dir: File): Doc? {
        val f = File(dir, "preset.json")
        if (!f.exists()) return null
        val key = f.absolutePath
        val mod = f.lastModified()
        synchronized(docs) { docs[key]?.let { if (it.first == mod) return it.second } }

        val o = JSONObject(f.readText())
        var root = o.optJSONObject("preset_root")
        if (root == null) {
            // Komponent / clip format
            val mods = o.optJSONArray("clip_modules")
            if (mods != null) root = JSONObject().put("internal_type", "OverlapLayerModule").put("viewgroup_items", mods)
        }
        if (root == null) return null
        val globals = HashMap<String, String>()
        val gl = root.optJSONArray("globals_list") ?: o.optJSONArray("globals_list")
        if (gl != null) {
            for (i in 0 until gl.length()) {
                val g = gl.optJSONObject(i) ?: continue
                val t = g.optString("title", "")
                if (t.isNotEmpty()) globals[t.lowercase()] = if (g.isNull("value")) "" else g.opt("value").toString()
            }
        }
        val doc = Doc(root, o.optJSONObject("preset_info"), dir, globals)
        synchronized(docs) { docs[key] = Pair(mod, doc) }
        return doc
    }

    /** Preset ka title (import ke time naam dikhane ke liye). */
    fun titleOf(dir: File): String? = try {
        JSONObject(File(dir, "preset.json").readText()).optJSONObject("preset_info")?.optString("title", "")?.trim()?.takeIf { it.isNotEmpty() }
    } catch (e: Exception) { null }

    fun render(ctx: Context, dir: File, W: Int, H: Int, pct: Int): Bitmap {
        val out = Bitmap.createBitmap(W.coerceAtLeast(1), H.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        try {
            val doc = load(dir) ?: return error(out, "Invalid KWGT file")
            var dw = doc.info?.optDouble("width", 0.0)?.toFloat() ?: 0f
            var dh = doc.info?.optDouble("height", 0.0)?.toFloat() ?: 0f
            if (dw <= 0f || dh <= 0f) { dw = 1080f; dh = 1080f }

            // pass 1: content ki hadd (bounds) nikaalo
            val probe = Env(ctx.applicationContext, doc)
            val tiny = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            probe.drawChildren(Canvas(tiny), doc.root, 0f, 0f, dw, dh)
            tiny.recycle()
            val b = probe.bounds
            if (b == null || b.width() <= 0f || b.height() <= 0f) return error(out, "Nothing to show")

            // pass 2: widget me beech me fit karke asli draw
            val c = Canvas(out)
            Fit.apply(c, b.width(), b.height(), out.width, out.height, pct, b.left, b.top, 0.96f)
            Env(ctx.applicationContext, doc).drawChildren(c, doc.root, 0f, 0f, dw, dh)
        } catch (e: Throwable) {
            return error(out, "Can't render this widget")
        }
        return out
    }

    private fun error(bmp: Bitmap, msg: String): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER
            textSize = minOf(bmp.width, bmp.height) * 0.09f
        }
        Canvas(bmp).drawText(msg, bmp.width / 2f, bmp.height / 2f, p)
        return bmp
    }

    // ───────────────────────── per-render environment ─────────────────────────

    private class TextInfo(val lines: List<String>, val paint: Paint, val w: Float, val h: Float, val lh: Float, val asc: Float, val align: Paint.Align)

    private class Env(val ctx: Context, val doc: Doc) {
        val cal: Calendar = Calendar.getInstance()
        val f = KwgtFormula({ cal }, { k -> doc.globals[k.lowercase()] }, { k -> battery(k) })
        val sizes = IdentityHashMap<JSONObject, FloatArray>()
        val texts = IdentityHashMap<JSONObject, TextInfo>()
        var bounds: RectF? = null

        private fun battery(k: String): String? {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            return when (k) {
                "level" -> if (lvl < 0) "0" else (lvl * 100 / sc).toString()
                "charging" -> if (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL) "1" else "0"
                "temp" -> (i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10).toString()
                else -> null
            }
        }

        // ── property access (formula > global > value) ──
        fun s(m: JSONObject, k: String, def: String = ""): String {
            val fx = m.optJSONObject("internal_formulas")?.optString(k, "") ?: ""
            if (fx.isNotEmpty()) return f.evalText(fx)
            val g = m.optJSONObject("internal_globals")?.optString(k, "") ?: ""
            if (g.isNotEmpty()) return doc.globals[g.lowercase()] ?: def
            if (!m.has(k) || m.isNull(k)) return def
            return m.opt(k).toString()
        }

        fun n(m: JSONObject, k: String, def: Float): Float = s(m, k, "").trim().toFloatOrNull() ?: def

        fun col(m: JSONObject, k: String, def: Int): Int = KwgtFormula.parseColor(s(m, k, "")) ?: def

        /** 0 = dikhta hai, 1 = invisible (jagah leta hai), 2 = remove. */
        fun vis(m: JSONObject): Int = when (s(m, "config_visible", "ALWAYS").trim().uppercase()) {
            "REMOVE" -> 2
            "INVISIBLE" -> 1
            else -> 0
        }

        fun kids(m: JSONObject): List<JSONObject> {
            val a = m.optJSONArray("viewgroup_items") ?: return emptyList()
            val l = ArrayList<JSONObject>(a.length())
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { l.add(it) }
            return l
        }

        fun type(m: JSONObject): String = m.optString("internal_type", "")

        private fun addBounds(x: Float, y: Float, w: Float, h: Float) {
            if (w <= 0f || h <= 0f) return
            val r = bounds
            if (r == null) bounds = RectF(x, y, x + w, y + h) else r.union(x, y, x + w, y + h)
        }

        // ── resources ──
        private fun resolve(name: String): String {
            val t = name.trim()
            return if (t.startsWith("kfile://")) t.removePrefix("kfile://").substringAfter('/', "") else t
        }

        private fun findFile(rel: String, vararg exts: String): File? {
            if (rel.isEmpty()) return null
            val direct = File(doc.dir, rel)
            if (direct.isFile) return direct
            for (e in exts) File(doc.dir, rel + e).let { if (it.isFile) return it }
            val parent = File(doc.dir, rel.substringBeforeLast('/', ""))
            val base = rel.substringAfterLast('/')
            return parent.listFiles()?.firstOrNull { it.isFile && (it.name.equals(base, true) || it.nameWithoutExtension.equals(base, true)) }
        }

        fun fontFor(m: JSONObject): Typeface {
            val rel = resolve(s(m, "text_family", ""))
            if (rel.isEmpty()) return Typeface.DEFAULT
            val file = findFile(rel, ".ttf", ".otf") ?: return Typeface.DEFAULT
            synchronized(fonts) {
                if (fonts.containsKey(file.absolutePath)) return fonts[file.absolutePath] ?: Typeface.DEFAULT
                val tf = try { Typeface.createFromFile(file) } catch (e: Exception) { null }
                fonts[file.absolutePath] = tf
                return tf ?: Typeface.DEFAULT
            }
        }

        /** Bitmap + uska asli (width, height). */
        fun bitmap(m: JSONObject): Pair<Bitmap, FloatArray>? {
            val rel = resolve(s(m, "bitmap_bitmap", ""))
            val file = findFile(rel, ".png", ".jpg", ".jpeg", ".webp") ?: return null
            val key = file.absolutePath + file.lastModified()
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            val nat = floatArrayOf(o.outWidth.toFloat(), o.outHeight.toFloat())
            var bmp = bitmaps.get(key)
            if (bmp == null) {
                var sample = 1
                while (o.outWidth / sample > 2048 || o.outHeight / sample > 2048) sample *= 2
                bmp = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
                bitmaps.put(key, bmp)
            }
            return Pair(bmp, nat)
        }

        // ── text ──
        fun text(m: JSONObject): TextInfo {
            texts[m]?.let { return it }
            var t = f.evalText(s(m, "text_expression", ""))
            val flt = m.optJSONArray("text_filter")
            if (flt != null) {
                for (i in 0 until flt.length()) {
                    when (flt.optString(i, "").uppercase()) {
                        "UP" -> t = t.uppercase()
                        "LOW" -> t = t.lowercase()
                        "CAP" -> t = t.split(' ').joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }
                    }
                }
            }
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = n(m, "text_size", 20f).coerceAtLeast(1f)
                color = col(m, "paint_color", Color.WHITE)
                typeface = fontFor(m)
            }
            val lines = t.split("\n")
            var w = 0f
            for (l in lines) w = maxOf(w, p.measureText(l))
            val fm = p.fontMetrics
            val lh = fm.descent - fm.ascent
            val tw = n(m, "text_width", 0f)
            val th = n(m, "text_height", 0f)
            val align = when (s(m, "text_align", "CENTER").uppercase()) {
                "LEFT" -> Paint.Align.LEFT
                "RIGHT" -> Paint.Align.RIGHT
                else -> Paint.Align.CENTER
            }
            val info = TextInfo(lines, p, if (tw > 0f) tw else w, if (th > 0f) th else lh * lines.size, lh, -fm.ascent, align)
            texts[m] = info
            return info
        }

        // ── layout ──
        fun measure(m: JSONObject): FloatArray {
            sizes[m]?.let { return it }
            val r = floatArrayOf(0f, 0f)
            sizes[m] = r
            if (vis(m) == 2) return r
            when (type(m)) {
                "TextModule" -> { val t = text(m); r[0] = t.w; r[1] = t.h }
                "ShapeModule" -> {
                    val w = n(m, "shape_width", 100f).coerceAtLeast(0f)
                    val circle = s(m, "shape_type", "RECT").uppercase() == "CIRCLE"
                    r[0] = w
                    r[1] = if (circle) w else n(m, "shape_height", 100f).coerceAtLeast(0f)
                }
                "BitmapModule" -> {
                    val b = bitmap(m)
                    if (b != null) {
                        val nat = b.second
                        val bw = n(m, "bitmap_width", 0f)
                        val bh = n(m, "bitmap_height", 0f)
                        when {
                            bw > 0f && bh > 0f -> { r[0] = bw; r[1] = bh }
                            bw > 0f -> { r[0] = bw; r[1] = bw * nat[1] / nat[0] }
                            bh > 0f -> { r[1] = bh; r[0] = bh * nat[0] / nat[1] }
                            else -> { r[0] = nat[0]; r[1] = nat[1] }
                        }
                    }
                }
                "ProgressModule" -> { r[0] = n(m, "style_size", 300f); r[1] = n(m, "style_height", 20f) }
                "StackLayerModule" -> {
                    val horiz = s(m, "config_stacking", "VERTICAL_CENTER").uppercase().startsWith("HORIZONTAL")
                    for (k in kids(m)) {
                        if (vis(k) == 2) continue
                        val z = measure(k)
                        if (horiz) { r[0] += z[0]; r[1] = maxOf(r[1], z[1]) } else { r[1] += z[1]; r[0] = maxOf(r[0], z[0]) }
                    }
                }
                else -> for (k in kids(m)) {
                    if (vis(k) == 2) continue
                    val z = measure(k)
                    r[0] = maxOf(r[0], z[0]); r[1] = maxOf(r[1], z[1])
                }
            }
            return r
        }

        private fun place(m: JSONObject, sz: FloatArray, cw: Float, ch: Float): FloatArray {
            val a = s(m, "position_anchor", "CENTER").uppercase()
            val pl = n(m, "position_padding_left", 0f); val pr = n(m, "position_padding_right", 0f)
            val pt = n(m, "position_padding_top", 0f); val pb = n(m, "position_padding_bottom", 0f)
            val x = when {
                a.contains("LEFT") -> pl
                a.contains("RIGHT") -> cw - sz[0] - pr
                else -> (cw - sz[0]) / 2f + (pl - pr) / 2f
            }
            val y = when {
                a.startsWith("TOP") -> pt
                a.startsWith("BOTTOM") -> ch - sz[1] - pb
                else -> (ch - sz[1]) / 2f + (pt - pb) / 2f
            }
            return floatArrayOf(x + n(m, "position_offset_x", 0f), y + n(m, "position_offset_y", 0f))
        }

        private fun crossPos(total: Float, size: Float, align: String): Float = when {
            align.contains("START") || align.contains("LEFT") || align.contains("TOP") -> 0f
            align.contains("END") || align.contains("RIGHT") || align.contains("BOTTOM") -> total - size
            else -> (total - size) / 2f
        }

        /** Container (x, y, w, h) ke andar uske bachche draw karta hai. */
        fun drawChildren(c: Canvas, m: JSONObject, x: Float, y: Float, w: Float, h: Float) {
            if (type(m) == "StackLayerModule") {
                val st = s(m, "config_stacking", "VERTICAL_CENTER").uppercase()
                val horiz = st.startsWith("HORIZONTAL")
                val cross = st.substringAfter('_', "CENTER")
                var pos = 0f
                for (k in kids(m)) {
                    if (vis(k) == 2) continue
                    val z = measure(k)
                    val ox = n(k, "position_offset_x", 0f)
                    val oy = n(k, "position_offset_y", 0f)
                    if (horiz) {
                        draw(c, k, x + pos + ox, y + crossPos(h, z[1], cross) + oy)
                        pos += z[0]
                    } else {
                        draw(c, k, x + crossPos(w, z[0], cross) + ox, y + pos + oy)
                        pos += z[1]
                    }
                }
            } else {
                for (k in kids(m)) {
                    if (vis(k) == 2) continue
                    val z = measure(k)
                    val p = place(k, z, w, h)
                    draw(c, k, x + p[0], y + p[1])
                }
            }
        }

        fun draw(c: Canvas, m: JSONObject, x: Float, y: Float) {
            if (vis(m) != 0) return
            val sz = measure(m)
            val w = sz[0]
            val h = sz[1]
            when (type(m)) {
                "TextModule" -> {
                    val t = text(m)
                    if (t.paint.alpha > 0 && t.lines.any { it.isNotEmpty() }) addBounds(x, y, w, h)
                    t.paint.textAlign = t.align
                    val ax = when (t.align) { Paint.Align.LEFT -> x; Paint.Align.RIGHT -> x + w; else -> x + w / 2f }
                    for ((i, l) in t.lines.withIndex()) c.drawText(l, ax, y + i * t.lh + t.asc, t.paint)
                }
                "ShapeModule" -> drawShape(c, m, x, y, w, h)
                "BitmapModule" -> {
                    val b = bitmap(m) ?: return
                    val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    val a = n(m, "bitmap_alpha", 100f)
                    p.alpha = (if (a <= 100f) a * 2.55f else a).toInt().coerceIn(0, 255)
                    if (s(m, "bitmap_filter", "").uppercase() == "COLORIZE") {
                        p.colorFilter = PorterDuffColorFilter(col(m, "bitmap_filter_color", Color.WHITE), PorterDuff.Mode.SRC_IN)
                    }
                    if (p.alpha > 0) addBounds(x, y, w, h)
                    c.drawBitmap(b.first, null, RectF(x, y, x + w, y + h), p)
                }
                "ProgressModule" -> {
                    val bg = col(m, "color_bgcolor", 0x40FFFFFF)
                    val fg = col(m, "color_fgcolor", Color.WHITE)
                    val frac = if (s(m, "progress_progress", "").uppercase() == "BATTERY") (f.evalText("\$bi(level)\$").toFloatOrNull() ?: 0f) / 100f else 0f
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    val r = minOf(w, h) / 2f
                    p.color = bg
                    c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p)
                    p.color = fg
                    if (frac > 0f) c.drawRoundRect(RectF(x, y, x + w * frac.coerceIn(0f, 1f), y + h), r, r, p)
                    addBounds(x, y, w, h)
                }
                "FontIconModule" -> { /* icon fonts abhi support nahi */ }
                else -> drawChildren(c, m, x, y, w, h)
            }
        }

        private fun drawShape(c: Canvas, m: JSONObject, x: Float, y: Float, w: Float, h: Float) {
            val color = col(m, "paint_color", Color.WHITE)
            if (Color.alpha(color) == 0 || w <= 0f || h <= 0f) return
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
            val mode = s(m, "paint_mode", s(m, "paint_style", "FILL")).uppercase()
            if (mode.contains("STROKE")) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = n(m, "paint_stroke", n(m, "paint_stroke_width", 4f)).coerceAtLeast(1f)
            }
            val r = RectF(x, y, x + w, y + h)
            when (s(m, "shape_type", "RECT").uppercase()) {
                "CIRCLE" -> c.drawCircle(x + w / 2f, y + h / 2f, minOf(w, h) / 2f, p)
                "OVAL", "ARC", "SLICE" -> c.drawOval(r, p)
                "TRIANGLE" -> {
                    val path = Path()
                    path.moveTo(x + w / 2f, y); path.lineTo(x + w, y + h); path.lineTo(x, y + h); path.close()
                    c.drawPath(path, p)
                }
                else -> {
                    val rad = n(m, "shape_corners", 0f).coerceIn(0f, minOf(w, h) / 2f)
                    if (rad > 0f) c.drawRoundRect(r, rad, rad, p) else c.drawRect(r, p)
                }
            }
            addBounds(x, y, w, h)
        }
    }
}
