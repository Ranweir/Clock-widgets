package com.example.clockwidget

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToLong

/** Chhota expression evaluator (MAML jaisa): #var, numbers, 'strings', + - * / %, comparisons, functions. */
class Expr(private val lookup: (String) -> Any?) {
    private var s = ""
    private var p = 0

    fun eval(src: String): Any {
        s = src
        p = 0
        return try {
            parseCompare()
        } catch (e: Exception) {
            0.0
        }
    }

    fun evalNum(src: String): Double = toNum(eval(src))

    private fun ws() {
        while (p < s.length && s[p].isWhitespace()) p++
    }

    private fun peek(): Char {
        ws()
        return if (p < s.length) s[p] else '\u0000'
    }

    private fun startsWith(t: String): Boolean {
        ws()
        return s.startsWith(t, p)
    }

    private fun parseCompare(): Any {
        var l = parseAdd()
        while (true) {
            val op = when {
                startsWith("==") -> "=="
                startsWith("!=") -> "!="
                startsWith("<=") -> "<="
                startsWith(">=") -> ">="
                startsWith("<") -> "<"
                startsWith(">") -> ">"
                else -> ""
            }
            if (op.isEmpty()) break
            p += op.length
            val r = parseAdd()
            val res = when (op) {
                "==" -> same(l, r)
                "!=" -> !same(l, r)
                "<=" -> toNum(l) <= toNum(r)
                ">=" -> toNum(l) >= toNum(r)
                "<" -> toNum(l) < toNum(r)
                else -> toNum(l) > toNum(r)
            }
            l = if (res) 1.0 else 0.0
        }
        return l
    }

    private fun parseAdd(): Any {
        var l = parseMul()
        while (true) {
            val c = peek()
            if (c == '+') {
                p++
                val r = parseMul()
                l = if (l is String || r is String) fmt(l) + fmt(r) else toNum(l) + toNum(r)
            } else if (c == '-') {
                p++
                val r = parseMul()
                l = toNum(l) - toNum(r)
            } else break
        }
        return l
    }

    private fun parseMul(): Any {
        var l = parseUnary()
        while (true) {
            val c = peek()
            if (c == '*') {
                p++
                l = toNum(l) * toNum(parseUnary())
            } else if (c == '/') {
                p++
                val r = toNum(parseUnary())
                l = if (r == 0.0) 0.0 else toNum(l) / r
            } else if (c == '%') {
                p++
                val r = toNum(parseUnary())
                l = if (r == 0.0) 0.0 else toNum(l) % r
            } else break
        }
        return l
    }

    private fun parseUnary(): Any {
        val c = peek()
        if (c == '-') {
            p++
            return -toNum(parseUnary())
        }
        if (c == '+') {
            p++
            return parseUnary()
        }
        return parsePrimary()
    }

    private fun parsePrimary(): Any {
        val c = peek()
        if (c == '(') {
            p++
            val v = parseCompare()
            if (peek() == ')') p++
            return v
        }
        if (c == '\'' || c == '"') {
            p++
            val st = p
            while (p < s.length && s[p] != c) p++
            val str = s.substring(st, p)
            if (p < s.length) p++
            return str
        }
        if (c.isDigit() || c == '.') {
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            return s.substring(st, p).toDoubleOrNull() ?: 0.0
        }
        if (c == '#' || c == '@') {
            p++
            val st = p
            while (p < s.length && (s[p].isLetterOrDigit() || s[p] == '_' || s[p] == '.')) p++
            val v = lookup(s.substring(st, p))
            return if (v is Number) v.toDouble() else (v ?: 0.0)
        }
        if (c.isLetter()) {
            val st = p
            while (p < s.length && (s[p].isLetterOrDigit() || s[p] == '_')) p++
            val name = s.substring(st, p)
            if (peek() == '(') return call(name)
            return 0.0
        }
        throw IllegalStateException("bad expression at $p")
    }

    private fun call(name: String): Any {
        p++ // '('
        val args = ArrayList<Any>()
        if (peek() == ')') {
            p++
        } else {
            while (true) {
                args.add(parseCompare())
                val c = peek()
                if (c == ',') {
                    p++
                    continue
                }
                if (c == ')') p++
                break
            }
        }
        fun n(i: Int) = if (i < args.size) toNum(args[i]) else 0.0
        fun b(x: Boolean) = if (x) 1.0 else 0.0
        return when (name.lowercase()) {
            "int" -> n(0).toLong().toDouble()
            "round" -> n(0).roundToLong().toDouble()
            "abs" -> abs(n(0))
            "min" -> minOf(n(0), n(1))
            "max" -> maxOf(n(0), n(1))
            "not" -> b(n(0) == 0.0)
            "eq" -> b(args.size >= 2 && same(args[0], args[1]))
            "ne" -> b(!(args.size >= 2 && same(args[0], args[1])))
            "lt" -> b(n(0) < n(1))
            "le" -> b(n(0) <= n(1))
            "gt" -> b(n(0) > n(1))
            "ge" -> b(n(0) >= n(1))
            "ifelse" -> {
                var i = 0
                while (i + 1 < args.size) {
                    if (toNum(args[i]) != 0.0) return args[i + 1]
                    i += 2
                }
                if (args.size % 2 == 1) args.last() else 0.0
            }
            else -> 0.0
        }
    }

    companion object {
        fun toNum(v: Any): Double = when (v) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }

        fun fmt(v: Any): String = when (v) {
            is Double -> if (!v.isNaN() && !v.isInfinite() && v == floor(v)) v.toLong().toString() else v.toString()
            else -> v.toString()
        }

        fun same(a: Any, b: Any): Boolean =
            if (a is String || b is String) fmt(a) == fmt(b) else toNum(a) == toNum(b)
    }
}
