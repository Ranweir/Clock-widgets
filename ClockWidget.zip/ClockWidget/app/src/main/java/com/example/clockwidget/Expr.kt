package com.example.clockwidget

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToLong

/** Chhota expression evaluator (MAML jaisa): #var, numbers, 'strings', + - * / %, comparisons, functions. */
class Expr(private val lookup: (String) -> Any?) {
    private var s = ""
    private var p = 0

    fun eval(src: String): Any {
        s = src
        p = 0
        return try {
            parseOr()
        } catch (e: Exception) {
            0.0
        }
    }

    fun evalNum(src: String): Double = toNum(eval(src))

    private fun ws() {
        while (p < s.length && s[p].isWhitespace()) p++
    }

    private fun peek(): Char {
        ws()
        return if (p < s.length) s[p] else '\u0000'
    }

    private fun startsWith(t: String): Boolean {
        ws()
        return s.startsWith(t, p)
    }

    private fun parseOr(): Any {
        var l = parseAnd()
        while (startsWith("||")) {
            p += 2
            val r = parseAnd()
            l = if (toNum(l) != 0.0 || toNum(r) != 0.0) 1.0 else 0.0
        }
        return l
    }

    private fun parseAnd(): Any {
        var l = parseCompare()
        while (startsWith("&&") || startsWith("**")) {   // MAML me "**" bhi AND hai
            p += 2
            val r = parseCompare()
            l = if (toNum(l) != 0.0 && toNum(r) != 0.0) 1.0 else 0.0
        }
        return l
    }

    private fun parseCompare(): Any {
        var l = parseAdd()
        while (true) {
            val op = when {
                startsWith("==") -> "=="
                startsWith("!=") -> "!="
                startsWith("<=") -> "<="
                startsWith(">=") -> ">="
                startsWith("<") -> "<"
                startsWith(">") -> ">"
                else -> ""
            }
            if (op.isEmpty()) break
            p += op.length
            val r = parseAdd()
            val res = when (op) {
                "==" -> same(l, r)
                "!=" -> !same(l, r)
                "<=" -> toNum(l) <= toNum(r)
                ">=" -> toNum(l) >= toNum(r)
                "<" -> toNum(l) < toNum(r)
                else -> toNum(l) > toNum(r)
            }
            l = if (res) 1.0 else 0.0
        }
        return l
    }

    private fun parseAdd(): Any {
        var l = parseMul()
        while (true) {
            val c = peek()
            if (c == '+') {
                p++
                val r = parseMul()
                l = if (l is String || r is String) fmt(l) + fmt(r) else toNum(l) + toNum(r)
            } else if (c == '-') {
                p++
                val r = parseMul()
                l = toNum(l) - toNum(r)
            } else break
        }
        return l
    }

    private fun parseMul(): Any {
        var l = parseUnary()
        while (true) {
            val c = peek()
            if (c == '*') {
                if (p + 1 < s.length && s[p + 1] == '*') break   // "**" AND hai, multiply nahi
                p++
                l = toNum(l) * toNum(parseUnary())
            } else if (c == '/') {
                p++
                val r = toNum(parseUnary())
                l = if (r == 0.0) 0.0 else toNum(l) / r
            } else if (c == '%') {
                p++
                val r = toNum(parseUnary())
                l = if (r == 0.0) 0.0 else toNum(l) % r
            } else break
        }
        return l
    }

    private fun parseUnary(): Any {
        val c = peek()
        if (c == '-') {
            p++
            return -toNum(parseUnary())
        }
        if (c == '+') {
            p++
            return parseUnary()
        }
        if (c == '!' && !(p + 1 < s.length && s[p + 1] == '=')) {
            p++
            return if (toNum(parseUnary()) == 0.0) 1.0 else 0.0
        }
        return parsePrimary()
    }

    private fun parsePrimary(): Any {
        val c = peek()
        if (c == '(') {
            p++
            val v = parseOr()
            if (peek() == ')') p++
            return v
        }
        if (c == '\'' || c == '"') {
            p++
            val st = p
            while (p < s.length && s[p] != c) p++
            val str = s.substring(st, p)
            if (p < s.length) p++
            return str
        }
        if (c.isDigit() || c == '.') {
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            return s.substring(st, p).toDoubleOrNull() ?: 0.0
        }
        if (c == '#' || c == '@') {
            p++
            val st = p
            while (p < s.length && (s[p].isLetterOrDigit() || s[p] == '_' || s[p] == '.')) p++
            val v = lookup(s.substring(st, p))
            return if (v is Number) v.toDouble() else (v ?: (if (c == '@') "" else 0.0))
        }
        if (c.isLetter()) {
            val st = p
            while (p < s.length && (s[p].isLetterOrDigit() || s[p] == '_')) p++
            val name = s.substring(st, p)
            if (peek() == '(') return call(name)
            return 0.0
        }
        throw IllegalStateException("bad expression at $p")
    }

    private fun call(name: String): Any {
        p++ // '('
        val args = ArrayList<Any>()
        if (peek() == ')') {
            p++
        } else {
            while (true) {
                args.add(parseOr())
                val c = peek()
                if (c == ',') {
                    p++
                    continue
                }
                if (c == ')') p++
                break
            }
        }
        fun n(i: Int) = if (i < args.size) toNum(args[i]) else 0.0
        fun b(x: Boolean) = if (x) 1.0 else 0.0
        return when (name.lowercase()) {
            "int" -> n(0).toLong().toDouble()
            "round" -> n(0).roundToLong().toDouble()
            "abs" -> abs(n(0))
            "floor" -> floor(n(0))
            "ceil" -> kotlin.math.ceil(n(0))
            "sqrt" -> kotlin.math.sqrt(n(0))
            "pow" -> Math.pow(n(0), n(1))
            "mod" -> if (n(1) == 0.0) 0.0 else n(0) % n(1)
            "sin" -> kotlin.math.sin(n(0))
            "cos" -> kotlin.math.cos(n(0))
            "min" -> if (args.isEmpty()) 0.0 else args.minOf { toNum(it) }
            "max" -> if (args.isEmpty()) 0.0 else args.maxOf { toNum(it) }
            "substr" -> {
                val t = if (args.isEmpty()) "" else fmt(args[0])
                val st = n(1).toInt().coerceIn(0, t.length)
                if (args.size > 2) t.substring(st, (st + n(2).toInt()).coerceIn(st, t.length)) else t.substring(st)
            }
            "strendswith" -> b(args.size >= 2 && fmt(args[0]).endsWith(fmt(args[1])))
            "strstartswith" -> b(args.size >= 2 && fmt(args[0]).startsWith(fmt(args[1])))
            "strisempty" -> b(args.isEmpty() || (args[0] is String && (args[0] as String).isEmpty()))
            "strlen" -> (if (args.isEmpty()) 0 else fmt(args[0]).length).toDouble()
            "formatdate" -> {
                val f = if (args.isEmpty()) "HH:mm" else fmt(args[0])
                val ms = if (args.size > 1) n(1) else toNum(lookup("time_sys") ?: System.currentTimeMillis().toDouble())
                // sirf numbers wale pattern (hh, mm, dd...) ke liye English digits; naam wale (EEE, MMM, a) phone ki bhasha me
                val loc = if (f.any { it == 'E' || it == 'a' } || f.contains("MMM")) java.util.Locale.getDefault() else java.util.Locale.US
                try { java.text.SimpleDateFormat(f, loc).format(java.util.Date(ms.toLong())) } catch (e: Exception) { "" }
            }
            "not" -> b(n(0) == 0.0)
            "eq" -> b(args.size >= 2 && same(args[0], args[1]))
            "ne" -> b(!(args.size >= 2 && same(args[0], args[1])))
            "lt" -> b(n(0) < n(1))
            "le" -> b(n(0) <= n(1))
            "gt" -> b(n(0) > n(1))
            "ge" -> b(n(0) >= n(1))
            "ifelse" -> {
                var i = 0
                while (i + 1 < args.size) {
                    if (toNum(args[i]) != 0.0) return args[i + 1]
                    i += 2
                }
                if (args.size % 2 == 1) args.last() else 0.0
            }
            else -> 0.0
        }
    }

    companion object {
        fun toNum(v: Any): Double = when (v) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }

        fun fmt(v: Any): String = when (v) {
            is Double -> if (!v.isNaN() && !v.isInfinite() && v == floor(v)) v.toLong().toString() else v.toString()
            else -> v.toString()
        }

        fun same(a: Any, b: Any): Boolean =
            if (a is String || b is String) fmt(a) == fmt(b) else toNum(a) == toNum(b)
    }
}
