package com.example.clockwidget

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Built-in clock designs, sab Canvas se bane hain (design space = w x h). */
object Builtins {
    class Spec(val id: String, val name: String, val kind: String, val w: Int, val h: Int)

    val list = listOf(
        Spec("b:bold", "Noir Bold", "Digital", 1000, 470),
        Spec("b:thin", "Thin Stack", "Digital", 700, 980),
        Spec("b:serif", "Serif Luxe", "Digital", 1000, 440),
        Spec("b:split", "Split Tone", "Digital", 1000, 420),
        Spec("b:date", "Date Focus", "Digital", 1200, 560),
        Spec("b:analog", "Classic Dial", "Analog", 800, 800),
        Spec("b:ring", "Ring Minimal", "Analog", 800, 800),
        // ── OS-inspired long / stacked lockscreen styles (system fonts, not the original proprietary fonts) ──
        Spec("b:hyper_stack", "HyperOS Stack", "Stack · HyperOS style", 700, 1000),
        Spec("b:hyper_wide", "HyperOS Wide", "Wide · HyperOS style", 1000, 420),
        Spec("b:origin_tall", "OriginOS Tall", "Tall stack · OriginOS style", 760, 1100),
        Spec("b:oneui_stack", "One UI Stack", "Stack · One UI style", 700, 1000),
        Spec("b:oneui_wide", "One UI Bold", "Wide · One UI style", 1000, 500),
        Spec("b:coloros_long", "ColorOS Long", "Long · ColorOS style", 1000, 700),
        Spec("b:coloros_stack", "ColorOS Stack", "Tall stack · ColorOS style", 640, 1100),
        Spec("b:ios", "Glass Bold", "Bold · iOS style", 1000, 560),
        Spec("b:pixel", "Outline Stack", "Stack · Pixel style", 760, 1000),
        Spec("b:dot", "Dot Matrix", "Dot matrix · Nothing style", 1000, 420),
        Spec("b:serifstack", "Serif Stack", "Tall stack · Serif", 700, 1100),
        Spec("b:mono", "Terminal Mono", "Wide · Mono", 1000, 380),
        // ── ColorOS 17 style tall glass clocks (Flux Glow ON karke best dikhte hain) ──
        Spec("b:ctall_stack", "Tall Glass Stack", "Tall stack · ColorOS 17 style", 800, 1140),
        Spec("b:ctall_wide", "Tall Glass Wide", "Tall wide · ColorOS 17 style", 1000, 700),
        Spec("b:ctall_left", "Tall Glass Left", "Tall left · ColorOS 17 style", 1000, 820),
        // ── Naye (v2.0) ──
        Spec("b:scenery", "Scenery", "Ultra-thin tall stack", 700, 1180),
        Spec("b:eastern", "Eastern Aesthetics", "Serif spaced · red divider", 1000, 560)
    )

    private val COLON_IDS = setOf(
        "b:bold", "b:serif", "b:date", "b:hyper_wide", "b:oneui_wide", "b:coloros_long", "b:ios", "b:dot", "b:mono", "b:eastern"
    )

    fun hasColon(id: String) = id in COLON_IDS

    fun spec(id: String) = list.firstOrNull { it.id == id }

    private val IVORY = Pal.IVORY

    private fun paint(
        size: Float, color: Int, tf: Typeface,
        align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f, alpha: Int = 255
    ) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        this.alpha = alpha
        typeface = tf
        textAlign = align
        letterSpacing = spacing
    }

    /** Text ko bounds ke hisaab se vertical center me draw karta hai. */
    private fun text(c: Canvas, s: String, x: Float, cy: Float, p: Paint) {
        val r = Rect()
        p.getTextBounds(s, 0, s.length, r)
        c.drawText(s, x, cy - (r.top + r.bottom) / 2f, p)
    }

    private fun tf(name: String, style: Int = Typeface.NORMAL) = Typeface.create(name, style)

    private fun two(n: Int) = if (n < 10) "0$n" else "$n"

    private fun hour(cal: Calendar, h12: Boolean, pad: Boolean = true): String {
        var h = cal.get(Calendar.HOUR_OF_DAY)
        if (h12) {
            h %= 12
            if (h == 0) h = 12
        }
        return if (pad) two(h) else h.toString()
    }

    private fun min(cal: Calendar) = two(cal.get(Calendar.MINUTE))

    private fun fmt(cal: Calendar, f: String) = SimpleDateFormat(f, Locale.ENGLISH).format(cal.time)

    /** Kaunsa hissa (layer) is clock me hai: main = digits, colon = ":" , date = date/text lines. */
    fun hasPart(id: String, part: String, colon: Boolean, showDate: Boolean): Boolean = when (part) {
        "main" -> true
        "colon" -> colon && hasColon(id)
        "date" -> showDate && id != "b:analog"
        else -> false
    }

    fun draw(id: String, c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        when (id) {
            "b:bold" -> bold(c, accent, h12, cal, part)
            "b:thin" -> thin(c, accent, h12, cal, part)
            "b:serif" -> serif(c, accent, h12, cal, part)
            "b:split" -> split(c, accent, h12, cal, part)
            "b:date" -> dateFocus(c, accent, h12, cal, part)
            "b:analog" -> if (part == "main") analog(c, accent, cal)
            "b:ring" -> ring(c, accent, cal, part)
            "b:hyper_stack" -> hyperStack(c, h12, cal, part)
            "b:hyper_wide" -> hyperWide(c, h12, cal, part)
            "b:origin_tall" -> originTall(c, accent, h12, cal, part)
            "b:oneui_stack" -> oneStack(c, h12, cal, part)
            "b:oneui_wide" -> oneWide(c, h12, cal, part)
            "b:coloros_long" -> colorosLong(c, h12, cal, part)
            "b:coloros_stack" -> colorosStack(c, accent, h12, cal, part)
            "b:ios" -> ios(c, h12, cal, part)
            "b:pixel" -> pixel(c, accent, h12, cal, part)
            "b:dot" -> dot(c, accent, h12, cal, part)
            "b:serifstack" -> serifStack(c, accent, h12, cal, part)
            "b:mono" -> mono(c, accent, h12, cal, part)
            "b:ctall_stack" -> ctallStack(c, h12, cal, part)
            "b:ctall_wide" -> ctallWide(c, h12, cal, part)
            "b:ctall_left" -> ctallLeft(c, h12, cal, part)
            "b:scenery" -> scenery(c, h12, cal, part)
            "b:eastern" -> eastern(c, h12, cal, part)
        }
    }

    private fun bold(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val f = tf("sans-serif-condensed", Typeface.BOLD)
        val pi = paint(340f, IVORY, f)
        val pa = paint(340f, accent, f)
        val h = hour(cal, h12)
        val m = min(cal)
        val gap = 14f
        val wh = pi.measureText(h)
        val wc = pa.measureText(":")
        val wm = pi.measureText(m)
        val x0 = (1000f - (wh + wc + wm + gap * 2)) / 2f
        when (part) {
            "main" -> {
                text(c, h, x0, 195f, pi)
                text(c, m, x0 + wh + gap + wc + gap, 195f, pi)
            }
            "colon" -> text(c, ":", x0 + wh + gap, 185f, pa)
            "date" -> text(c, fmt(cal, "EEE  ·  d MMM").uppercase(Locale.ENGLISH), 500f, 425f,
                paint(52f, IVORY, tf("sans-serif-medium"), Paint.Align.CENTER, 0.28f, 200))
        }
    }

    private fun thin(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val f = tf("sans-serif-thin")
        if (part == "date") {
            text(c, fmt(cal, "EEE  d MMM").uppercase(Locale.ENGLISH), 350f, 28f,
                paint(50f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.3f))
        } else if (part == "main") {
            text(c, hour(cal, h12), 350f, 300f, paint(560f, IVORY, f, Paint.Align.CENTER))
            text(c, min(cal), 350f, 760f, paint(560f, accent, f, Paint.Align.CENTER))
        }
    }

    private fun serif(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(300f, IVORY, Typeface.create("serif", Typeface.NORMAL))
        val h = hour(cal, h12, false)
        val m = min(cal)
        val wh = p.measureText(h)
        val wc = p.measureText(":")
        val wm = p.measureText(m)
        val x0 = (1000f - (wh + wc + wm)) / 2f
        when (part) {
            "main" -> {
                text(c, h, x0, 245f, p)
                text(c, m, x0 + wh + wc, 245f, p)
                if (h12) {
                    text(c, fmt(cal, "a").uppercase(Locale.ENGLISH), 500f, 410f,
                        paint(40f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.4f))
                }
            }
            "colon" -> text(c, ":", x0 + wh, 235f, p)
            "date" -> {
                text(c, fmt(cal, "EEEE  ·  d MMMM").uppercase(Locale.ENGLISH), 500f, 28f,
                    paint(40f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.35f))
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    strokeWidth = 3f
                }
                c.drawLine(420f, 88f, 580f, 88f, line)
            }
        }
    }

    private fun split(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val f = tf("sans-serif-thin")
        val ph = paint(380f, accent, f)
        val pm = paint(380f, IVORY, f)
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = ph.measureText(h)
        val wm = pm.measureText(m)
        val x0 = (1000f - (wh + 50f + wm)) / 2f
        if (part == "date") {
            text(c, fmt(cal, "MMM dd  EEE"), x0, 26f,
                paint(54f, IVORY, tf("sans-serif-light"), Paint.Align.LEFT, 0.05f, 210))
        } else if (part == "main") {
            text(c, h, x0, 235f, ph)
            text(c, m, x0 + wh + 50f, 235f, pm)
        }
    }

    private fun dateFocus(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val x0 = 580f
        val tp = paint(170f, IVORY, tf("sans-serif-thin"), Paint.Align.LEFT)
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = tp.measureText(h)
        val wc = tp.measureText(":")
        when (part) {
            "main" -> {
                val day = cal.get(Calendar.DAY_OF_MONTH).toString()
                text(c, day, 260f, 280f, paint(460f, accent, tf("sans-serif-thin"), Paint.Align.CENTER))
                text(c, h, x0, 410f, tp)
                text(c, m, x0 + wh + wc, 410f, tp)
            }
            "colon" -> text(c, ":", x0 + wh, 400f, tp)
            "date" -> {
                text(c, fmt(cal, "EEEE").uppercase(Locale.ENGLISH), x0, 140f,
                    paint(90f, IVORY, tf("sans-serif-light"), Paint.Align.LEFT, 0.12f))
                text(c, fmt(cal, "MMMM yyyy").uppercase(Locale.ENGLISH), x0, 235f,
                    paint(46f, IVORY, tf("sans-serif-medium"), Paint.Align.LEFT, 0.3f, 190))
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    strokeWidth = 3f
                }
                c.drawLine(x0, 300f, x0 + 120f, 300f, line)
            }
        }
    }

    private fun hand(c: Canvas, angle: Float, from: Float, to: Float, width: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = width
            strokeCap = Paint.Cap.ROUND
        }
        c.save()
        c.rotate(angle, 400f, 400f)
        c.drawLine(400f, 400f + from, 400f, 400f - to, p)
        c.restore()
    }

    private fun analog(c: Canvas, accent: Int, cal: Calendar) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
        c.drawCircle(400f, 400f, 380f, fill)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        c.drawCircle(400f, 400f, 377f, ring)

        for (i in 0 until 60) {
            val big = i % 5 == 0
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (big) accent else IVORY
                alpha = if (big) 255 else 130
                strokeWidth = if (big) 8f else 3f
            }
            c.save()
            c.rotate(i * 6f, 400f, 400f)
            c.drawLine(400f, 44f, 400f, 44f + if (big) 34f else 14f, p)
            c.restore()
        }
        val np = paint(78f, IVORY, tf("sans-serif-light"), Paint.Align.CENTER)
        text(c, "12", 400f, 130f, np)
        text(c, "3", 670f, 400f, np)
        text(c, "6", 400f, 670f, np)
        text(c, "9", 130f, 400f, np)

        val h = cal.get(Calendar.HOUR_OF_DAY) % 12
        val m = cal.get(Calendar.MINUTE)
        hand(c, (h + m / 60f) * 30f, 30f, 190f, 24f, IVORY)
        hand(c, m * 6f, 30f, 300f, 14f, IVORY)
        val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
        c.drawCircle(400f, 400f, 20f, cap)
        cap.color = Pal.BG
        c.drawCircle(400f, 400f, 7f, cap)
    }

    private fun ring(c: Canvas, accent: Int, cal: Calendar, part: String) {
        if (part == "date") {
            text(c, fmt(cal, "EEE  d").uppercase(Locale.ENGLISH), 400f, 580f,
                paint(46f, IVORY, tf("sans-serif-medium"), Paint.Align.CENTER, 0.3f, 200))
            return
        }
        if (part != "main") return
        val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = IVORY
            alpha = 220
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        c.drawCircle(400f, 400f, 376f, rp)
        for (i in 0 until 12) {
            val big = i % 3 == 0
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (big) accent else IVORY
                alpha = if (big) 255 else 170
                strokeWidth = 6f
                strokeCap = Paint.Cap.ROUND
            }
            c.save()
            c.rotate(i * 30f, 400f, 400f)
            c.drawLine(400f, 50f, 400f, 50f + if (big) 46f else 20f, p)
            c.restore()
        }
        val h = cal.get(Calendar.HOUR_OF_DAY) % 12
        val m = cal.get(Calendar.MINUTE)
        hand(c, (h + m / 60f) * 30f, 0f, 210f, 28f, IVORY)
        hand(c, m * 6f, 0f, 310f, 14f, accent)
        val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = IVORY }
        c.drawCircle(400f, 400f, 16f, cap)
        cap.color = Pal.BG
        c.drawCircle(400f, 400f, 6f, cap)
    }

    // ───────────────────── OS-inspired styles ─────────────────────

    /** Text ko vertically (aur chahe to horizontally) kheench kar "long" look deta hai. */
    private fun tall(c: Canvas, s: String, x: Float, cy: Float, p: Paint, sy: Float, sx: Float = 1f) {
        c.save()
        c.scale(sx, sy, x, cy)
        text(c, s, x, cy, p)
        c.restore()
    }

    private fun smallDate(c: Canvas, s: String, x: Float, y: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, size: Float = 52f) =
        text(c, s, x, y, paint(size, color, tf("sans-serif-medium"), align, 0.04f, 225))

    private fun hyperStack(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val p = paint(520f, IVORY, tf("sans-serif", Typeface.BOLD), Paint.Align.CENTER)
            text(c, hour(cal, h12), 350f, 280f, p)
            text(c, min(cal), 350f, 760f, p)
        } else if (part == "date") {
            smallDate(c, fmt(cal, "EEE, d MMM"), 350f, 40f, IVORY)
        }
    }

    private fun hyperWide(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(360f, IVORY, tf("sans-serif-light"))
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = p.measureText(h)
        val wc = p.measureText(":")
        val wm = p.measureText(m)
        val x0 = (1000f - (wh + wc + wm)) / 2f
        when (part) {
            "main" -> {
                text(c, h, x0, 235f, p)
                text(c, m, x0 + wh + wc, 235f, p)
            }
            "colon" -> text(c, ":", x0 + wh, 222f, p)
            "date" -> smallDate(c, fmt(cal, "EEE, d MMM"), 500f, 48f, IVORY)
        }
    }

    private fun originTall(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val f = tf("sans-serif-thin")
            tall(c, hour(cal, h12), 380f, 310f, paint(400f, IVORY, f, Paint.Align.CENTER), 1.5f)
            tall(c, min(cal), 380f, 800f, paint(400f, accent, f, Paint.Align.CENTER), 1.5f)
        } else if (part == "date") {
            text(c, fmt(cal, "EEE  d MMM").uppercase(Locale.ENGLISH), 40f, 36f,
                paint(44f, IVORY, tf("sans-serif-light"), Paint.Align.LEFT, 0.3f, 210))
        }
    }

    private fun oneStack(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val p = paint(470f, IVORY, tf("sans-serif-black"), Paint.Align.CENTER)
            text(c, hour(cal, h12), 350f, 270f, p)
            text(c, min(cal), 350f, 700f, p)
        } else if (part == "date") {
            smallDate(c, fmt(cal, "EEE, MMM d"), 350f, 40f, IVORY)
        }
    }

    private fun oneWide(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(330f, IVORY, tf("sans-serif-black"))
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = p.measureText(h)
        val wc = p.measureText(":")
        val wm = p.measureText(m)
        val x0 = (1000f - (wh + wc + wm)) / 2f
        when (part) {
            "main" -> {
                text(c, h, x0, 280f, p)
                text(c, m, x0 + wh + wc, 280f, p)
            }
            "colon" -> text(c, ":", x0 + wh, 268f, p)
            "date" -> smallDate(c, fmt(cal, "EEE, MMM d"), 500f, 50f, IVORY, size = 56f)
        }
    }

    private fun colorosLong(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(380f, IVORY, tf("sans-serif-condensed"))
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = p.measureText(h)
        val wm = p.measureText(m)
        val gap = 130f
        val x0 = (1000f - (wh + gap + wm)) / 2f
        when (part) {
            "main" -> {
                tall(c, h, x0, 410f, p, 1.7f)
                tall(c, m, x0 + wh + gap, 410f, p, 1.7f)
            }
            "colon" -> {
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = IVORY }
                val cx = x0 + wh + gap / 2f
                c.drawCircle(cx, 410f - 105f, 20f, dot)
                c.drawCircle(cx, 410f + 105f, 20f, dot)
            }
            "date" -> smallDate(c, fmt(cal, "d MMM EEE"), 500f, 50f, IVORY, size = 56f)
        }
    }

    private fun colorosStack(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val f = tf("sans-serif-condensed-light")
            tall(c, hour(cal, h12), 320f, 320f, paint(420f, IVORY, f, Paint.Align.CENTER), 1.55f)
            tall(c, min(cal), 320f, 820f, paint(420f, accent, f, Paint.Align.CENTER), 1.55f)
        } else if (part == "date") {
            smallDate(c, fmt(cal, "d MMM EEE"), 320f, 40f, IVORY)
        }
    }

    private fun ios(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(400f, IVORY, tf("sans-serif-medium", Typeface.BOLD))
        val h = hour(cal, h12, false)
        val m = min(cal)
        val wh = p.measureText(h)
        val wc = p.measureText(":")
        val wm = p.measureText(m)
        val x0 = (1000f - (wh + wc + wm)) / 2f
        when (part) {
            "main" -> {
                tall(c, h, x0, 330f, p, 1.15f)
                tall(c, m, x0 + wh + wc, 330f, p, 1.15f)
            }
            "colon" -> tall(c, ":", x0 + wh, 318f, paint(400f, IVORY, tf("sans-serif-medium", Typeface.BOLD), Paint.Align.LEFT, 0f, 235), 1.15f)
            "date" -> smallDate(c, fmt(cal, "EEEE, d MMMM"), 500f, 55f, IVORY, size = 62f)
        }
    }

    private fun pixel(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val f = tf("sans-serif", Typeface.BOLD)
            text(c, hour(cal, h12), 380f, 290f, paint(460f, IVORY, f, Paint.Align.CENTER))
            val outline = paint(460f, accent, f, Paint.Align.CENTER).apply {
                style = Paint.Style.STROKE
                strokeWidth = 7f
            }
            text(c, min(cal), 380f, 750f, outline)
        } else if (part == "date") {
            smallDate(c, fmt(cal, "EEE, MMM d"), 40f, 40f, IVORY, Paint.Align.LEFT)
        }
    }

    private val DOTS = mapOf(
        '0' to listOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
        '1' to listOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
        '2' to listOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
        '3' to listOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
        '4' to listOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
        '5' to listOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
        '6' to listOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
        '7' to listOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
        '8' to listOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
        '9' to listOf("01110", "10001", "10001", "01111", "00001", "00010", "01100")
    )

    private fun dotDigit(c: Canvas, ch: Char, x0: Float, y0: Float, cell: Float, r: Float, p: Paint) {
        val rows = DOTS[ch] ?: return
        for ((ry, row) in rows.withIndex()) {
            for ((rx, v) in row.withIndex()) {
                if (v == '1') c.drawCircle(x0 + rx * cell + cell / 2f, y0 + ry * cell + cell / 2f, r, p)
            }
        }
    }

    private fun dot(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val cell = 36f
        val r = 15f
        val xs = 32f
        val y0 = 60f
        val h = hour(cal, h12)
        val m = min(cal)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = IVORY }
        when (part) {
            "main" -> {
                dotDigit(c, h[0], xs, y0, cell, r, p)
                dotDigit(c, h[1], xs + 216f, y0, cell, r, p)
                dotDigit(c, m[0], xs + 540f, y0, cell, r, p)
                dotDigit(c, m[1], xs + 756f, y0, cell, r, p)
            }
            "colon" -> {
                p.color = accent
                val cx = xs + 432f + 54f
                c.drawCircle(cx, y0 + 2 * cell + cell / 2f, r, p)
                c.drawCircle(cx, y0 + 4 * cell + cell / 2f, r, p)
            }
            "date" -> text(c, fmt(cal, "EEE · d MMM").uppercase(Locale.ENGLISH), 500f, 362f,
                paint(46f, accent, Typeface.create("monospace", Typeface.BOLD), Paint.Align.CENTER, 0.3f))
        }
    }

    private fun serifStack(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val f = Typeface.create("serif", Typeface.NORMAL)
            tall(c, hour(cal, h12), 350f, 300f, paint(380f, IVORY, f, Paint.Align.CENTER), 1.25f)
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accent
                strokeWidth = 3f
            }
            c.drawLine(290f, 555f, 410f, 555f, line)
            tall(c, min(cal), 350f, 810f, paint(380f, IVORY, f, Paint.Align.CENTER), 1.25f)
        } else if (part == "date") {
            text(c, fmt(cal, "EEEE · d MMM").uppercase(Locale.ENGLISH), 350f, 50f,
                paint(40f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.35f))
        }
    }

    private fun mono(c: Canvas, accent: Int, h12: Boolean, cal: Calendar, part: String) {
        val p = paint(300f, IVORY, Typeface.create("monospace", Typeface.BOLD))
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = p.measureText(h)
        val wc = p.measureText(":")
        val wm = p.measureText(m)
        val x0 = (1000f - (wh + wc + wm)) / 2f
        when (part) {
            "main" -> {
                text(c, h, x0, 175f, p)
                text(c, m, x0 + wh + wc, 175f, p)
            }
            "colon" -> text(c, ":", x0 + wh, 165f, paint(300f, accent, Typeface.create("monospace", Typeface.BOLD)))
            "date" -> text(c, "[ " + fmt(cal, "EEE d MMM").uppercase(Locale.ENGLISH) + " ]", 500f, 335f,
                paint(40f, accent, Typeface.create("monospace", Typeface.NORMAL), Paint.Align.CENTER, 0.2f))
        }
    }

    // ───────────── ColorOS 17 style tall condensed glass digits ─────────────

    private fun tallPaint(size: Float) =
        paint(size, IVORY, tf("sans-serif-condensed", Typeface.BOLD), Paint.Align.CENTER)

    /** Har digit ko fixed pitch par, ek dusre se chipka kar draw karta hai; total chaudai return karta hai. */
    private fun tallDigits(c: Canvas, s: String, xLeft: Float, cy: Float, p: Paint, sy: Float, sx: Float = 1f): Float {
        val pitch = p.measureText("0") * sx
        for ((i, ch) in s.withIndex()) {
            tall(c, ch.toString(), xLeft + (i + 0.5f) * pitch, cy, p, sy, sx)
        }
        return pitch * s.length
    }

    private fun ctallStack(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val p = tallPaint(420f)
            tallDigits(c, hour(cal, h12), 0f, 290f, p, 1.75f)
            tallDigits(c, min(cal), 0f, 850f, p, 1.75f)
        } else if (part == "date") {
            text(c, fmt(cal, "MMM d  EEE"), 800f, 62f,
                paint(56f, IVORY, tf("sans-serif-medium"), Paint.Align.RIGHT, 0.02f, 230))
        }
    }

    private fun ctallWide(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val p = tallPaint(430f)
        val pitch = p.measureText("0")
        val x0 = (1000f - pitch * 4) / 2f
        if (part == "main") {
            tallDigits(c, hour(cal, h12) + min(cal), x0, 405f, p, 1.55f)
        } else if (part == "date") {
            text(c, fmt(cal, "MMM d  EEE"), x0, 62f,
                paint(56f, IVORY, tf("sans-serif-medium"), Paint.Align.LEFT, 0.02f, 230))
        }
    }

    private fun ctallLeft(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            tallDigits(c, hour(cal, h12) + min(cal), 0f, 300f, tallPaint(430f), 1.55f)
        } else if (part == "date") {
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = IVORY
                alpha = 150
                strokeWidth = 3f
            }
            c.drawLine(0f, 600f, 860f, 600f, line)
            val dp = paint(64f, IVORY, tf("sans-serif-medium"), Paint.Align.LEFT, 0.02f, 235)
            text(c, fmt(cal, "MMM d"), 0f, 675f, dp)
            text(c, fmt(cal, "EEE"), 0f, 750f, dp)
        }
    }

    // ───────────── v2.0: Scenery & Eastern Aesthetics ─────────────

    private fun scenery(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        if (part == "main") {
            val p = paint(430f, IVORY, tf("sans-serif-condensed", Typeface.NORMAL), Paint.Align.CENTER)
            p.typeface = tf("sans-serif-thin", Typeface.NORMAL)
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = 7f
            tallDigits(c, hour(cal, h12), 350f, 380f, p, 1.9f, 0.82f)
            tallDigits(c, min(cal), 350f, 930f, p, 1.9f, 0.82f)
        } else if (part == "date") {
            text(c, fmt(cal, "MMM dd, EEE"), 350f, 60f,
                paint(54f, IVORY, tf("sans-serif"), Paint.Align.CENTER, 0.02f, 225))
        }
    }

    private fun eastern(c: Canvas, h12: Boolean, cal: Calendar, part: String) {
        val serif = tf("serif", Typeface.NORMAL)
        when (part) {
            "main" -> {
                val p = paint(190f, IVORY, serif, Paint.Align.CENTER)
                val h = hour(cal, h12)
                val m = min(cal)
                val gap = 150f
                val xs = floatArrayOf(500f - 3.4f * gap / 1.5f, 500f - 1.4f * gap / 1.5f,
                    500f + 1.4f * gap / 1.5f, 500f + 3.4f * gap / 1.5f)
                val all = h + m
                for (i in 0 until 4) text(c, all[i].toString(), xs[i], 300f, p)
            }
            "colon" -> {
                val l = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(214, 72, 52)
                    strokeWidth = 5f
                    strokeCap = Paint.Cap.ROUND
                }
                c.drawLine(500f, 255f, 500f, 345f, l)
            }
            "date" -> {
                text(c, fmt(cal, "EEEE").uppercase(Locale.ENGLISH), 500f, 120f,
                    paint(42f, IVORY, serif, Paint.Align.CENTER, 0.35f, 235))
                text(c, fmt(cal, "M/d"), 500f, 470f,
                    paint(42f, IVORY, serif, Paint.Align.CENTER, 0.05f, 225))
            }
        }
    }
}
