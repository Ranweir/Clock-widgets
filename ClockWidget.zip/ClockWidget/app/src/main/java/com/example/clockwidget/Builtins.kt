package com.example.clockwidget

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Built-in clock designs, sab Canvas se bane hain (design space = w x h). */
object Builtins {
    class Spec(val id: String, val name: String, val kind: String, val w: Int, val h: Int)

    val list = listOf(
        Spec("b:bold", "Noir Bold", "Digital", 1000, 470),
        Spec("b:thin", "Thin Stack", "Digital", 700, 980),
        Spec("b:serif", "Serif Luxe", "Digital", 1000, 440),
        Spec("b:split", "Split Tone", "Digital", 1000, 420),
        Spec("b:date", "Date Focus", "Digital", 1200, 560),
        Spec("b:analog", "Classic Dial", "Analog", 800, 800),
        Spec("b:ring", "Ring Minimal", "Analog", 800, 800)
    )

    fun spec(id: String) = list.firstOrNull { it.id == id }

    private val IVORY = Pal.IVORY

    private fun paint(
        size: Float, color: Int, tf: Typeface,
        align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f, alpha: Int = 255
    ) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        this.alpha = alpha
        typeface = tf
        textAlign = align
        letterSpacing = spacing
    }

    /** Text ko bounds ke hisaab se vertical center me draw karta hai. */
    private fun text(c: Canvas, s: String, x: Float, cy: Float, p: Paint) {
        val r = Rect()
        p.getTextBounds(s, 0, s.length, r)
        c.drawText(s, x, cy - (r.top + r.bottom) / 2f, p)
    }

    private fun tf(name: String, style: Int = Typeface.NORMAL) = Typeface.create(name, style)

    private fun two(n: Int) = if (n < 10) "0$n" else "$n"

    private fun hour(cal: Calendar, h12: Boolean, pad: Boolean = true): String {
        var h = cal.get(Calendar.HOUR_OF_DAY)
        if (h12) {
            h %= 12
            if (h == 0) h = 12
        }
        return if (pad) two(h) else h.toString()
    }

    private fun min(cal: Calendar) = two(cal.get(Calendar.MINUTE))

    private fun fmt(cal: Calendar, f: String) = SimpleDateFormat(f, Locale.ENGLISH).format(cal.time)

    fun draw(id: String, c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        when (id) {
            "b:bold" -> bold(c, accent, h12, cal)
            "b:thin" -> thin(c, accent, h12, cal)
            "b:serif" -> serif(c, accent, h12, cal)
            "b:split" -> split(c, accent, h12, cal)
            "b:date" -> dateFocus(c, accent, h12, cal)
            "b:analog" -> analog(c, accent, cal)
            "b:ring" -> ring(c, accent, cal)
        }
    }

    private fun bold(c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        val f = tf("sans-serif-condensed", Typeface.BOLD)
        val pi = paint(340f, IVORY, f)
        val pa = paint(340f, accent, f)
        val h = hour(cal, h12)
        val m = min(cal)
        val gap = 14f
        val wh = pi.measureText(h)
        val wc = pa.measureText(":")
        val wm = pi.measureText(m)
        var x = (1000f - (wh + wc + wm + gap * 2)) / 2f
        text(c, h, x, 195f, pi)
        x += wh + gap
        text(c, ":", x, 185f, pa)
        x += wc + gap
        text(c, m, x, 195f, pi)
        text(c, fmt(cal, "EEE  ·  d MMM").uppercase(Locale.ENGLISH), 500f, 425f,
            paint(52f, IVORY, tf("sans-serif-medium"), Paint.Align.CENTER, 0.28f, 200))
    }

    private fun thin(c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        val f = tf("sans-serif-thin")
        text(c, fmt(cal, "EEE  d MMM").uppercase(Locale.ENGLISH), 350f, 28f,
            paint(50f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.3f))
        text(c, hour(cal, h12), 350f, 300f, paint(560f, IVORY, f, Paint.Align.CENTER))
        text(c, min(cal), 350f, 760f, paint(560f, accent, f, Paint.Align.CENTER))
    }

    private fun serif(c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        text(c, fmt(cal, "EEEE  ·  d MMMM").uppercase(Locale.ENGLISH), 500f, 28f,
            paint(40f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.35f))
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            strokeWidth = 3f
        }
        c.drawLine(420f, 88f, 580f, 88f, line)
        val t = hour(cal, h12, false) + ":" + min(cal)
        text(c, t, 500f, 245f, paint(300f, IVORY, Typeface.create("serif", Typeface.NORMAL), Paint.Align.CENTER))
        if (h12) {
            text(c, fmt(cal, "a").uppercase(Locale.ENGLISH), 500f, 410f,
                paint(40f, accent, tf("sans-serif-medium"), Paint.Align.CENTER, 0.4f))
        }
    }

    private fun split(c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        val f = tf("sans-serif-thin")
        val ph = paint(380f, accent, f)
        val pm = paint(380f, IVORY, f)
        val h = hour(cal, h12)
        val m = min(cal)
        val wh = ph.measureText(h)
        val wm = pm.measureText(m)
        val x0 = (1000f - (wh + 50f + wm)) / 2f
        text(c, fmt(cal, "MMM dd  EEE"), x0, 26f,
            paint(54f, IVORY, tf("sans-serif-light"), Paint.Align.LEFT, 0.05f, 210))
        text(c, h, x0, 235f, ph)
        text(c, m, x0 + wh + 50f, 235f, pm)
    }

    private fun dateFocus(c: Canvas, accent: Int, h12: Boolean, cal: Calendar) {
        val day = cal.get(Calendar.DAY_OF_MONTH).toString()
        text(c, day, 260f, 280f, paint(460f, accent, tf("sans-serif-thin"), Paint.Align.CENTER))
        val x0 = 580f
        text(c, fmt(cal, "EEEE").uppercase(Locale.ENGLISH), x0, 140f,
            paint(90f, IVORY, tf("sans-serif-light"), Paint.Align.LEFT, 0.12f))
        text(c, fmt(cal, "MMMM yyyy").uppercase(Locale.ENGLISH), x0, 235f,
            paint(46f, IVORY, tf("sans-serif-medium"), Paint.Align.LEFT, 0.3f, 190))
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            strokeWidth = 3f
        }
        c.drawLine(x0, 300f, x0 + 120f, 300f, line)
        val t = hour(cal, h12) + ":" + min(cal)
        text(c, t, x0, 410f, paint(170f, IVORY, tf("sans-serif-thin"), Paint.Align.LEFT))
    }

    private fun hand(c: Canvas, angle: Float, from: Float, to: Float, width: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = width
            strokeCap = Paint.Cap.ROUND
        }
        c.save()
        c.rotate(angle, 400f, 400f)
        c.drawLine(400f, 400f + from, 400f, 400f - to, p)
        c.restore()
    }

    private fun analog(c: Canvas, accent: Int, cal: Calendar) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
        c.drawCircle(400f, 400f, 380f, fill)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        c.drawCircle(400f, 400f, 377f, ring)

        for (i in 0 until 60) {
            val big = i % 5 == 0
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (big) accent else IVORY
                alpha = if (big) 255 else 130
                strokeWidth = if (big) 8f else 3f
            }
            c.save()
            c.rotate(i * 6f, 400f, 400f)
            c.drawLine(400f, 44f, 400f, 44f + if (big) 34f else 14f, p)
            c.restore()
        }
        val np = paint(78f, IVORY, tf("sans-serif-light"), Paint.Align.CENTER)
        text(c, "12", 400f, 130f, np)
        text(c, "3", 670f, 400f, np)
        text(c, "6", 400f, 670f, np)
        text(c, "9", 130f, 400f, np)

        val h = cal.get(Calendar.HOUR_OF_DAY) % 12
        val m = cal.get(Calendar.MINUTE)
        hand(c, (h + m / 60f) * 30f, 30f, 190f, 24f, IVORY)
        hand(c, m * 6f, 30f, 300f, 14f, IVORY)
        val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
        c.drawCircle(400f, 400f, 20f, cap)
        cap.color = Pal.BG
        c.drawCircle(400f, 400f, 7f, cap)
    }

    private fun ring(c: Canvas, accent: Int, cal: Calendar) {
        val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = IVORY
            alpha = 220
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        c.drawCircle(400f, 400f, 376f, rp)
        for (i in 0 until 12) {
            val big = i % 3 == 0
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (big) accent else IVORY
                alpha = if (big) 255 else 170
                strokeWidth = 6f
                strokeCap = Paint.Cap.ROUND
            }
            c.save()
            c.rotate(i * 30f, 400f, 400f)
            c.drawLine(400f, 50f, 400f, 50f + if (big) 46f else 20f, p)
            c.restore()
        }
        text(c, fmt(cal, "EEE  d").uppercase(Locale.ENGLISH), 400f, 580f,
            paint(46f, IVORY, tf("sans-serif-medium"), Paint.Align.CENTER, 0.3f, 200))
        val h = cal.get(Calendar.HOUR_OF_DAY) % 12
        val m = cal.get(Calendar.MINUTE)
        hand(c, (h + m / 60f) * 30f, 0f, 210f, 28f, IVORY)
        hand(c, m * 6f, 0f, 310f, 14f, accent)
        val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = IVORY }
        c.drawCircle(400f, 400f, 16f, cap)
        cap.color = Pal.BG
        c.drawCircle(400f, 400f, 6f, cap)
    }
}
