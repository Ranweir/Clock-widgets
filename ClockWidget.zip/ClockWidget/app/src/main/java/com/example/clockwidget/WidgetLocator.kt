package com.example.clockwidget

import android.accessibilityservice.AccessibilityService
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Sirf ek kaam: launcher me hamare widget ka ImageView (id: clock_img) dhoondhna aur uski screen position
 * nikalna, taaki blur/glow wahi wallpaper hissa use kare jo widget ke peeche hai.
 * Koi text / dusre app ka data padha, save ya bheja nahi jaata.
 */
class WidgetLocator : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var home: Set<String> = emptySet()
    private val scanRun = Runnable { scan() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        home = homePackages()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in home) return
        // scroll/animation ruke tab hi scan (debounce)
        handler.removeCallbacks(scanRun)
        handler.postDelayed(scanRun, 450)
    }

    override fun onInterrupt() {}

    private fun homePackages(): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
    }

    private fun scan() {
        val root = try { rootInActiveWindow } catch (t: Throwable) { null } ?: return
        try {
            if (root.packageName?.toString() !in home) return
            val nodes = root.findAccessibilityNodeInfosByViewId("$packageName:id/clock_img")
            if (nodes.isNullOrEmpty()) return
            val (sw, sh) = WallStore.screenSize(this)
            val rects = ArrayList<Rect>()
            for (n in nodes) {
                val r = Rect()
                n.getBoundsInScreen(r)
                // scroll ke beech ka aadha-dikhta widget skip
                if (r.width() > 40 && r.height() > 40 && r.left >= 0 && r.top >= 0 && r.right <= sw && r.bottom <= sh) rects.add(r)
            }
            if (rects.isNotEmpty()) apply(this, rects, sw, sh)
        } finally {
            root.recycle()
        }
    }

    private fun apply(ctx: Context, rects: List<Rect>, sw: Int, sh: Int) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = ClockWidgetProvider.ids(ctx).toMutableList()
        for (r in rects) {
            if (ids.isEmpty()) break
            // size se sabse milta widget id chuno (ek se zyada widget hone par)
            val id = ids.minByOrNull {
                val (w, h) = ClockWidgetProvider.sizeFor(ctx, mgr, it)
                abs(w - r.width()) + abs(h - r.height())
            } ?: break
            ids.remove(id)
            val cfg = Prefs.widget(ctx, id) ?: continue
            val spanX = sw - r.width()
            val spanY = sh - r.height()
            val x = if (spanX > 2) (r.left * 100f / spanX).toInt().coerceIn(0, 100) else 50
            val y = if (spanY > 2) (r.top * 100f / spanY).toInt().coerceIn(0, 100) else 50
            if (abs(x - cfg.wallX) >= 1 || abs(y - cfg.wallY) >= 1) {
                Prefs.setWidget(ctx, id, cfg.copy(wallX = x, wallY = y))
                ClockWidgetProvider.refreshOne(ctx, mgr, id)
            }
        }
    }

    companion object {
        /** Accessibility service on hai? */
        fun enabled(ctx: Context): Boolean {
            val v = android.provider.Settings.Secure.getString(
                ctx.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return v.split(':').any { it.contains(ctx.packageName + "/") && it.endsWith("WidgetLocator") }
        }
    }
}
