package com.example.clockwidget

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File

data class KwgtInfo(val id: String, val name: String, val locked: Boolean = false)

/** Import kiye hue KWGT (.kwgt) widgets: filesDir/kwgt/<id>/preset.json (+ bitmaps/, fonts/ ...). */
object KwgtStore {
    private fun base(ctx: Context) = File(ctx.filesDir, "kwgt")

    fun findPreset(dir: File, depth: Int = 0): File? {
        if (File(dir, "preset.json").exists()) return dir
        if (depth >= 3) return null
        return dir.listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("__MACOSX") }
            ?.sortedBy { it.name }
            ?.firstNotNullOfOrNull { findPreset(it, depth + 1) }
    }

    fun list(ctx: Context): List<KwgtInfo> =
        base(ctx).listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("_") && findPreset(it) != null }
            ?.sortedBy { it.name }
            ?.map { d ->
                val n = File(d, "name.txt").takeIf { it.exists() }?.readText()?.trim()
                KwgtInfo(d.name, if (n.isNullOrEmpty()) d.name else n, findPreset(d)?.let { KwgtRenderer.isLocked(it) } ?: false)
            } ?: emptyList()

    fun name(ctx: Context, id: String): String? = list(ctx).firstOrNull { it.id == id }?.name

    fun root(ctx: Context, id: String): File? {
        if (!id.matches(Regex("[A-Za-z0-9_]+"))) return null
        val d = File(base(ctx), id)
        return if (d.isDirectory) findPreset(d) else null
    }

    fun delete(ctx: Context, id: String) {
        if (id.matches(Regex("[A-Za-z0-9_]+"))) File(base(ctx), id).deleteRecursively()
    }

    private fun cleanName(raw: String): String {
        var n = raw.substringBeforeLast('.', raw)
        n = n.replace('_', ' ').replace('-', ' ').trim()
        return if (n.isEmpty()) "KWGT widget" else n
    }

    /** .kwgt (zip) ya seedha preset.json import karke naya id return karta hai. */
    fun import(ctx: Context, uri: Uri, displayName: String): String {
        val id = "k" + System.currentTimeMillis()
        val tmp = File(base(ctx), "_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val raw = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the file")
        try {
            BufferedInputStream(raw).use { input ->
                input.mark(8)
                val b0 = input.read()
                val b1 = input.read()
                input.reset()
                if (b0 == 'P'.code && b1 == 'K'.code) {
                    ThemeStore.unzip(input, tmp, Counter())
                } else {
                    // seedha JSON (preset.json) bhi chalega
                    val text = input.readBytes().toString(Charsets.UTF_8)
                    if (!text.trimStart().startsWith("{")) throw IllegalStateException("This is not a .kwgt file")
                    File(tmp, "preset.json").writeText(text)
                }
            }
        } catch (e: java.util.zip.ZipException) {
            tmp.deleteRecursively()
            throw IllegalStateException("This file is not a valid .kwgt (zip)")
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        }

        val rootDir = findPreset(tmp)
        if (rootDir == null) {
            tmp.deleteRecursively()
            throw IllegalStateException("No preset.json found. Is this a KWGT widget (.kwgt)? KLWP wallpapers (.klwp) are not supported.")
        }
        if (KwgtRenderer.isLocked(rootDir)) {
            tmp.deleteRecursively()
            throw IllegalStateException("This widget is locked by its author, so it only works inside the KWGT app and cannot be used here. Please import an unlocked .kwgt file.")
        }
        val title = KwgtRenderer.titleOf(rootDir)
        File(tmp, "name.txt").writeText(title ?: cleanName(displayName))
        val dst = File(base(ctx), id)
        if (!tmp.renameTo(dst)) {
            tmp.deleteRecursively()
            throw IllegalStateException("Could not save the widget")
        }
        return id
    }
}
