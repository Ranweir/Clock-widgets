package com.example.clockwidget

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sqrt

/**
 * KWGT (Kustom) formula engine: text ke andar `$ ... $` wale hisse evaluate karta hai.
 * Pure Kotlin (Android par depend nahi), taaki alag se test ho sake.
 *
 * Supported: df, tc, if, mu (+ math funcs), gv, bi, ce, aur + - * / % == != < > && || operators.
 * Unsupported functions (weather, music, notifications ...) khali / "--" dete hain; crash nahi.
 */
class KwgtFormula(
    private val now: () -> Calendar = { Calendar.getInstance() },
    /** Global variable (gv) ki value; null = nahi mili. */
    private val global: (String) -> String? = { null },
    /** Battery info (bi): level, charging, temp ... */
    private val battery: (String) -> String? = { null }
) {
    /** `$expr$` wale hisse evaluate karke poora text return karta hai. */
    fun evalText(s: String): String {
        if (s.indexOf('$') < 0) return stripTags(s)
        val sb = StringBuilder()
        val parts = s.split('$')
        for ((i, p) in parts.withIndex()) {
            if (i % 2 == 0) sb.append(p)
            else sb.append(try { str(evalArg(p)) } catch (e: Exception) { "" })
        }
        return stripTags(sb.toString())
    }

    private val tagRe = Regex("\\[/?(b|i|s|u|c|f|sz|bg|bgc|fg)(=[^\\]]*)?]")
    private fun stripTags(s: String): String = if (s.indexOf('[') < 0) s else tagRe.replace(s, "")

    // ───────────── values ─────────────
    private fun num(v: Any?): Double? = when (v) {
        is Double -> v
        is Number -> v.toDouble()
        is String -> v.trim().toDoubleOrNull()
        is Boolean -> if (v) 1.0 else 0.0
        else -> null
    }

    private fun truthy(v: Any?): Boolean = when (v) {
        is Double -> v != 0.0
        is Boolean -> v
        is String -> { val t = v.trim(); t.isNotEmpty() && t != "0" && !t.equals("false", true) }
        else -> false
    }

    fun str(v: Any?): String = when (v) {
        null -> ""
        is Double -> fmt(v)
        is Boolean -> if (v) "1" else "0"
        else -> v.toString()
    }

    private fun fmt(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return ""
        if (d == floor(d) && abs(d) < 1e15) return d.toLong().toString()
        var t = String.format(Locale.US, "%.6f", d)
        t = t.trimEnd('0').trimEnd('.')
        return t
    }

    // ───────────── parser ─────────────
    private sealed class N {
        class Lit(val v: Any) : N()
        class Call(val name: String, val args: List<String>) : N()
        class Bin(val op: String, val l: N, val r: N) : N()
        class Un(val op: Char, val n: N) : N()
    }

    private class Parser(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i] == ' ') i++ }
        fun atEnd(): Boolean { ws(); return i >= s.length }

        fun expr(minPrec: Int = 0): N {
            var left = primary()
            while (true) {
                ws()
                val op = peekOp() ?: break
                val prec = prec(op)
                if (prec < minPrec) break
                i += op.length
                val right = expr(prec + 1)
                left = N.Bin(op, left, right)
            }
            return left
        }

        private fun prec(op: String) = when (op) {
            "||" -> 1
            "&&" -> 2
            "==", "=", "!=", "<>", "<", ">", "<=", ">=" -> 3
            "+", "-" -> 4
            else -> 5
        }

        private fun peekOp(): String? {
            if (i >= s.length) return null
            val two = if (i + 1 < s.length) s.substring(i, i + 2) else ""
            if (two in listOf("||", "&&", "==", "!=", "<>", "<=", ">=")) return two
            val c = s[i]
            return if (c in "+-*/%=<>") c.toString() else null
        }

        private fun isWordChar(c: Char) = c.isLetterOrDigit() || c == '_' || c == '.' || c == '#' || c == ':'

        private fun primary(): N {
            ws()
            if (i >= s.length) throw IllegalArgumentException("end")
            val c = s[i]
            if (c == '(') {
                i++
                val e = expr()
                ws()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException(")")
                i++
                return e
            }
            if (c == '"' || c == '\'') {
                i++
                val st = i
                while (i < s.length && s[i] != c) i++
                if (i >= s.length) throw IllegalArgumentException("quote")
                val t = s.substring(st, i)
                i++
                return N.Lit(t)
            }
            if (c == '-' || c == '!') {
                i++
                return N.Un(c, primary())
            }
            if (isWordChar(c)) {
                val st = i
                while (i < s.length && isWordChar(s[i])) i++
                val w = s.substring(st, i)
                if (i < s.length && s[i] == '(') {
                    val close = matching(s, i)
                    val raw = s.substring(i + 1, close)
                    i = close + 1
                    return N.Call(w.lowercase(), splitArgs(raw))
                }
                w.toDoubleOrNull()?.let { return N.Lit(it) }
                return N.Lit(w)
            }
            throw IllegalArgumentException("unexpected $c")
        }

        companion object {
            /** s[open] == '(' ka jodidaar ')' ka index. */
            fun matching(s: String, open: Int): Int {
                var depth = 0
                var q = 0.toChar()
                var j = open
                while (j < s.length) {
                    val ch = s[j]
                    if (q != 0.toChar()) { if (ch == q) q = 0.toChar() }
                    else if (ch == '"' || ch == '\'') q = ch
                    else if (ch == '(') depth++
                    else if (ch == ')') { depth--; if (depth == 0) return j }
                    j++
                }
                throw IllegalArgumentException("unbalanced")
            }

            fun splitArgs(raw: String): List<String> {
                val out = ArrayList<String>()
                var depth = 0
                var q = 0.toChar()
                var st = 0
                for (j in raw.indices) {
                    val ch = raw[j]
                    if (q != 0.toChar()) { if (ch == q) q = 0.toChar() }
                    else if (ch == '"' || ch == '\'') q = ch
                    else if (ch == '(') depth++
                    else if (ch == ')') depth--
                    else if (ch == ',' && depth == 0) { out.add(raw.substring(st, j)); st = j + 1 }
                }
                out.add(raw.substring(st))
                return if (out.size == 1 && out[0].isBlank()) emptyList() else out
            }
        }
    }

    /** Argument: pehle expression ki tarah, na ban sake to seedha text ("hh:mm a" jaise). */
    private fun evalArg(raw: String): Any? {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        return try {
            val p = Parser(t)
            val n = p.expr()
            if (!p.atEnd()) t else eval(n)
        } catch (e: Exception) {
            t
        }
    }

    private fun raw(a: String): String {
        val t = a.trim()
        return if (t.length >= 2 && (t[0] == '"' || t[0] == '\'') && t.last() == t[0]) t.substring(1, t.length - 1) else t
    }

    // ───────────── evaluator ─────────────
    private fun eval(n: N): Any? = when (n) {
        is N.Lit -> n.v
        is N.Un -> if (n.op == '-') (num(eval(n.n))?.let { -it } ?: "") else (if (truthy(eval(n.n))) 0.0 else 1.0)
        is N.Bin -> bin(n.op, eval(n.l), eval(n.r))
        is N.Call -> call(n.name, n.args)
    }

    private fun bin(op: String, a: Any?, b: Any?): Any? {
        val x = num(a)
        val y = num(b)
        when (op) {
            "&&" -> return if (truthy(a) && truthy(b)) 1.0 else 0.0
            "||" -> return if (truthy(a) || truthy(b)) 1.0 else 0.0
            "==", "=", "!=", "<>" -> {
                val eq = if (x != null && y != null) x == y else str(a).equals(str(b), true)
                return if ((op == "!=" || op == "<>") != eq) 1.0 else 0.0
            }
            "<", ">", "<=", ">=" -> {
                val c = if (x != null && y != null) x.compareTo(y) else str(a).compareTo(str(b), true)
                val r = when (op) { "<" -> c < 0; ">" -> c > 0; "<=" -> c <= 0; else -> c >= 0 }
                return if (r) 1.0 else 0.0
            }
        }
        if (x == null || y == null) {
            // text par arithmetic: "+" jodta hai; baaki operator text me hi rehte hain (jaise dd-MM)
            return str(a) + op + str(b)
        }
        return when (op) {
            "+" -> x + y
            "-" -> x - y
            "*" -> x * y
            "/" -> if (y == 0.0) 0.0 else x / y
            "%" -> if (y == 0.0) 0.0 else x % y
            else -> ""
        }
    }

    private fun arg(a: List<String>, i: Int): Any? = if (i < a.size) evalArg(a[i]) else null
    private fun argN(a: List<String>, i: Int): Double? = num(arg(a, i))

    private fun call(name: String, a: List<String>): Any? {
        when (name) {
            "df" -> {
                if (a.isEmpty()) return ""
                val cal = Calendar.getInstance()
                cal.timeInMillis = now().timeInMillis
                // format me comma ho sakta hai ("EEEE, dd MMMM"); aakhri argument sirf tab timestamp hai jab wo number ho
                var fmtParts = a
                if (a.size >= 2) {
                    val ts = num(a.last().trim())
                    if (ts != null) { cal.timeInMillis = (ts * 1000).toLong(); fmtParts = a.dropLast(1) }
                }
                val f = raw(fmtParts.joinToString(","))
                return try { SimpleDateFormat(f, Locale.getDefault()).format(cal.time) } catch (e: Exception) { "" }
            }
            "tc" -> return tc(a)
            "if" -> {
                var i = 0
                while (i + 1 < a.size) {
                    if (truthy(arg(a, i))) return arg(a, i + 1)
                    i += 2
                }
                return if (i < a.size) arg(a, i) else ""
            }
            "mu" -> return if (a.isEmpty()) "" else (num(arg(a, 0)) ?: "")
            "gv" -> return global(raw(a.getOrElse(0) { "" })) ?: ""
            "bi" -> return battery(raw(a.getOrElse(0) { "" }).lowercase()) ?: "0"
            "ce" -> return ce(a)
            // math (mu ke andar bhi chalte hain)
            "abs" -> return argN(a, 0)?.let { abs(it) } ?: ""
            "ceil" -> return argN(a, 0)?.let { ceil(it) } ?: ""
            "floor" -> return argN(a, 0)?.let { floor(it) } ?: ""
            "round" -> return argN(a, 0)?.let { it.roundToLong().toDouble() } ?: ""
            "sqrt" -> return argN(a, 0)?.let { sqrt(it) } ?: ""
            "pow" -> { val x = argN(a, 0); val y = argN(a, 1); return if (x != null && y != null) x.pow(y) else "" }
            "min" -> { val x = argN(a, 0); val y = argN(a, 1); return if (x != null && y != null) min(x, y) else "" }
            "max" -> { val x = argN(a, 0); val y = argN(a, 1); return if (x != null && y != null) max(x, y) else "" }
            "sin" -> return argN(a, 0)?.let { Math.sin(Math.toRadians(it)) } ?: ""
            "cos" -> return argN(a, 0)?.let { Math.cos(Math.toRadians(it)) } ?: ""
            // weather: is app me nahi hai
            "wi", "wf" -> return "--"
            // music, notifications, system, location, ... : khali
            else -> return ""
        }
    }

    private fun tc(a: List<String>): Any? {
        if (a.isEmpty()) return ""
        val op = raw(a[0]).lowercase()
        val t = str(arg(a, 1))
        return when (op) {
            "up" -> t.uppercase()
            "low" -> t.lowercase()
            "cap", "cap2" -> t.split(' ').joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }
            "len" -> t.length.toDouble()
            "cut" -> {
                val st = (argN(a, 2) ?: 0.0).toInt().coerceIn(0, t.length)
                val ln = argN(a, 3)?.toInt()
                if (ln == null) t.substring(st) else t.substring(st, (st + ln).coerceIn(st, t.length))
            }
            "ell" -> {
                val ln = (argN(a, 2) ?: t.length.toDouble()).toInt()
                if (t.length <= ln) t else t.substring(0, max(0, ln - 1)) + "…"
            }
            "split" -> {
                val d = raw(a.getOrElse(2) { "," })
                val idx = (argN(a, 3) ?: 0.0).toInt()
                t.split(d).getOrElse(idx) { "" }
            }
            "lpad" -> { val ln = (argN(a, 2) ?: 0.0).toInt(); val ch = str(arg(a, 3)).ifEmpty { "0" }; t.padStart(ln, ch[0]) }
            "rpad" -> { val ln = (argN(a, 2) ?: 0.0).toInt(); val ch = str(arg(a, 3)).ifEmpty { " " }; t.padEnd(ln, ch[0]) }
            "reg" -> try {
                val m = Regex(raw(a.getOrElse(2) { "" })).find(t)
                m?.groupValues?.getOrElse((argN(a, 3) ?: 0.0).toInt()) { "" } ?: ""
            } catch (e: Exception) { "" }
            else -> t
        }
    }

    /** ce(color, op, value): alpha (0-100) aur lum (-100..100) support. */
    private fun ce(a: List<String>): Any? {
        val col = str(arg(a, 0))
        val c = parseColor(col) ?: return col
        val op = raw(a.getOrElse(1) { "" }).lowercase()
        val v = argN(a, 2) ?: return col
        var al = (c ushr 24) and 0xFF
        var r = (c shr 16) and 0xFF
        var g = (c shr 8) and 0xFF
        var b = c and 0xFF
        when (op) {
            "alpha" -> al = (v / 100.0 * 255).toInt().coerceIn(0, 255)
            "lum" -> {
                val f = 1.0 + v / 100.0
                r = (r * f).toInt().coerceIn(0, 255); g = (g * f).toInt().coerceIn(0, 255); b = (b * f).toInt().coerceIn(0, 255)
            }
            else -> return col
        }
        return String.format("#%02X%02X%02X%02X", al, r, g, b)
    }

    companion object {
        /** "#AARRGGBB", "#RRGGBB", "#RGB" -> ARGB int (null = galat). */
        fun parseColor(s: String): Int? {
            val t = s.trim()
            if (!t.startsWith("#")) return null
            val h = t.substring(1)
            return try {
                when (h.length) {
                    8 -> h.toLong(16).toInt()
                    6 -> (0xFF000000L or h.toLong(16)).toInt()
                    3 -> {
                        val r = h.substring(0, 1).repeat(2); val g = h.substring(1, 2).repeat(2); val b = h.substring(2, 3).repeat(2)
                        (0xFF000000L or "$r$g$b".toLong(16)).toInt()
                    }
                    else -> null
                }
            } catch (e: NumberFormatException) {
                null
            }
        }
    }
}
