package com.example.clockwidget

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0, dashed: Boolean = false) =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) {
            if (dashed) setStroke(dp(strokeDp), strokeColor, dp(6).toFloat(), dp(4).toFloat())
            else setStroke(dp(strokeDp), strokeColor)
        }
    }

/** Preview ke peeche ka gehra gradient (taaki safed clock saaf dikhe). */
fun Context.previewBackdrop(radiusDp: Int) = GradientDrawable(
    GradientDrawable.Orientation.TL_BR,
    intArrayOf(0xFF232B4A.toInt(), 0xFF10121F.toInt(), 0xFF07070C.toInt())
).apply { cornerRadius = dp(radiusDp).toFloat() }

fun Context.tv(
    text: String, sp: Float, color: Int,
    tf: Typeface = Typeface.DEFAULT, spacing: Float = 0f
) = TextView(this).apply {
    this.text = text
    textSize = sp
    setTextColor(color)
    typeface = tf
    letterSpacing = spacing
    includeFontPadding = false
}

fun Context.label(text: String) =
    tv(text.uppercase(), 11f, Pal.GOLD, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.22f)

fun Context.serif(text: String, sp: Float, color: Int = Pal.IVORY) =
    tv(text, sp, color, Typeface.create("serif", Typeface.NORMAL), 0.01f)

fun Context.circleButton(symbol: String, onClick: () -> Unit) = TextView(this).apply {
    text = symbol
    textSize = 20f
    setTextColor(Pal.GOLD)
    gravity = Gravity.CENTER
    background = rounded(Pal.SURFACE2, 22, Pal.STROKE, 1)
    layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
    setOnClickListener { onClick() }
}

fun Context.pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
    this.text = text.uppercase()
    textSize = 13f
    letterSpacing = 0.16f
    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    gravity = Gravity.CENTER
    setTextColor(if (filled) Pal.BG else Pal.GOLD)
    background = if (filled) rounded(Pal.GOLD, 28) else rounded(0, 28, Pal.GOLD, 1)
    setPadding(dp(22), dp(16), dp(22), dp(16))
    setOnClickListener { onClick() }
}

fun Context.spacer(heightDp: Int) = View(this).apply {
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
}
