package com.example.clockwidget

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0, dashed: Boolean = false) =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) {
            if (dashed) setStroke(dp(strokeDp), strokeColor, dp(6).toFloat(), dp(4).toFloat())
            else setStroke(dp(strokeDp), strokeColor)
        }
    }

/** Preview ke peeche ka gehra gradient (taaki safed clock saaf dikhe). */
fun Context.previewBackdrop(radiusDp: Int) = GradientDrawable(
    GradientDrawable.Orientation.TL_BR,
    intArrayOf(0xFF232B4A.toInt(), 0xFF10121F.toInt(), 0xFF07070C.toInt())
).apply { cornerRadius = dp(radiusDp).toFloat() }

fun Context.tv(
    text: String, sp: Float, color: Int,
    tf: Typeface = Typeface.DEFAULT, spacing: Float = 0f
) = TextView(this).apply {
    this.text = text
    textSize = sp
    setTextColor(color)
    typeface = tf
    letterSpacing = spacing
    includeFontPadding = false
}

fun Context.label(text: String) =
    tv(text.uppercase(), 11f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.22f)

fun Context.serif(text: String, sp: Float, color: Int = Pal.uTitle) =
    tv(text, sp, color, Typeface.create("serif", Typeface.NORMAL), 0.01f)

fun Context.circleButton(symbol: String, onClick: () -> Unit) = TextView(this).apply {
    text = symbol
    textSize = 20f
    setTextColor(Pal.uGold)
    gravity = Gravity.CENTER
    background = rounded(Pal.uSurface2, 22, Pal.uStroke, 1)
    layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
    setOnClickListener { onClick() }
    pressFeedback(0.9f)
}

fun Context.pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
    this.text = text.uppercase()
    textSize = 13f
    letterSpacing = 0.16f
    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    gravity = Gravity.CENTER
    setTextColor(if (filled) Pal.uOnGold else Pal.uGold)
    background = if (filled) rounded(Pal.uGold, 28) else rounded(0, 28, Pal.uGold, 1)
    setPadding(dp(22), dp(16), dp(22), dp(16))
    setOnClickListener { onClick() }
    pressFeedback(0.96f)
}

fun Context.spacer(heightDp: Int) = View(this).apply {
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
}

/** Tap par halka dab ke wapas "pop" hota hai (click / long-click par asar nahi). */
@android.annotation.SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback(down: Float = 0.965f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(down).scaleY(down).setDuration(110)
                    .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(320)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
        }
        false
    }
}
