package com.example.clockwidget

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

data class ThemeInfo(val id: String, val name: String)

class Counter { var n = 0L }

/** Import ki hui Xiaomi themes: filesDir/themes/<id>/ */
object ThemeStore {
    private const val MAX_BYTES = 150L * 1024 * 1024

    private fun base(ctx: Context) = File(ctx.filesDir, "themes")

    fun list(ctx: Context): List<ThemeInfo> =
        base(ctx).listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("_") && findRoot(it) != null }
            ?.sortedBy { it.name }
            ?.map { d ->
                val n = File(d, "name.txt").takeIf { it.exists() }?.readText()?.trim()
                ThemeInfo(d.name, if (n.isNullOrEmpty()) d.name else n)
            } ?: emptyList()

    fun name(ctx: Context, id: String): String? = list(ctx).firstOrNull { it.id == id }?.name

    fun findRoot(dir: File, depth: Int = 0): File? {
        if (File(dir, "manifest.xml").exists()) return dir
        if (depth >= 4) return null
        return dir.listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("__MACOSX") }
            ?.sortedBy { it.name }
            ?.firstNotNullOfOrNull { findRoot(it, depth + 1) }
    }

    /** Built-in Xiaomi themes (assets/themes/<id>) — import ki zaroorat nahi. */
    fun isBundled(id: String) = id.startsWith("xiaomi_")

    fun installBundled(ctx: Context) {
        try {
            val ids = ctx.assets.list("themes") ?: return
            for (id in ids) {
                val dst = File(base(ctx), id)
                val marker = File(dst, ".v")
                if (marker.exists() && marker.readText() == BUNDLED_VERSION) continue
                dst.deleteRecursively()
                copyAsset(ctx, "themes/$id", dst)
                marker.writeText(BUNDLED_VERSION)
            }
        } catch (e: Exception) {
            // bundled theme copy fail ho to app baaki chalta rahe
        }
        upgradeLegacy(ctx)
    }

    private const val BUNDLED_VERSION = "3"

    /**
     * Pehle import ki hui purani "clock 3x4" (MTZ PORT) ko naye manifest me upgrade karta hai
     * (ColorOS-style date + colon option). 24h/12h wahi rehta hai jo us copy me tha.
     */
    fun upgradeLegacy(ctx: Context) {
        try {
            val patched = ctx.assets.open("themes/xiaomi_clock_3x4/manifest.xml").bufferedReader().use { it.readText() }
            val dirs = base(ctx).listFiles()?.filter {
                it.isDirectory && !it.name.startsWith("_") && !isBundled(it.name)
            } ?: return
            for (d in dirs) {
                val root = findRoot(d) ?: continue
                val mf = File(root, "manifest.xml")
                val old = mf.readText()
                if (!old.contains("Aguskurniawan") || old.contains("show_date")) continue
                mf.writeText(if (old.contains("#hour24")) patched.replace("#hour12", "#hour24") else patched)
            }
        } catch (e: Exception) {
            // upgrade fail ho to purani theme jaisi chalti rahe
        }
    }

    private fun copyAsset(ctx: Context, path: String, dst: File) {
        val kids = ctx.assets.list(path) ?: emptyArray()
        if (kids.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            for (k in kids) copyAsset(ctx, "$path/$k", File(dst, k))
        }
    }

    fun root(ctx: Context, id: String): File? {
        if (!id.matches(Regex("[A-Za-z0-9_]+"))) return null
        val d = File(base(ctx), id)
        return if (d.isDirectory) findRoot(d) else null
    }

    fun delete(ctx: Context, id: String) {
        if (isBundled(id)) return
        if (id.matches(Regex("[A-Za-z0-9_]+"))) File(base(ctx), id).deleteRecursively()
    }

    private fun cleanName(raw: String): String {
        var n = raw.substringBeforeLast('.', raw)
        n = n.replace(Regex("^[0-9a-fA-F]{8}-"), "")
        n = n.replace('_', ' ').replace('-', ' ').trim()
        return if (n.isEmpty()) "Imported theme" else n
    }

    private fun unzip(input: java.io.InputStream, dest: File, counter: Counter) {
        val destPath = dest.canonicalPath + File.separator
        ZipInputStream(input).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val entryName = e.name.replace('\\', '/')
                if (entryName.startsWith("__MACOSX") || entryName.endsWith(".DS_Store")) {
                    zin.closeEntry()
                    continue
                }
                val out = File(dest, entryName)
                if (!out.canonicalPath.startsWith(destPath)) throw SecurityException("Unsafe path in zip: ${e.name}")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val r = zin.read(buf)
                            if (r < 0) break
                            counter.n += r.toLong()
                            if (counter.n > MAX_BYTES) throw IllegalStateException("Zip is too large")
                            o.write(buf, 0, r)
                        }
                    }
                }
                zin.closeEntry()
            }
        }
    }

    /** Zip / .mtz import karke naya theme id return karta hai. */
    fun import(ctx: Context, uri: Uri, displayName: String): String {
        val id = "t" + System.currentTimeMillis()
        val tmp = File(base(ctx), "_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val counter = Counter()

        val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the file")
        try {
            unzip(input, tmp, counter)

            // Xiaomi .mtz ke andar kabhi kabhi inner zip hota hai (clock_2x4 etc.)
            if (findRoot(tmp) == null) {
                val inner = tmp.walkTopDown().filter {
                    it.isFile && (it.extension.equals("zip", true) || it.extension.equals("mtz", true) || it.name.startsWith("clock", true))
                }.take(20).toList()
                for (f in inner) {
                    val d = File(f.parentFile, f.name + "_x")
                    d.mkdirs()
                    try {
                        f.inputStream().use { unzip(it, d, counter) }
                    } catch (e: SecurityException) {
                        throw e
                    } catch (e: Exception) {
                        // ye file zip nahi thi, skip
                    }
                    if (findRoot(tmp) != null) break
                }
            }
        } catch (e: java.util.zip.ZipException) {
            tmp.deleteRecursively()
            throw IllegalStateException("This file is not a valid zip")
        }

        if (findRoot(tmp) == null) {
            tmp.deleteRecursively()
            throw IllegalStateException("No manifest.xml found in this file")
        }
        File(tmp, "name.txt").writeText(cleanName(displayName))
        val dst = File(base(ctx), id)
        if (!tmp.renameTo(dst)) {
            tmp.deleteRecursively()
            throw IllegalStateException("Could not save the theme")
        }
        return id
    }
}
