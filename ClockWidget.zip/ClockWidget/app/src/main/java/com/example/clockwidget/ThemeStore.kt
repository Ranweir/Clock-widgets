package com.example.clockwidget

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

data class ThemeInfo(val id: String, val name: String)

/** Import ki hui Xiaomi themes: filesDir/themes/<id>/ */
object ThemeStore {
    private const val MAX_BYTES = 150L * 1024 * 1024

    private fun base(ctx: Context) = File(ctx.filesDir, "themes")

    fun list(ctx: Context): List<ThemeInfo> =
        base(ctx).listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("_") && findRoot(it) != null }
            ?.sortedBy { it.name }
            ?.map { d ->
                val n = File(d, "name.txt").takeIf { it.exists() }?.readText()?.trim()
                ThemeInfo(d.name, if (n.isNullOrEmpty()) d.name else n)
            } ?: emptyList()

    fun name(ctx: Context, id: String): String? = list(ctx).firstOrNull { it.id == id }?.name

    fun findRoot(dir: File): File? {
        if (File(dir, "manifest.xml").exists()) return dir
        return dir.listFiles()?.firstOrNull { it.isDirectory && File(it, "manifest.xml").exists() }
    }

    fun root(ctx: Context, id: String): File? {
        if (!id.matches(Regex("[A-Za-z0-9_]+"))) return null
        val d = File(base(ctx), id)
        return if (d.isDirectory) findRoot(d) else null
    }

    fun delete(ctx: Context, id: String) {
        if (id.matches(Regex("[A-Za-z0-9_]+"))) File(base(ctx), id).deleteRecursively()
    }

    private fun cleanName(raw: String): String {
        var n = raw.substringBeforeLast('.', raw)
        n = n.replace(Regex("^[0-9a-fA-F]{8}-"), "")
        n = n.replace('_', ' ').replace('-', ' ').trim()
        return if (n.isEmpty()) "Imported theme" else n
    }

    /** Zip import karke naya theme id return karta hai. */
    fun import(ctx: Context, uri: Uri, displayName: String): String {
        val id = "t" + System.currentTimeMillis()
        val tmp = File(base(ctx), "_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val tmpPath = tmp.canonicalPath + File.separator
        var total = 0L

        val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the file")
        ZipInputStream(input).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val out = File(tmp, e.name)
                if (!out.canonicalPath.startsWith(tmpPath)) throw SecurityException("Unsafe path in zip: ${e.name}")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val r = zin.read(buf)
                            if (r < 0) break
                            total += r
                            if (total > MAX_BYTES) throw IllegalStateException("Zip is too large")
                            o.write(buf, 0, r)
                        }
                    }
                }
                zin.closeEntry()
            }
        }

        if (findRoot(tmp) == null) {
            tmp.deleteRecursively()
            throw IllegalStateException("No manifest.xml found in this zip")
        }
        File(tmp, "name.txt").writeText(cleanName(displayName))
        val dst = File(base(ctx), id)
        if (!tmp.renameTo(dst)) {
            tmp.deleteRecursively()
            throw IllegalStateException("Could not save the theme")
        }
        return id
    }
}
