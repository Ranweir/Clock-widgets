package com.example.clockwidget

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

object ThemeStore {
    private const val MAX_BYTES = 150L * 1024 * 1024

    fun dir(ctx: Context) = File(ctx.filesDir, "theme")

    /** manifest.xml jis folder me ho wo theme root hai. */
    fun findRoot(base: File): File? {
        if (File(base, "manifest.xml").exists()) return base
        return base.listFiles()?.firstOrNull { it.isDirectory && File(it, "manifest.xml").exists() }
    }

    fun root(ctx: Context): File? = findRoot(dir(ctx))

    fun import(ctx: Context, uri: Uri) {
        val tmp = File(ctx.filesDir, "theme_new")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val tmpPath = tmp.canonicalPath + File.separator
        var total = 0L

        val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("File khul nahi rahi")
        ZipInputStream(input).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val out = File(tmp, e.name)
                if (!out.canonicalPath.startsWith(tmpPath)) throw SecurityException("Galat path zip me: ${e.name}")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val r = zin.read(buf)
                            if (r < 0) break
                            total += r
                            if (total > MAX_BYTES) throw IllegalStateException("Zip bahut bada hai")
                            o.write(buf, 0, r)
                        }
                    }
                }
                zin.closeEntry()
            }
        }

        if (findRoot(tmp) == null) {
            tmp.deleteRecursively()
            throw IllegalStateException("Is zip me manifest.xml nahi mili")
        }
        val dst = dir(ctx)
        dst.deleteRecursively()
        if (!tmp.renameTo(dst)) {
            tmp.deleteRecursively()
            throw IllegalStateException("Theme save nahi ho payi")
        }
    }
}
