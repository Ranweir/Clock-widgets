package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context)
        schedule(context)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
    }

    override fun onDisabled(context: Context) {
        cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                refresh(context)
                schedule(context)
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.TICK"
        private const val RENDER_W = 540

        private fun ids(context: Context): IntArray {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
        }

        fun refresh(context: Context) {
            val ids = ids(context)
            if (ids.isEmpty()) return
            val root = ThemeStore.root(context)
            val bmp = root?.let { ClockRenderer.render(it, RENDER_W) }

            val rv = RemoteViews(context.packageName, R.layout.widget_clock)
            if (bmp != null) {
                rv.setImageViewBitmap(R.id.clock_img, bmp)
                rv.setViewVisibility(R.id.hint, View.GONE)
            } else {
                rv.setViewVisibility(R.id.hint, View.VISIBLE)
            }
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            AppWidgetManager.getInstance(context).updateAppWidget(ids, rv)
        }

        private fun tickIntent(context: Context): PendingIntent {
            val i = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
            return PendingIntent.getBroadcast(
                context, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Agle minute ki shuruaat par update. */
        fun schedule(context: Context) {
            if (ids(context).isEmpty()) return
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val at = (System.currentTimeMillis() / 60000 + 1) * 60000
            val pi = tickIntent(context)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }

        fun cancel(context: Context) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(context))
        }
    }
}
