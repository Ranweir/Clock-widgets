package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // Naye widget ko editor ki current (draft) setting mil jati hai
        for (id in ids) {
            if (Prefs.widget(context, id) == null) Prefs.setWidget(context, id, Prefs.draft(context))
        }
        refresh(context)
        schedule(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        refreshOne(context, manager, id)
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        for (id in ids) Prefs.removeWidget(context, id)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
    }

    override fun onDisabled(context: Context) {
        cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                refresh(context)
                schedule(context)
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.TICK"
        private const val MAX_PIXELS = 1_000_000

        fun ids(context: Context): IntArray {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
        }

        /** Widget ka asli size pixels me (resize karne par ye badalta hai). */
        fun sizeFor(context: Context, mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
            val o = mgr.getAppWidgetOptions(id)
            val d = context.resources.displayMetrics.density
            val land = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            var wdp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            var hdp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
            if (wdp <= 0) wdp = 250
            if (hdp <= 0) hdp = 130
            var w = (wdp * d).toInt().coerceAtLeast(100)
            var h = (hdp * d).toInt().coerceAtLeast(100)
            val area = w.toLong() * h
            if (area > MAX_PIXELS) {
                val f = Math.sqrt(MAX_PIXELS.toDouble() / area)
                w = (w * f).toInt()
                h = (h * f).toInt()
            }
            return Pair(w, h)
        }

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            for (id in ids(context)) refreshOne(context, mgr, id)
        }

        fun refreshOne(context: Context, mgr: AppWidgetManager, id: Int) {
            val cfg = Prefs.widget(context, id) ?: Prefs.draft(context)
            val (w, h) = sizeFor(context, mgr, id)
            val bmp = ClockEngine.render(context, cfg, w, h)
            val rv = RemoteViews(context.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.clock_img, bmp)
            val open = PendingIntent.getActivity(
                context, id,
                Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_WIDGET_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            mgr.updateAppWidget(id, rv)
        }

        private fun tickIntent(context: Context): PendingIntent {
            val i = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
            return PendingIntent.getBroadcast(
                context, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Agle minute ki shuruaat par update. */
        fun schedule(context: Context) {
            if (ids(context).isEmpty()) return
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val at = (System.currentTimeMillis() / 60000 + 1) * 60000
            val pi = tickIntent(context)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }

        fun cancel(context: Context) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(context))
        }
    }
}
