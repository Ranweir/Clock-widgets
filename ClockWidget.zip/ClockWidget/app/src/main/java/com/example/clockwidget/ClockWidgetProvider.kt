package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // Naye widget ko editor ki current (draft) setting mil jati hai
        for (id in ids) {
            if (Prefs.widget(context, id) == null) Prefs.setWidget(context, id, Prefs.draft(context))
        }
        refresh(context)
        schedule(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        // goAsync: animation ke frames background thread me bhejne tak process zinda rahe
        val pending = try { goAsync() } catch (e: Throwable) { null }
        animateOne(context, manager, id) { try { pending?.finish() } catch (e: Throwable) {} }
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        for (id in ids) Prefs.removeWidget(context, id)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
    }

    override fun onDisabled(context: Context) {
        cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                refresh(context)
                schedule(context)
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.TICK"
        private const val MAX_PIXELS = 1_000_000

        fun ids(context: Context): IntArray {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
        }

        /** Widget ka asli size pixels me (resize karne par ye badalta hai). */
        fun sizeFor(context: Context, mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
            val o = mgr.getAppWidgetOptions(id)
            val d = context.resources.displayMetrics.density
            val land = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            var wdp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            var hdp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
            if (wdp <= 0) wdp = 250
            if (hdp <= 0) hdp = 130
            var w = (wdp * d).toInt().coerceAtLeast(100)
            var h = (hdp * d).toInt().coerceAtLeast(100)
            val area = w.toLong() * h
            if (area > MAX_PIXELS) {
                val f = Math.sqrt(MAX_PIXELS.toDouble() / area)
                w = (w * f).toInt()
                h = (h * f).toInt()
            }
            return Pair(w, h)
        }

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            for (id in ids(context)) refreshOne(context, mgr, id)
        }

        private val shownMorph = java.util.concurrent.ConcurrentHashMap<Int, Float>()
        private val animGen = java.util.concurrent.ConcurrentHashMap<Int, Int>()

        private fun push(context: Context, mgr: AppWidgetManager, id: Int, bmp: android.graphics.Bitmap) {
            val rv = RemoteViews(context.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.clock_img, bmp)
            rv.setContentDescription(R.id.clock_img, "Aurum Clock")
            val open = PendingIntent.getActivity(
                context, id,
                Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_WIDGET_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            mgr.updateAppWidget(id, rv)
        }

        fun refreshOne(context: Context, mgr: AppWidgetManager, id: Int) {
            val cfg = Prefs.widget(context, id) ?: Prefs.draft(context)
            val (w, h) = sizeFor(context, mgr, id)
            animGen.merge(id, 1) { a, b -> a + b }      // chalti animation ho to rok do
            push(context, mgr, id, ClockEngine.render(context, cfg, w, h))
            shownMorph[id] = Fit.morphFor(w, h)
        }

        /** Kya ye clock widget ke size ke saath morph hota hai (manifest me #morph hai)? */
        private fun usesMorph(context: Context, clockId: String): Boolean {
            if (!clockId.startsWith("t:")) return false
            val root = ThemeStore.root(context, clockId.substring(2)) ?: return false
            return try { java.io.File(root, "manifest.xml").readText().contains("#morph") } catch (e: Exception) { false }
        }

        /**
         * Resize par widget purane layout se naye layout tak ~0.4s me morph hota hai: beech ke frames
         * background me render hokar bheje jaate hain (launcher khud animation nahi karta, isliye hum frames dete hain).
         * Resize jaari ho to har naya size pichle frame se aage chalta hai (animation tootti nahi).
         */
        fun animateOne(context: Context, mgr: AppWidgetManager, id: Int, done: () -> Unit) {
            val cfg = Prefs.widget(context, id) ?: Prefs.draft(context)
            val (w, h) = sizeFor(context, mgr, id)
            val target = Fit.morphFor(w, h)
            val from = shownMorph[id]
            if (from == null || Math.abs(target - from) < 0.02f || !usesMorph(context, cfg.clockId)) {
                try { refreshOne(context, mgr, id) } finally { done() }
                return
            }
            val gen = animGen.merge(id, 1) { a, b -> a + b } ?: 1
            Thread {
                try {
                    val dur = 420f
                    val t0 = android.os.SystemClock.uptimeMillis()
                    // animation ke dauran chhote frames (tez), aakhir me full quality
                    val f = Math.min(1.0, Math.sqrt(260_000.0 / (w.toLong() * h))).toFloat()
                    val sw = (w * f).toInt().coerceAtLeast(64)
                    val sh = (h * f).toInt().coerceAtLeast(64)
                    while (animGen[id] == gen) {
                        val t = ((android.os.SystemClock.uptimeMillis() - t0) / dur).coerceIn(0f, 1f)
                        if (t >= 1f) break
                        val e = 1f - (1f - t) * (1f - t) * (1f - t)      // ease-out
                        val m = from + (target - from) * e
                        val bmp = ClockEngine.render(context, cfg, sw, sh, m)
                        if (animGen[id] != gen) break
                        push(context, mgr, id, bmp)
                        shownMorph[id] = m
                    }
                    if (animGen[id] == gen) {
                        push(context, mgr, id, ClockEngine.render(context, cfg, w, h, target))
                        shownMorph[id] = target
                    }
                } catch (e: Throwable) {
                    // animation fail ho to bhi final frame zaroor dikhe
                    try { if (animGen[id] == gen) refreshOne(context, mgr, id) } catch (_: Throwable) {}
                } finally {
                    done()
                }
            }.start()
        }

        private fun tickIntent(context: Context): PendingIntent {
            val i = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
            return PendingIntent.getBroadcast(
                context, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Agle minute ki shuruaat par update. */
        fun schedule(context: Context) {
            if (ids(context).isEmpty()) return
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val at = (System.currentTimeMillis() / 60000 + 1) * 60000
            val pi = tickIntent(context)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }

        fun cancel(context: Context) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(context))
        }
    }
}
