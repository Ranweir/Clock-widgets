package com.example.clockwidget

import android.content.Context
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Outline
import android.view.ViewOutlineProvider
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Floating bar ke 3 icons (grid / import / gear), canvas se bane, taaki font par depend na ho. */
class BarIcon(ctx: Context, private val kind: Int) : View(ctx) {
    var tint: Int = Pal.uMuted
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.color = tint
        p.strokeWidth = s * 0.085f
        p.style = Paint.Style.STROKE
        c.save()
        c.translate(ox, oy)
        when (kind) {
            0 -> {
                val g = s * 0.10f
                val a = s * 0.12f
                val sz = (s - 2 * a - g) / 2f
                for (i in 0..1) for (j in 0..1) {
                    val l = a + i * (sz + g)
                    val t = a + j * (sz + g)
                    c.drawRoundRect(RectF(l, t, l + sz, t + sz), s * 0.07f, s * 0.07f, p)
                }
            }
            1 -> {
                val path = Path()
                path.moveTo(s * 0.16f, s * 0.58f)
                path.lineTo(s * 0.16f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.58f)
                c.drawPath(path, p)
                c.drawLine(s * 0.5f, s * 0.14f, s * 0.5f, s * 0.60f, p)
                val head = Path()
                head.moveTo(s * 0.32f, s * 0.44f)
                head.lineTo(s * 0.5f, s * 0.62f)
                head.lineTo(s * 0.68f, s * 0.44f)
                c.drawPath(head, p)
            }
            else -> {
                val cx = s / 2f
                val cy = s / 2f
                c.drawCircle(cx, cy, s * 0.17f, p)
                c.drawCircle(cx, cy, s * 0.31f, p)
                for (k in 0 until 8) {
                    val a = Math.PI / 4 * k
                    c.drawLine(
                        cx + cos(a).toFloat() * s * 0.37f, cy + sin(a).toFloat() * s * 0.37f,
                        cx + cos(a).toFloat() * s * 0.46f, cy + sin(a).toFloat() * s * 0.46f, p
                    )
                }
            }
        }
        c.restore()
    }
}

/** Horizontal swipe se page badalne wala container (vertical scroll bachpan se chalta rehta hai). */
class SwipeFrame(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dx0 = 0f
    private var dy0 = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; dy0 = e.y; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - dx0
                val dy = e.y - dy0
                if (abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.6f) { dragging = true; return true }
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = e.x - dx0
                for (i in 0 until childCount) getChildAt(i).translationX = dx * 0.35f
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dx = e.x - dx0
                for (i in 0 until childCount) getChildAt(i).animate().translationX(0f).setDuration(150).start()
                if (dragging && e.actionMasked == MotionEvent.ACTION_UP && abs(dx) > resources.displayMetrics.density * 70f) {
                    onSwipe(if (dx < 0) 1 else -1)
                }
                dragging = false
            }
        }
        return true
    }
}

/**
 * iOS-style floating tab bar. Ek glass "pill" selected tab ke peeche rehta hai.
 *  - Tap: pill naye tab par slide karke jaata hai.
 *  - Press & drag: pill thoda bada ho jaata hai aur ungli ke saath chalta hai; jaise hi
 *    doosre tab ke upar pahunchta hai, page badal jaata hai; chhodne par nearest tab par snap.
 */
class GlassBar(ctx: Context) : LinearLayout(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var accent: Int = Pal.GOLD
        set(v) { field = v; invalidate() }
    var idleColor: Int = Pal.MUTED
    var selected = 0
        private set

    private var pillCx = -1f
    private var press = 0f
    private var dragging = false
    private var downX = 0f
    private var slideAnim: ValueAnimator? = null
    private var pressAnim: ValueAnimator? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() * 1.2f }

    // ── Liquid glass (body) ──
    private var tintAlpha = 40
    private var darkUi = true
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() * 1.5f }
    private val rim2P = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() }
    private val hairP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat(); color = Color.argb(40, 60, 50, 30) }
    private val clip = Path()
    private val rb = RectF()
    private var bodyR = 0f

    /** Liquid-glass body ka tint (0..100) aur UI dark/light. */
    fun setGlass(tint: Int, dark: Boolean) {
        tintAlpha = (14 + tint * 1.3f).toInt().coerceIn(10, 190)
        darkUi = dark
        buildBody(width, height)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        buildBody(w, h)
    }

    private fun buildBody(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val W = w.toFloat(); val H = h.toFloat()
        bodyR = minOf(context.dp(40).toFloat(), H / 2f)
        rb.set(0f, 0f, W, H)
        val tb = if (darkUi) Color.WHITE else Color.WHITE
        bodyP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb((tintAlpha * 0.85f).toInt(), Color.red(tb), Color.green(tb), Color.blue(tb)),
            Color.argb((tintAlpha * 0.55f).toInt(), Color.red(tb), Color.green(tb), Color.blue(tb))
        ), null, Shader.TileMode.CLAMP)
        // andar ka dark top-shade = glass ki "depth"
        val shadeA = if (darkUi) 70 else 34
        shadeP.shader = LinearGradient(0f, 0f, 0f, H * 0.55f, Color.argb(shadeA, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        // neeche ki chamak
        glowP.shader = LinearGradient(0f, H * 0.6f, 0f, H, Color.TRANSPARENT, Color.argb(if (darkUi) 62 else 90, 255, 255, 255), Shader.TileMode.CLAMP)
        // upar-left se tirchi sheen
        sheenP.shader = LinearGradient(0f, 0f, W * 0.55f, H, Color.argb(if (darkUi) 46 else 70, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        // bahar ki rim: upar halki, neeche tez safed (jaise screenshot me)
        rimP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb(120, 255, 255, 255), Color.argb(26, 255, 255, 255),
            Color.argb(40, 255, 255, 255), Color.argb(238, 255, 255, 255)
        ), floatArrayOf(0f, 0.38f, 0.66f, 1f), Shader.TileMode.CLAMP)
        rim2P.shader = LinearGradient(0f, 0f, W, H, intArrayOf(
            Color.argb(80, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(46, 255, 255, 255)
        ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, bodyR); o.alpha = 0.3f }
        }
    }

    private fun drawBody(c: Canvas) {
        if (width <= 0 || bodyP.shader == null) return
        c.drawRoundRect(rb, bodyR, bodyR, bodyP)
        clip.reset(); clip.addRoundRect(rb, bodyR, bodyR, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(rb, shadeP)
        c.drawRect(rb, glowP)
        c.drawRect(rb, sheenP)
        c.restore()
        if (!darkUi) {   // light mode me safed rim dikhne ke liye halki dark hairline
            val hl = hairP.strokeWidth / 2f
            c.drawRoundRect(hl, hl, rb.right - hl, rb.bottom - hl, bodyR - hl, bodyR - hl, hairP)
        }
        val i1 = rimP.strokeWidth / 2f
        c.drawRoundRect(i1, i1, rb.right - i1, rb.bottom - i1, bodyR - i1, bodyR - i1, rimP)
        val i2 = rimP.strokeWidth + rim2P.strokeWidth / 2f + context.dp(1)
        c.drawRoundRect(i2, i2, rb.right - i2, rb.bottom - i2, (bodyR - i2).coerceAtLeast(1f), (bodyR - i2).coerceAtLeast(1f), rim2P)
    }

    init {
        orientation = HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        clipChildren = false
        clipToPadding = false
        setWillNotDraw(false)
    }

    private fun tabCx(i: Int): Float {
        val c = getChildAt(i.coerceIn(0, childCount - 1)) ?: return width / 2f
        return c.left + c.width / 2f
    }

    private fun nearest(x: Float): Int {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in 0 until childCount) {
            val d = abs(tabCx(i) - x)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    /** Items naye bane (labels / size badle): pill ko selected tab par bina animation ke rakho. */
    fun resetTo(i: Int) {
        selected = i
        slideAnim?.cancel()
        pillCx = -1f
        post { pillCx = tabCx(selected); updateTints(); invalidate() }
        invalidate()
    }

    /** Bahar se (swipe ya code) tab badla: pill slide kare. */
    fun select(i: Int) {
        if (i == selected && !dragging) { return }
        selected = i
        if (!dragging) slideTo(tabCx(i))
    }

    private fun slideTo(target: Float) {
        slideAnim?.cancel()
        if (pillCx < 0f || width == 0) { pillCx = target; updateTints(); invalidate(); return }
        slideAnim = ValueAnimator.ofFloat(pillCx, target).apply {
            duration = 320
            interpolator = OvershootInterpolator(0.8f)
            addUpdateListener { setPill(it.animatedValue as Float) }
            start()
        }
    }

    private fun setPill(x: Float) { pillCx = x; updateTints(); invalidate() }

    private fun animatePress(to: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, to).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Pill jis tab ke jitna paas, utna uska icon/label accent rang ka. */
    private fun updateTints() {
        if (pillCx < 0f) return
        for (i in 0 until childCount) {
            val item = getChildAt(i) as? ViewGroup ?: continue
            val w = item.width.coerceAtLeast(1).toFloat()
            val t = (1f - abs(pillCx - tabCx(i)) / w).coerceIn(0f, 1f)
            val col = blend(idleColor, accent, t)
            (item.getChildAt(0) as? BarIcon)?.tint = col
            (item.getChildAt(2) as? TextView)?.setTextColor(col)
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    override fun dispatchDraw(c: Canvas) {
        drawBody(c)
        if (childCount > 0) {
            if (pillCx < 0f) { pillCx = tabCx(selected); updateTints() }
            val ch = getChildAt(0)
            val sc = 1f + 0.16f * press
            val hw = ch.width / 2f * sc
            val cy = (ch.top + ch.bottom) / 2f
            val hh = (ch.bottom - ch.top) / 2f * sc
            rect.set(pillCx - hw, cy - hh, pillCx + hw, cy + hh)
            // selected pill: andar dabi hui dark glass; press par halki aur chamakdaar ho jaati hai
            val dk = if (darkUi) 1f else 0.55f
            val fa = ((if (darkUi) 92 else 46) * (1f - 0.62f * press)).toInt()
            fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, intArrayOf(
                Color.argb((fa * 1.25f).toInt().coerceAtMost(255), 0, 0, 0),
                Color.argb((fa * 0.7f).toInt(), 0, 0, 0)
            ), null, Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, hh, hh, fill)
            fill.shader = null
            fill.color = Color.argb((26 + 20 * press).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(rect, hh, hh, fill)
            ring.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, intArrayOf(
                Color.argb((16 * dk + 70 * press).toInt(), 255, 255, 255),
                Color.argb((10 + 30 * press).toInt(), 255, 255, 255),
                Color.argb((60 * dk + 170 * press).toInt().coerceAtMost(255), 255, 255, 255)
            ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, hh, hh, ring)
            ring.shader = null
        }
        super.dispatchDraw(c)
    }

    override fun onInterceptTouchEvent(e: MotionEvent) = true

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                dragging = false
                animatePress(1f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.x - downX) > slop) {
                    dragging = true
                    slideAnim?.cancel()
                }
                if (dragging && childCount > 0) {
                    setPill(e.x.coerceIn(tabCx(0), tabCx(childCount - 1)))
                    val n = nearest(pillCx)
                    if (n != selected) { selected = n; onSelect?.invoke(n) }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val target = when {
                    e.actionMasked == MotionEvent.ACTION_CANCEL -> selected
                    dragging -> nearest(pillCx)
                    else -> nearest(e.x)
                }
                dragging = false
                animatePress(0f)
                if (target != selected) { selected = target; onSelect?.invoke(target) }
                slideTo(tabCx(target))
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
