package com.example.clockwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Floating bar ke 3 icons (grid / import / gear), canvas se bane, taaki font par depend na ho. */
class BarIcon(ctx: Context, private val kind: Int) : View(ctx) {
    var tint: Int = Pal.MUTED
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.color = tint
        p.strokeWidth = s * 0.085f
        p.style = Paint.Style.STROKE
        c.save()
        c.translate(ox, oy)
        when (kind) {
            0 -> {
                val g = s * 0.10f
                val a = s * 0.12f
                val sz = (s - 2 * a - g) / 2f
                for (i in 0..1) for (j in 0..1) {
                    val l = a + i * (sz + g)
                    val t = a + j * (sz + g)
                    c.drawRoundRect(RectF(l, t, l + sz, t + sz), s * 0.07f, s * 0.07f, p)
                }
            }
            1 -> {
                val path = Path()
                path.moveTo(s * 0.16f, s * 0.58f)
                path.lineTo(s * 0.16f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.58f)
                c.drawPath(path, p)
                c.drawLine(s * 0.5f, s * 0.14f, s * 0.5f, s * 0.60f, p)
                val head = Path()
                head.moveTo(s * 0.32f, s * 0.44f)
                head.lineTo(s * 0.5f, s * 0.62f)
                head.lineTo(s * 0.68f, s * 0.44f)
                c.drawPath(head, p)
            }
            else -> {
                val cx = s / 2f
                val cy = s / 2f
                c.drawCircle(cx, cy, s * 0.17f, p)
                c.drawCircle(cx, cy, s * 0.31f, p)
                for (k in 0 until 8) {
                    val a = Math.PI / 4 * k
                    c.drawLine(
                        cx + cos(a).toFloat() * s * 0.37f, cy + sin(a).toFloat() * s * 0.37f,
                        cx + cos(a).toFloat() * s * 0.46f, cy + sin(a).toFloat() * s * 0.46f, p
                    )
                }
            }
        }
        c.restore()
    }
}

/** Horizontal swipe se page badalne wala container (vertical scroll bachpan se chalta rehta hai). */
class SwipeFrame(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dx0 = 0f
    private var dy0 = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; dy0 = e.y; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - dx0
                val dy = e.y - dy0
                if (abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.6f) { dragging = true; return true }
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = e.x - dx0
                for (i in 0 until childCount) getChildAt(i).translationX = dx * 0.35f
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dx = e.x - dx0
                for (i in 0 until childCount) getChildAt(i).animate().translationX(0f).setDuration(150).start()
                if (dragging && e.actionMasked == MotionEvent.ACTION_UP && abs(dx) > resources.displayMetrics.density * 70f) {
                    onSwipe(if (dx < 0) 1 else -1)
                }
                dragging = false
            }
        }
        return true
    }
}
