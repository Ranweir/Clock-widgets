package com.example.clockwidget

import android.content.Context
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.view.ViewTreeObserver
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Outline
import android.view.ViewOutlineProvider
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Floating bar ke 3 icons (grid / import / gear), canvas se bane, taaki font par depend na ho. */
class BarIcon(ctx: Context, private val kind: Int) : View(ctx) {
    var tint: Int = Pal.uMuted
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.color = tint
        p.strokeWidth = s * 0.085f
        p.style = Paint.Style.STROKE
        c.save()
        c.translate(ox, oy)
        when (kind) {
            0 -> {
                val g = s * 0.10f
                val a = s * 0.12f
                val sz = (s - 2 * a - g) / 2f
                for (i in 0..1) for (j in 0..1) {
                    val l = a + i * (sz + g)
                    val t = a + j * (sz + g)
                    c.drawRoundRect(RectF(l, t, l + sz, t + sz), s * 0.07f, s * 0.07f, p)
                }
            }
            1 -> {
                val path = Path()
                path.moveTo(s * 0.16f, s * 0.58f)
                path.lineTo(s * 0.16f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.80f)
                path.lineTo(s * 0.84f, s * 0.58f)
                c.drawPath(path, p)
                c.drawLine(s * 0.5f, s * 0.14f, s * 0.5f, s * 0.60f, p)
                val head = Path()
                head.moveTo(s * 0.32f, s * 0.44f)
                head.lineTo(s * 0.5f, s * 0.62f)
                head.lineTo(s * 0.68f, s * 0.44f)
                c.drawPath(head, p)
            }
            else -> {
                val cx = s / 2f
                val cy = s / 2f
                c.drawCircle(cx, cy, s * 0.17f, p)
                c.drawCircle(cx, cy, s * 0.31f, p)
                for (k in 0 until 8) {
                    val a = Math.PI / 4 * k
                    c.drawLine(
                        cx + cos(a).toFloat() * s * 0.37f, cy + sin(a).toFloat() * s * 0.37f,
                        cx + cos(a).toFloat() * s * 0.46f, cy + sin(a).toFloat() * s * 0.46f, p
                    )
                }
            }
        }
        c.restore()
    }
}

/** Horizontal swipe se page badalne wala container. Drag ke saath chalta hai, tez fling par bhi page badalta hai. */
class SwipeFrame(ctx: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val minFling = ViewConfiguration.get(ctx).scaledMinimumFlingVelocity * 4f
    private var dx0 = 0f
    private var dy0 = 0f
    private var dragging = false
    private var vt: android.view.VelocityTracker? = null

    private fun track(e: MotionEvent) {
        if (vt == null) vt = android.view.VelocityTracker.obtain()
        vt?.addMovement(e)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        track(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; dy0 = e.y; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - dx0
                val dy = e.y - dy0
                if (abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.6f) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { vt?.recycle(); vt = null }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        track(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = e.x - dx0
                // rubber-band: jitna kheencho utna bhaari
                val shown = dx * 0.42f / (1f + abs(dx) / (width.coerceAtLeast(1) * 1.4f))
                for (i in 0 until childCount) getChildAt(i).translationX = shown
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dx = e.x - dx0
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                vt?.recycle(); vt = null
                val d = resources.displayMetrics.density
                val far = abs(dx) > d * 70f
                val fling = abs(vx) > minFling.coerceAtLeast(d * 700f) && abs(dx) > d * 24f && (vx < 0) == (dx < 0)
                val go = dragging && e.actionMasked == MotionEvent.ACTION_UP && (far || fling)
                if (!go) {
                    for (i in 0 until childCount) getChildAt(i).animate().translationX(0f).setDuration(260)
                        .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)).start()
                }
                if (go) onSwipe(if (dx < 0) 1 else -1)
                dragging = false
            }
        }
        return true
    }
}

/**
 * iOS-style floating tab bar. Ek glass "pill" selected tab ke peeche rehta hai.
 *  - Tap: pill naye tab par slide karke jaata hai.
 *  - Press & drag: pill thoda bada ho jaata hai aur ungli ke saath chalta hai; jaise hi
 *    doosre tab ke upar pahunchta hai, page badal jaata hai; chhodne par nearest tab par snap.
 */
class GlassBar(ctx: Context) : LinearLayout(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var accent: Int = Pal.GOLD
        set(v) { field = v; invalidate() }
    var idleColor: Int = Pal.MUTED
    var selected = 0
        private set

    private var pillCx = -1f
    private var press = 0f
    private var dragging = false
    private var downX = 0f
    private var slideAnim: ValueAnimator? = null
    private var pressAnim: ValueAnimator? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() * 1.2f }

    // ── Liquid glass (body) ──
    private var tintAlpha = 40
    private var darkUi = true
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() * 1.5f }
    private val rim2P = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat() }
    private val hairP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat(); color = Color.argb(40, 60, 50, 30) }
    private val clip = Path()
    private val rb = RectF()
    private var bodyR = 0f

    /** Liquid-glass body ka tint (0..100) aur UI dark/light. */
    fun setGlass(tint: Int, dark: Boolean) {
        tintAlpha = (14 + tint * 1.3f).toInt().coerceIn(10, 190)
        darkUi = dark
        centerP.colorFilter = flattenFilter()
        snapValid = false
        buildBody(width, height)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        snapValid = false
        buildBody(w, h)
    }

    private fun buildBody(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val W = w.toFloat(); val H = h.toFloat()
        bodyR = minOf(context.dp(40).toFloat(), H / 2f)
        rb.set(0f, 0f, W, H)
        val tb = if (darkUi) Color.WHITE else Color.WHITE
        bodyP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb((tintAlpha * 0.40f).toInt(), Color.red(tb), Color.green(tb), Color.blue(tb)),
            Color.argb((tintAlpha * 0.20f).toInt(), Color.red(tb), Color.green(tb), Color.blue(tb))
        ), null, Shader.TileMode.CLAMP)
        // andar ka dark top-shade = glass ki "depth"
        val shadeA = if (darkUi) 70 else 34
        shadeP.shader = LinearGradient(0f, 0f, 0f, H * 0.55f, Color.argb(shadeA, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        // neeche ki chamak
        glowP.shader = LinearGradient(0f, H * 0.6f, 0f, H, Color.TRANSPARENT, Color.argb(if (darkUi) 62 else 90, 255, 255, 255), Shader.TileMode.CLAMP)
        // upar-left se tirchi sheen
        sheenP.shader = LinearGradient(0f, 0f, W * 0.55f, H, Color.argb(if (darkUi) 46 else 70, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        // bahar ki rim: upar halki, neeche tez safed (jaise screenshot me)
        rimP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb(120, 255, 255, 255), Color.argb(26, 255, 255, 255),
            Color.argb(40, 255, 255, 255), Color.argb(238, 255, 255, 255)
        ), floatArrayOf(0f, 0.38f, 0.66f, 1f), Shader.TileMode.CLAMP)
        rim2P.shader = LinearGradient(0f, 0f, W, H, intArrayOf(
            Color.argb(80, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(46, 255, 255, 255)
        ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, bodyR); o.alpha = 0.3f }
        }
    }

    // ── Backdrop blur + lens refraction (real liquid glass) ──
    private var source: View? = null
    private var preDraw: ViewTreeObserver.OnPreDrawListener? = null
    private var lastSig = 0
    private var snap: Bitmap? = null
    private var snapCanvas: Canvas? = null
    private var snapIn: IntArray? = null
    private var snapTmp: IntArray? = null
    private val snapScale = 0.125f
    private val snapMargin get() = context.dp(22)
    private val lensM = Matrix()
    private val centerP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frostP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    /** Peeche ke content ka contrast page-background ki taraf dabata hai, taaki dark cards ho ya khali page, glass ek jaisa dikhe. */
    private fun flattenFilter(): ColorMatrixColorFilter {
        val k = 0.36f
        val t = Pal.uBg
        val r = (1f - k) * Color.red(t); val g = (1f - k) * Color.green(t); val bl = (1f - k) * Color.blue(t)
        return ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
            k, 0f, 0f, 0f, r,
            0f, k, 0f, 0f, g,
            0f, 0f, k, 0f, bl,
            0f, 0f, 0f, 1f, 0f
        )))
    }

    /** Jis view ke upar bar tairta hai (pager): uska peeche ka hissa blur karke glass me dikhega. */
    fun bindSource(v: View) {
        unbindSource()
        source = v
        if (isAttachedToWindow) registerPreDraw()
    }

    private fun sig(): Int {
        val g = source as? ViewGroup ?: return 0
        var h = 17
        for (i in 0 until g.childCount) {
            val ch = g.getChildAt(i)
            h = h * 31 + ch.translationX.toBits()
            h = h * 31 + ch.alpha.toBits()
            h = h * 31 + ((ch as? android.widget.ScrollView)?.scrollY ?: 0)
        }
        return h * 31 + g.childCount
    }

    private fun registerPreDraw() {
        val v = source ?: return
        if (preDraw != null) return
        preDraw = ViewTreeObserver.OnPreDrawListener {
            val s = sig()
            if (s != lastSig) { lastSig = s; invalidate() }
            true
        }.also { v.viewTreeObserver.addOnPreDrawListener(it) }
    }

    private fun unbindSource() {
        val l = preDraw
        if (l != null) { source?.viewTreeObserver?.takeIf { it.isAlive }?.removeOnPreDrawListener(l) }
        preDraw = null
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); registerPreDraw() }
    override fun onDetachedFromWindow() { unbindSource(); super.onDetachedFromWindow() }

    private fun boxBlur(a: IntArray, tmp: IntArray, w: Int, h: Int, r: Int) {
        if (r < 1) return
        val d = 2 * r + 1
        for (pass in 0..1) {
            // horizontal: a -> tmp
            for (y in 0 until h) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) { val p = a[y * w + k.coerceIn(0, w - 1)]; sr += p shr 16 and 255; sg += p shr 8 and 255; sb += p and 255 }
                for (x in 0 until w) {
                    tmp[y * w + x] = (0xFF shl 24) or (sr / d shl 16) or (sg / d shl 8) or (sb / d)
                    val add = a[y * w + (x + r + 1).coerceAtMost(w - 1)]
                    val rem = a[y * w + (x - r).coerceAtLeast(0)]
                    sr += (add shr 16 and 255) - (rem shr 16 and 255)
                    sg += (add shr 8 and 255) - (rem shr 8 and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
            // vertical: tmp -> a
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) { val p = tmp[k.coerceIn(0, h - 1) * w + x]; sr += p shr 16 and 255; sg += p shr 8 and 255; sb += p and 255 }
                for (y in 0 until h) {
                    a[y * w + x] = (0xFF shl 24) or (sr / d shl 16) or (sg / d shl 8) or (sb / d)
                    val add = tmp[(y + r + 1).coerceAtMost(h - 1) * w + x]
                    val rem = tmp[(y - r).coerceAtLeast(0) * w + x]
                    sr += (add shr 16 and 255) - (rem shr 16 and 255)
                    sg += (add shr 8 and 255) - (rem shr 8 and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
        }
    }

    /** Bar ke peeche ka content chhote bitmap me utaar ke blur karta hai. */
    private fun captureBackdrop(): Boolean {
        val src = source ?: return false
        if (width <= 0 || height <= 0 || src.width <= 0) return false
        val m = snapMargin
        val fw = width + 2 * m
        val fh = height + 2 * m
        val bw = (fw * snapScale).toInt().coerceAtLeast(6)
        val bh = (fh * snapScale).toInt().coerceAtLeast(6)
        var b = snap
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            snap = b; snapCanvas = Canvas(b)
            snapIn = IntArray(bw * bh); snapTmp = IntArray(bw * bh)
        }
        val cv = snapCanvas ?: return false
        cv.drawColor(Pal.uBg)
        cv.save()
        cv.scale(bw / fw.toFloat(), bh / fh.toFloat())
        cv.translate(-(left - src.left - m).toFloat(), -(top - src.top - m).toFloat())
        try { src.draw(cv) } catch (_: Throwable) { cv.restore(); return false }
        cv.restore()
        val px = snapIn ?: return false
        b.getPixels(px, 0, bw, 0, 0, bw, bh)
        boxBlur(px, snapTmp ?: return false, bw, bh, 2)
        b.setPixels(px, 0, bw, 0, 0, bw, bh)
        return true
    }

    private var snapSig = 0
    private var snapValid = false
    private var snapL = Int.MIN_VALUE
    private var snapT = Int.MIN_VALUE
    private var lastCapMs = 0L

    private var frozen = false

    /** Page transition ke dauran capture band (frame budget bachane ko); khatam hote hi ek baar refresh. */
    fun setBackdropFrozen(f: Boolean) {
        frozen = f
        if (!f) { snapValid = false; invalidate() }
    }

    /** Peeche ka content badla ho tabhi dobara capture; scroll ke dauran max ~10fps (blur me farq nahi dikhta). */
    private fun ensureBackdrop(): Boolean {
        if (frozen && snapValid) return true
        val s = sig()
        val stale = !snapValid || s != snapSig || snapL != left || snapT != top
        if (!stale) return true
        val now = android.os.SystemClock.uptimeMillis()
        if (snapValid && now - lastCapMs < 100) { postInvalidateDelayed(100); return true }
        snapValid = captureBackdrop(); snapSig = s; snapL = left; snapT = top; lastCapMs = now
        return snapValid
    }

    /** Bahar se bolo ki peeche ka content (jaise images) badla hai. */
    fun refreshBackdrop() { if (frozen) return; snapValid = false; invalidate() }

    private fun drawBackdrop(c: Canvas) {
        if (!ensureBackdrop()) return
        val b = snap ?: return
        val m = snapMargin
        val sx = (width + 2 * m) / b.width.toFloat()
        val sy = (height + 2 * m) / b.height.toFloat()
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        lensM.setScale(sx, sy)
        lensM.postTranslate(-m.toFloat(), -m.toFloat())
        sh.setLocalMatrix(lensM)
        centerP.shader = sh
        c.drawRoundRect(rb, bodyR, bodyR, centerP)
        // frost: har page par ek jaisa look (peeche ka content sirf halka sa jhalakta hai)
        frostP.color = Color.argb(if (darkUi) 80 else 70, Color.red(Pal.uBg), Color.green(Pal.uBg), Color.blue(Pal.uBg))
        c.drawRoundRect(rb, bodyR, bodyR, frostP)
    }

    private fun drawBody(c: Canvas) {
        if (width <= 0 || bodyP.shader == null) return
        drawBackdrop(c)
        c.drawRoundRect(rb, bodyR, bodyR, bodyP)
        clip.reset(); clip.addRoundRect(rb, bodyR, bodyR, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(rb, shadeP)
        c.drawRect(rb, glowP)
        c.drawRect(rb, sheenP)
        c.restore()
        if (!darkUi) {   // light mode me safed rim dikhne ke liye halki dark hairline
            val hl = hairP.strokeWidth / 2f
            c.drawRoundRect(hl, hl, rb.right - hl, rb.bottom - hl, bodyR - hl, bodyR - hl, hairP)
        }
        val i1 = rimP.strokeWidth / 2f
        c.drawRoundRect(i1, i1, rb.right - i1, rb.bottom - i1, bodyR - i1, bodyR - i1, rimP)
        val i2 = rimP.strokeWidth + rim2P.strokeWidth / 2f + context.dp(1)
        c.drawRoundRect(i2, i2, rb.right - i2, rb.bottom - i2, (bodyR - i2).coerceAtLeast(1f), (bodyR - i2).coerceAtLeast(1f), rim2P)
    }

    init {
        orientation = HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        clipChildren = false
        clipToPadding = false
        setWillNotDraw(false)
    }

    private fun tabCx(i: Int): Float {
        val c = getChildAt(i.coerceIn(0, childCount - 1)) ?: return width / 2f
        return c.left + c.width / 2f
    }

    private fun nearest(x: Float): Int {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in 0 until childCount) {
            val d = abs(tabCx(i) - x)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    /** Items naye bane (labels / size badle): pill ko selected tab par bina animation ke rakho. */
    fun resetTo(i: Int) {
        selected = i
        slideAnim?.cancel()
        pillCx = -1f
        post { pillCx = tabCx(selected); updateTints(); invalidate() }
        invalidate()
    }

    /** Bahar se (swipe ya code) tab badla: pill slide kare. */
    fun select(i: Int) {
        if (i == selected && !dragging) { return }
        selected = i
        if (!dragging) slideTo(tabCx(i))
    }

    private fun slideTo(target: Float) {
        slideAnim?.cancel()
        if (pillCx < 0f || width == 0) { pillCx = target; updateTints(); invalidate(); return }
        slideAnim = ValueAnimator.ofFloat(pillCx, target).apply {
            duration = 320
            interpolator = OvershootInterpolator(0.8f)
            addUpdateListener { setPill(it.animatedValue as Float) }
            start()
        }
    }

    private fun setPill(x: Float) { pillCx = x; updateTints(); invalidate() }

    private fun animatePress(to: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, to).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Pill jis tab ke jitna paas, utna uska icon/label accent rang ka. */
    private fun updateTints() {
        if (pillCx < 0f) return
        for (i in 0 until childCount) {
            val item = getChildAt(i) as? ViewGroup ?: continue
            val w = item.width.coerceAtLeast(1).toFloat()
            val t = (1f - abs(pillCx - tabCx(i)) / w).coerceIn(0f, 1f)
            val col = blend(idleColor, accent, t)
            (item.getChildAt(0) as? BarIcon)?.tint = col
            (item.getChildAt(2) as? TextView)?.setTextColor(col)
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    override fun dispatchDraw(c: Canvas) {
        drawBody(c)
        if (childCount > 0) {
            if (pillCx < 0f) { pillCx = tabCx(selected); updateTints() }
            val ch = getChildAt(0)
            val sc = 1f + 0.16f * press
            val hw = ch.width / 2f * sc
            val cy = (ch.top + ch.bottom) / 2f
            val hh = (ch.bottom - ch.top) / 2f * sc
            rect.set(pillCx - hw, cy - hh, pillCx + hw, cy + hh)
            // selected pill: andar dabi hui dark glass; press par halki aur chamakdaar ho jaati hai
            val dk = if (darkUi) 1f else 0.55f
            val fa = ((if (darkUi) 92 else 46) * (1f - 0.62f * press)).toInt()
            fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, intArrayOf(
                Color.argb((fa * 1.25f).toInt().coerceAtMost(255), 0, 0, 0),
                Color.argb((fa * 0.7f).toInt(), 0, 0, 0)
            ), null, Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, hh, hh, fill)
            fill.shader = null
            fill.color = Color.argb((26 + 20 * press).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(rect, hh, hh, fill)
            ring.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, intArrayOf(
                Color.argb((16 * dk + 70 * press).toInt(), 255, 255, 255),
                Color.argb((10 + 30 * press).toInt(), 255, 255, 255),
                Color.argb((60 * dk + 170 * press).toInt().coerceAtMost(255), 255, 255, 255)
            ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, hh, hh, ring)
            ring.shader = null
        }
        super.dispatchDraw(c)
    }

    override fun onInterceptTouchEvent(e: MotionEvent) = true

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                dragging = false
                animatePress(1f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.x - downX) > slop) {
                    dragging = true
                    slideAnim?.cancel()
                }
                if (dragging && childCount > 0) {
                    setPill(e.x.coerceIn(tabCx(0), tabCx(childCount - 1)))
                    val n = nearest(pillCx)
                    if (n != selected) { selected = n; onSelect?.invoke(n) }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val target = when {
                    e.actionMasked == MotionEvent.ACTION_CANCEL -> selected
                    dragging -> nearest(pillCx)
                    else -> nearest(e.x)
                }
                dragging = false
                animatePress(0f)
                if (target != selected) { selected = target; onSelect?.invoke(target) }
                slideTo(tabCx(target))
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

/** Liquid-glass panel (dialog ke liye): frosted body + gold glow + specular highlight + shimmer sweep + gradient rim. */
class GlassPanelDrawable(private val radius: Float, private val dark: Boolean, private val blurred: Boolean, private val strokePx: Float, private val gold: Int = Pal.GOLD) :
    android.graphics.drawable.Drawable() {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val goldTopP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val goldBotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val specP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val shimP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx }
    private val rim2P = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx * 0.7f }
    private val goldRimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx * 0.8f }
    private val clip = Path()
    private val r = RectF()
    private val shimM = Matrix()
    private var phase = -1f
    private var anim: ValueAnimator? = null
    private var W = 0f
    private var H = 0f

    /** Shimmer: ek chamakdaar patti kabhi-kabhi tirchi nikalti hai. */
    fun startShimmer() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(-0.4f, 2.2f).apply {
            duration = 4200
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }
    fun stopShimmer() { anim?.cancel(); anim = null }

    override fun onBoundsChange(b: android.graphics.Rect) {
        W = b.width().toFloat(); H = b.height().toFloat()
        r.set(b)
        val baseA = if (blurred) (if (dark) 120 else 178) else (if (dark) 240 else 246)
        val base = if (dark) Color.rgb(30, 32, 44) else Color.WHITE
        fillP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb(baseA, Color.red(base), Color.green(base), Color.blue(base)),
            Color.argb((baseA * 0.8f).toInt(), Color.red(base), Color.green(base), Color.blue(base))
        ), null, Shader.TileMode.CLAMP)
        sheenP.shader = LinearGradient(0f, 0f, W * 0.65f, H * 0.75f,
            Color.argb(if (dark) 60 else 110, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        glowP.shader = LinearGradient(0f, H * 0.62f, 0f, H,
            Color.TRANSPARENT, Color.argb(if (dark) 58 else 90, 255, 255, 255), Shader.TileMode.CLAMP)
        val gr = Color.red(gold); val gg = Color.green(gold); val gb = Color.blue(gold)
        // gold glow: upar-left ka bada halo + neeche-right ki halki aanch
        goldTopP.shader = android.graphics.RadialGradient(W * 0.18f, 0f, W * 0.75f,
            Color.argb(if (dark) 92 else 70, gr, gg, gb), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        goldBotP.shader = android.graphics.RadialGradient(W * 0.9f, H, W * 0.6f,
            Color.argb(if (dark) 70 else 52, gr, gg, gb), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        // specular highlight: upar ki patli chamakti line, siron par fade
        specP.strokeWidth = strokePx * 1.4f
        specP.shader = LinearGradient(W * 0.08f, 0f, W * 0.92f, 0f, intArrayOf(
            Color.TRANSPARENT, Color.argb(235, 255, 255, 255), Color.argb(235, 255, 255, 255), Color.TRANSPARENT
        ), floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        shimP.shader = LinearGradient(0f, 0f, W * 0.34f, 0f, intArrayOf(
            Color.TRANSPARENT, Color.argb(if (dark) 70 else 120, 255, 255, 255), Color.TRANSPARENT
        ), null, Shader.TileMode.CLAMP)
        rimP.shader = LinearGradient(0f, 0f, 0f, H, intArrayOf(
            Color.argb(170, 255, 255, 255), Color.argb(34, 255, 255, 255),
            Color.argb(50, 255, 255, 255), Color.argb(240, 255, 255, 255)
        ), floatArrayOf(0f, 0.4f, 0.65f, 1f), Shader.TileMode.CLAMP)
        rim2P.shader = LinearGradient(0f, 0f, W, H, intArrayOf(
            Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(60, 255, 255, 255)
        ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        goldRimP.shader = LinearGradient(0f, 0f, W, H, intArrayOf(
            Color.argb(200, gr, gg, gb), Color.argb(0, gr, gg, gb), Color.argb(170, gr, gg, gb)
        ), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        clip.reset(); clip.addRoundRect(r, radius, radius, Path.Direction.CW)
    }

    override fun draw(c: Canvas) {
        c.drawRoundRect(r, radius, radius, fillP)
        c.save(); c.clipPath(clip)
        c.drawRect(r, goldTopP); c.drawRect(r, goldBotP)
        c.drawRect(r, sheenP); c.drawRect(r, glowP)
        if (phase > -0.3f && phase < 1.3f) {   // shimmer sweep (tirchi patti)
            c.save()
            c.rotate(18f, W / 2f, H / 2f)
            shimM.setTranslate(-W * 0.34f + phase * (W * 1.5f), 0f)
            shimP.shader.setLocalMatrix(shimM)
            c.drawRect(-W * 0.3f, -H * 0.5f, W * 1.6f, H * 1.5f, shimP)
            c.restore()
        }
        c.restore()
        val h1 = strokePx / 2f
        c.drawRoundRect(r.left + h1, r.top + h1, r.right - h1, r.bottom - h1, radius - h1, radius - h1, rimP)
        val h2 = strokePx + rim2P.strokeWidth / 2f + 1f
        val rr = (radius - h2).coerceAtLeast(1f)
        c.drawRoundRect(r.left + h2, r.top + h2, r.right - h2, r.bottom - h2, rr, rr, rim2P)
        val h3 = h2 + rim2P.strokeWidth / 2f + goldRimP.strokeWidth / 2f + 1f
        val r3 = (radius - h3).coerceAtLeast(1f)
        c.drawRoundRect(r.left + h3, r.top + h3, r.right - h3, r.bottom - h3, r3, r3, goldRimP)
        // specular line, thoda andar upar
        val y = strokePx * 3.2f
        c.drawLine(W * 0.08f, y, W * 0.92f, y, specP)
    }

    override fun getOutline(o: Outline) { o.setRoundRect(bounds, radius); o.alpha = 1f }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
