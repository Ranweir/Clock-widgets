package com.example.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import java.util.Calendar

object Fit {
    /**
     * Widget ki shape se 0..1: 0 = chauda/square (row layout), 1 = lamba (stack layout).
     * Beech ke sizes par continuous rehta hai, isliye resize karte waqt layout smoothly morph hota hai.
     */
    fun morphFor(w: Int, h: Int): Float {
        val aspect = w.toFloat() / h.coerceAtLeast(1)
        val t = ((1.0f - aspect) / 0.4f).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)   // smoothstep
    }

    /** Content (ox,oy,cw,ch) ko W x H me beech me fit karta hai; pct = user size %. */
    fun apply(c: Canvas, cw: Float, ch: Float, W: Int, H: Int, pct: Int, ox: Float = 0f, oy: Float = 0f, fill: Float = 0.98f) {
        val s = minOf(W * fill / cw, H * fill / ch) * pct.coerceIn(20, 100) / 100f
        c.translate(W / 2f, H / 2f)
        c.scale(s, s)
        c.translate(-(ox + cw / 2f), -(oy + ch / 2f))
    }
}

object ClockEngine {
    fun nameOf(ctx: Context, id: String): String =
        Builtins.spec(id)?.name
            ?: (if (id.startsWith("t:")) ThemeStore.name(ctx, id.substring(2)) else null)
            ?: (if (id.startsWith("k:")) KwgtStore.name(ctx, id.substring(2)) else null)
            ?: "Unknown clock"

    private val PARTS = listOf("main", "colon", "date")

    /**
     * Glow style me halo kat na jaye isliye clock render me thoda chhota hota hai (max 85%).
     * Ye sirf render me hota hai: user ka Size slider/setting waisa hi rehta hai, to dusri style par
     * jaate hi clock apne poore size par wapas aa jaata hai.
     */
    private fun effScale(cfg: Cfg): Int = if (cfg.style == 5 && !cfg.flux) minOf(cfg.scale, 85) else cfg.scale

    /** 0..100 slider -> 0.6x .. 1.6x (50 = original). */
    private fun stretchOf(v: Int): Float = if (v < 50) 0.6f + 0.4f * v / 50f else 1f + 0.6f * (v - 50) / 50f

    /** Digits ko moti (r > 0) ya patli (r < 0) karta hai: alpha ko kuch pixels shift karke jodte / ghatate hain. */
    private fun thicken(src: Bitmap, r: Float): Bitmap {
        if (Math.abs(r) < 0.5f) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rad = Math.abs(r)
        val rings = floatArrayOf(rad * 0.5f, rad)
        val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
        if (r > 0) {
            for (rr in rings) for (i in 0 until 8) {
                val a = Math.PI * 2 * i / 8
                c.drawBitmap(src, (Math.cos(a) * rr).toFloat(), (Math.sin(a) * rr).toFloat(), p)
            }
            c.drawBitmap(src, 0f, 0f, p)
        } else {
            c.drawBitmap(src, 0f, 0f, p)
            p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
            for (rr in rings) for (i in 0 until 8) {
                val a = Math.PI * 2 * i / 8
                c.drawBitmap(src, (Math.cos(a) * rr).toFloat(), (Math.sin(a) * rr).toFloat(), p)
            }
        }
        return out
    }

    /**
     * Digits ke upar ki opacity: v < 50 = upar se transparent (neeche solid), v > 50 = upar ka hissa aur solid.
     * Content ki asli upar/neeche (alpha bounds) ke beech vertical gradient lagta hai.
     */
    private fun topFade(src: Bitmap, v: Int): Bitmap {
        if (v == 50) return src
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var top = -1
        var bot = -1
        for (y in 0 until h) {
            var any = false
            for (x in 0 until w step 2) if ((px[y * w + x] ushr 24) > 12) { any = true; break }
            if (any) { if (top < 0) top = y; bot = y }
        }
        if (top < 0 || bot <= top) return src
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, 0f, 0f, null)
        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mask)
        mc.drawBitmap(src, 0f, 0f, null)
        val p = android.graphics.Paint()
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        if (v < 50) {
            // upar transparent -> neeche poora: out ko gradient se mask karo
            val a = (v / 50f)
            p.shader = android.graphics.LinearGradient(0f, top.toFloat(), 0f, bot.toFloat(),
                Color.argb((a * 255).toInt(), 0, 0, 0), Color.BLACK, android.graphics.Shader.TileMode.CLAMP)
            val o2 = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val oc = Canvas(o2)
            oc.drawBitmap(src, 0f, 0f, null)
            oc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            mask.recycle(); out.recycle()
            return o2
        }
        // upar aur solid: apni hi copy upar ke gradient ke saath upar se chadha do
        val a = (v - 50) / 50f
        p.shader = android.graphics.LinearGradient(0f, top.toFloat(), 0f, bot.toFloat(),
            Color.argb((a * 255).toInt(), 0, 0, 0), Color.TRANSPARENT, android.graphics.Shader.TileMode.CLAMP)
        mc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        c.drawBitmap(mask, 0f, 0f, null)
        mask.recycle()
        return out
    }

    fun render(ctx: Context, cfg: Cfg, W: Int, H: Int, morph: Float? = null): Bitmap {
        val w = W.coerceAtLeast(1)
        val h = H.coerceAtLeast(1)
        // size effects/layers on-off karne par kabhi nahi badalta
        val fill = 0.95f
        val cal = Calendar.getInstance()

        // KWGT widget: apne rang/effects ke saath seedha draw (glass effects unke rang nahi badalte)
        if (cfg.clockId.startsWith("k:")) {
            val kroot = KwgtStore.root(ctx, cfg.clockId.substring(2))
            if (kroot != null) return KwgtRenderer.render(ctx, kroot, w, h, cfg.scale)
        }

        var layers: Map<String, Bitmap>? = null
        if (cfg.clockId.startsWith("t:")) {
            val root = ThemeStore.root(ctx, cfg.clockId.substring(2))
            if (root != null) layers = ThemeRenderer.renderLayers(root, w, h, effScale(cfg), fill, cfg.colon || root.let { r -> !ThemeStore.hasLayer(r, "show_colon") }, cfg.showDate, morph ?: Fit.morphFor(w, h), cfg.use12h,
                vStretch = stretchOf(cfg.tStretch), redStrength = cfg.tRed / 50f)
        } else {
            layers = builtinLayers(Builtins.spec(cfg.clockId) ?: Builtins.list.first(), cfg, w, h, fill, cal)
        }
        if (layers == null) layers = builtinLayers(Builtins.list.first(), cfg, w, h, fill, cal)

        // Backdrop blur sirf "Blur" style me (aur tabhi jab Blur slider > 0); baaki styles par koi chhupa asar nahi
        val backdrop = cfg.style == 2 && cfg.blur > 0 && !cfg.flux
        val useWall = backdrop && Effects.pv(cfg.s3, 1) == 1
        val wall = if (useWall || (cfg.flux && WallStore.usable(ctx))) WallStore.crop(ctx, w, h, cfg.wallY, cfg.wallX) else null
        // Wallpaper pata ho to rang widget ke peeche wale hisse se, warna poore wallpaper ke system colours se
        val tints = if (wall != null) Effects.tintsFrom(wall)
        else if (cfg.flux || backdrop) Effects.wallpaperTints(ctx) else Pair(Pal.ICE, Pal.ICE)

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        for (part in PARTS) {
            var base = layers[part] ?: continue
            val isT = cfg.clockId.startsWith("t:")
            if (isT && part == "main" && cfg.tThick != 50) base = thicken(base, (cfg.tThick - 50) / 50f * w * 0.012f)
            if (isT && part == "main" && cfg.tTop != 50) base = topFade(base, cfg.tTop)
            val glow = when (part) {
                "date" -> if (cfg.dateGlow >= 0) cfg.dateGlow else cfg.glow
                "colon" -> if (cfg.colGlow >= 0) cfg.colGlow else cfg.glow
                else -> cfg.glow
            }
            val clear = when (part) {
                "date" -> if (cfg.dateClear >= 0) cfg.dateClear else cfg.clear
                "colon" -> if (cfg.colClear >= 0) cfg.colClear else cfg.clear
                else -> cfg.clear
            }
            var fx = if (cfg.flux) Effects.flux(base, tints.first, tints.second, glow, clear)
            else Effects.styled(base, if (cfg.style == 2 && !backdrop) 0 else cfg.style, glow, cfg.glowColor, cfg.accent, cfg)
            if (backdrop) {
                fx = Effects.withBackdrop(base, fx, cfg.blur, cfg.bgGlow, tints.first, tints.second, wall, glow, cfg.glowColor, clear)
            }
            val op = if (!isT) 100 else if (part == "date") cfg.dOpa else cfg.tOpa
            if (op >= 100) oc.drawBitmap(fx, 0f, 0f, null)
            else oc.drawBitmap(fx, 0f, 0f, android.graphics.Paint().apply { alpha = (op * 255 / 100).coerceIn(0, 255) })
        }
        return out
    }

    private fun builtinLayers(b: Builtins.Spec, cfg: Cfg, w: Int, h: Int, fill: Float, cal: Calendar): Map<String, Bitmap> {
        val map = HashMap<String, Bitmap>()
        for (part in PARTS) {
            if (!Builtins.hasPart(b.id, part, cfg.colon, cfg.showDate)) continue
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            Fit.apply(c, b.w.toFloat(), b.h.toFloat(), w, h, effScale(cfg), 0f, 0f, fill)
            Builtins.draw(b.id, c, cfg.accent, cfg.use12h, cal, part)
            map[part] = bmp
        }
        return map
    }
}
