package com.example.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import java.util.Calendar

object Fit {
    /** Content (ox,oy,cw,ch) ko W x H me beech me fit karta hai; pct = user size %. */
    fun apply(c: Canvas, cw: Float, ch: Float, W: Int, H: Int, pct: Int, ox: Float = 0f, oy: Float = 0f, fill: Float = 0.98f) {
        val s = minOf(W * fill / cw, H * fill / ch) * pct.coerceIn(20, 100) / 100f
        c.translate(W / 2f, H / 2f)
        c.scale(s, s)
        c.translate(-(ox + cw / 2f), -(oy + ch / 2f))
    }
}

object ClockEngine {
    fun nameOf(ctx: Context, id: String): String =
        Builtins.spec(id)?.name
            ?: (if (id.startsWith("t:")) ThemeStore.name(ctx, id.substring(2)) else null)
            ?: "Unknown clock"

    private val PARTS = listOf("main", "colon", "date")

    fun render(ctx: Context, cfg: Cfg, W: Int, H: Int): Bitmap {
        val w = W.coerceAtLeast(1)
        val h = H.coerceAtLeast(1)
        // size effects/layers on-off karne par kabhi nahi badalta
        val fill = 0.95f
        val cal = Calendar.getInstance()

        var layers: Map<String, Bitmap>? = null
        if (cfg.clockId.startsWith("t:")) {
            val root = ThemeStore.root(ctx, cfg.clockId.substring(2))
            if (root != null) layers = ThemeRenderer.renderLayers(root, w, h, cfg.scale, fill, cfg.colon, cfg.showDate)
        } else {
            layers = builtinLayers(Builtins.spec(cfg.clockId) ?: Builtins.list.first(), cfg, w, h, fill, cal)
        }
        if (layers == null) layers = builtinLayers(Builtins.list.first(), cfg, w, h, fill, cal)

        val wall = if (cfg.blur > 0 || (cfg.flux && WallStore.usable(ctx))) WallStore.crop(ctx, w, h, cfg.wallY, cfg.wallX) else null
        // Wallpaper pata ho to rang widget ke peeche wale hisse se, warna poore wallpaper ke system colours se
        val tints = if (wall != null) Effects.tintsFrom(wall)
        else if (cfg.flux || cfg.blur > 0) Effects.wallpaperTints(ctx) else Pair(Pal.ICE, Pal.ICE)

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        for (part in PARTS) {
            val base = layers[part] ?: continue
            val glow = when (part) {
                "date" -> if (cfg.dateGlow >= 0) cfg.dateGlow else cfg.glow
                "colon" -> if (cfg.colGlow >= 0) cfg.colGlow else cfg.glow
                else -> cfg.glow
            }
            val clear = when (part) {
                "date" -> if (cfg.dateClear >= 0) cfg.dateClear else cfg.clear
                "colon" -> if (cfg.colClear >= 0) cfg.colClear else cfg.clear
                else -> cfg.clear
            }
            var fx = if (cfg.flux) Effects.flux(base, tints.first, tints.second, glow, clear)
            else Effects.apply(base, cfg.glass, glow, cfg.glowColor)
            if (part == "main" && cfg.blur > 0) {
                fx = Effects.withBackdrop(base, fx, cfg.blur, cfg.bgGlow, tints.first, tints.second, wall)
            }
            oc.drawBitmap(fx, 0f, 0f, null)
        }
        return out
    }

    private fun builtinLayers(b: Builtins.Spec, cfg: Cfg, w: Int, h: Int, fill: Float, cal: Calendar): Map<String, Bitmap> {
        val map = HashMap<String, Bitmap>()
        for (part in PARTS) {
            if (!Builtins.hasPart(b.id, part, cfg.colon, cfg.showDate)) continue
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            Fit.apply(c, b.w.toFloat(), b.h.toFloat(), w, h, cfg.scale, 0f, 0f, fill)
            Builtins.draw(b.id, c, cfg.accent, cfg.use12h, cal, part)
            map[part] = bmp
        }
        return map
    }
}
