package com.example.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import java.util.Calendar

object Fit {
    /** Content (ox,oy,cw,ch) ko W x H me beech me fit karta hai; pct = user size %. */
    fun apply(c: Canvas, cw: Float, ch: Float, W: Int, H: Int, pct: Int, ox: Float = 0f, oy: Float = 0f, fill: Float = 0.98f) {
        val s = minOf(W * fill / cw, H * fill / ch) * pct.coerceIn(20, 100) / 100f
        c.translate(W / 2f, H / 2f)
        c.scale(s, s)
        c.translate(-(ox + cw / 2f), -(oy + ch / 2f))
    }
}

object ClockEngine {
    fun nameOf(ctx: Context, id: String): String =
        Builtins.spec(id)?.name
            ?: (if (id.startsWith("t:")) ThemeStore.name(ctx, id.substring(2)) else null)
            ?: "Unknown clock"

    fun render(ctx: Context, cfg: Cfg, W: Int, H: Int): Bitmap {
        val bmp = Bitmap.createBitmap(W.coerceAtLeast(1), H.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // glow/glass ke liye kinaron par jagah chhodte hain
        // size effects on/off karne par kabhi nahi badalta
        val fill = 0.95f
        val cal = Calendar.getInstance()

        var done = false
        if (cfg.clockId.startsWith("t:")) {
            val root = ThemeStore.root(ctx, cfg.clockId.substring(2))
            if (root != null) done = ThemeRenderer.draw(root, c, W, H, cfg.scale, fill, cfg.colon)
        } else {
            val b = Builtins.spec(cfg.clockId)
            if (b != null) {
                c.save()
                Fit.apply(c, b.w.toFloat(), b.h.toFloat(), W, H, cfg.scale, 0f, 0f, fill)
                Builtins.draw(b.id, c, cfg.accent, cfg.use12h, cal, cfg.colon)
                c.restore()
                done = true
            }
        }
        if (!done) {
            // theme delete ho gayi ho to pehla built-in dikhao
            val b = Builtins.list.first()
            c.save()
            Fit.apply(c, b.w.toFloat(), b.h.toFloat(), W, H, cfg.scale, 0f, 0f, fill)
            Builtins.draw(b.id, c, cfg.accent, cfg.use12h, cal, cfg.colon)
            c.restore()
        }
        val tints = if (cfg.flux || cfg.blur > 0) Effects.wallpaperTints(ctx) else Pair(Pal.ICE, Pal.ICE)
        val fx = if (cfg.flux) Effects.flux(bmp, tints.first, tints.second, cfg.glow, cfg.clear)
        else Effects.apply(bmp, cfg.glass, cfg.glow, cfg.glowColor)
        if (cfg.blur <= 0) return fx
        val wall = WallStore.crop(ctx, W, H, cfg.wallY)
        return Effects.withBackdrop(bmp, fx, cfg.blur, cfg.bgGlow, tints.first, tints.second, wall)
    }
}
