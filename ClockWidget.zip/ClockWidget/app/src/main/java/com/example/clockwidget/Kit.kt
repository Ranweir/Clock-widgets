package com.example.clockwidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.TypedValue
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * "Kit" look for the clock customisation page: soft glossy cards, raised 3D pill buttons
 * and sliders with a glossy knob. Sirf app ke apne rang (gold / surface); koi naya rang nahi.
 */
private fun mixc(a: Int, b: Int, t: Float): Int = Color.rgb(
    (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
    (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
    (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
)
private fun lighten(c: Int, t: Float) = mixc(c, Color.WHITE, t)
private fun darken(c: Int, t: Float) = mixc(c, Color.BLACK, t)

/** Ek soft raised card; sections isi ke andar jaate hain. */
fun Context.kitCard(parent: LinearLayout): LinearLayout {
    val dark = Pal.dark
    val top = if (dark) lighten(Pal.uSurface, 0.07f) else Color.WHITE
    val bot = if (dark) Pal.uSurface else mixc(Pal.uSurface2, Color.WHITE, 0.6f)
    val card = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(20))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot)).apply {
            cornerRadius = dp(26).toFloat()
            setStroke(dp(1), if (dark) Color.argb(46, 255, 255, 255) else (Pal.uStroke and 0x00FFFFFF) or (0x8C shl 24))
        }
        elevation = dp(if (dark) 4 else 6).toFloat()
    }
    parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(18) })
    return card
}

/** Card ka section heading. */
fun Context.sec(text: String) =
    tv(text, 16f, Pal.uTitle, Typeface.create("sans-serif-medium", Typeface.BOLD))

/** Slider ki value (right side). */
fun Context.kval(text: String) =
    tv(text, 13f, Pal.uTitle, Typeface.create("sans-serif-medium", Typeface.NORMAL))

/** Raised 3D pill button. */
fun Context.kchip(text: String) = TextView(this).apply {
    this.text = text
    textSize = 12f
    letterSpacing = 0.14f
    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    gravity = Gravity.CENTER
    setPadding(dp(20), dp(12), dp(20), dp(12))
    stateListAnimator = null
    pressFeedback(0.95f)
}

fun Context.kstyle(t: TextView, selected: Boolean) {
    val dark = Pal.dark
    val r = dp(26).toFloat()
    if (selected) {
        val g = Pal.uGold
        t.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(lighten(g, 0.35f), g, darken(g, 0.18f))).apply {
            cornerRadius = r
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
        t.setTextColor(Pal.uOnGold)
        t.elevation = dp(2).toFloat()
    } else {
        val top = if (dark) lighten(Pal.uSurface2, 0.10f) else Color.WHITE
        val bot = if (dark) Pal.uSurface2 else mixc(Pal.uSurface2, Color.WHITE, 0.35f)
        t.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot)).apply {
            cornerRadius = r
            setStroke(dp(1), if (dark) Color.argb(40, 255, 255, 255) else Pal.uStroke)
        }
        t.setTextColor(Pal.uText)
        t.elevation = dp(4).toFloat()
    }
}

/** SeekBar ko inset track + gradient fill + glossy white knob deta hai (behaviour same). */
fun SeekBar.kit() {
    if (this is GlowSeekBar) return      // GlowSeekBar apne aap draw karta hai
    val c = context
    val dark = Pal.dark
    val h = c.dp(10)
    val track = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(darken(Pal.uSurface2, if (dark) 0.35f else 0.10f), Pal.uSurface2)).apply { cornerRadius = h / 2f }
    val fillG = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(mixc(Pal.uGold, Pal.uSurface2, 0.65f), Pal.uGold)).apply { cornerRadius = h / 2f }
    val prog = ClipDrawable(fillG, Gravity.START, ClipDrawable.HORIZONTAL)
    val layers = LayerDrawable(arrayOf(track, prog)).apply {
        setId(0, android.R.id.background)
        setId(1, android.R.id.progress)
        for (i in 0..1) { setLayerHeight(i, h); setLayerGravity(i, Gravity.CENTER_VERTICAL) }
    }
    progressDrawable = layers

    val d = c.dp(30)
    val shadow = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.argb(if (dark) 110 else 55, 0, 0, 0))
        setSize(d, d)
    }
    val knob = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.WHITE, Color.rgb(214, 214, 220))).apply {
        shape = GradientDrawable.OVAL
        setSize(d, d)
        setStroke(c.dp(1), Color.argb(200, 255, 255, 255))
    }
    thumb = LayerDrawable(arrayOf(shadow, knob)).apply {
        setLayerInset(0, c.dp(2), c.dp(4), c.dp(2), 0)
        setLayerInset(1, c.dp(2), 0, c.dp(2), c.dp(3))
    }
    thumbOffset = 0
    splitTrack = false
    setPadding(c.dp(14), 0, c.dp(14), 0)
}

/** Title + bold value + kit slider. */
fun Context.ksliderRow(col: LinearLayout, title: String, value: Int, onChange: (Int) -> Unit) {
    val head = LinearLayout(this)
    head.addView(tv(title, 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val v = kval("$value%")
    head.addView(v.apply { visibility = android.view.View.GONE })   // value ab slider ke pill me dikhti hai
    col.addView(spacer(16))
    col.addView(head)
    col.addView(spacer(2))
    col.addView(GlowSeekBar(this).apply {
        max = 100
        progress = value
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                v.text = "$p%"
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    })
}


/**
 * Red glow slider (patla track): thin inset track, red fill jo apne aas-paas halka glow chhodti hai,
 * aur chhota glowing red pill thumb jisme current value % me likhi hoti hai (0% ... 100%).
 * SeekBar hi hai, isliye listener / max / progress ka code waisa hi chalta hai.
 */
class GlowSeekBar(ctx: Context) : SeekBar(ctx) {
    /** Pill me dikhne wali value = progress + valueMin (jaise Size slider 30..100%). */
    var valueMin = 0

    private val d = ctx.resources.displayMetrics.density
    private val pillW = 42f * d
    private val pillH = 22f * d
    private val trackH = 4f * d
    /** Glow ke liye jagah: pill 0% / 100% par bhi uska glow view se bahar nahi kat-ta. */
    private val edge = 17f * d
    private val rect = RectF()
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 0.8f }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 11f, ctx.resources.displayMetrics)
    }

    init {
        thumb = null
        splitTrack = false
        val pad = (edge + pillW / 2f).toInt()      // touch mapping = pill ke centre ki range
        setPadding(pad, 0, pad, 0)
        minimumHeight = (56f * d).toInt()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(resolveSize(suggestedMinimumWidth, wSpec), (56f * d).toInt())
    }

    // progress badalte hi dobara draw (listener wrap: caller ka listener waisa hi chalta hai)
    override fun setOnSeekBarChangeListener(l: OnSeekBarChangeListener?) {
        super.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { invalidate(); l?.onProgressChanged(s, p, fromUser) }
            override fun onStartTrackingTouch(s: SeekBar?) { l?.onStartTrackingTouch(s) }
            override fun onStopTrackingTouch(s: SeekBar?) { l?.onStopTrackingTouch(s) }
        })
    }

    /** Capsule ke chaaron taraf soft glow: bahar ki taraf alpha girta jaata hai (blur-mask ke bina, har phone par chalta hai). */
    private fun glow(c: Canvas, l: Float, t: Float, r: Float, b: Float, red: Int, layers: Int, step: Float, aMax: Float) {
        val rr = Color.red(red); val gg = Color.green(red); val bb = Color.blue(red)
        for (i in layers downTo 1) {
            val k = i / layers.toFloat()                 // 1 = sabse bahar
            val a = (aMax * (1f - k) * (1f - k) + aMax * 0.12f).toInt().coerceIn(0, 255)
            val g = i * step
            rect.set(l - g, t - g, r + g, b + g)
            glowP.color = Color.argb(a, rr, gg, bb)
            c.drawRoundRect(rect, (b - t) / 2f + g, (b - t) / 2f + g, glowP)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val dark = Pal.dark
        val red = Pal.uGold
        val gk = if (dark) 1f else 0.6f
        val frac = if (max > 0) progress.toFloat() / max else 0f
        val tl = paddingLeft.toFloat()
        val tr = w - paddingRight
        val cx = tl + frac * (tr - tl)

        // patla track (andar dabaa hua)
        rect.set(edge, cy - trackH / 2f, w - edge, cy + trackH / 2f)
        trackP.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            darken(Pal.uSurface2, if (dark) 0.45f else 0.12f), lighten(Pal.uSurface2, if (dark) 0.05f else 0f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, trackH / 2f, trackH / 2f, trackP)

        // fill ka glow (patla, track ke saath)
        glow(c, edge, cy - trackH / 2f, cx, cy + trackH / 2f, red, 7, d * 0.9f, 30f * gk)
        // fill
        rect.set(edge, cy - trackH / 2f, cx, cy + trackH / 2f)
        fillP.shader = LinearGradient(edge, 0f, cx.coerceAtLeast(edge + 1f), 0f,
            darken(red, 0.25f), lighten(red, 0.10f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, trackH / 2f, trackH / 2f, fillP)

        // pill ke aas-paas bada laal glow
        val pl = cx - pillW / 2f; val pr = cx + pillW / 2f
        val pt = cy - pillH / 2f; val pb = cy + pillH / 2f
        glow(c, pl, pt, pr, pb, red, 14, d * 1.15f, 44f * gk)

        // pill thumb + value
        rect.set(pl, pt, pr, pb)
        pillP.shader = LinearGradient(0f, pt, 0f, pb, lighten(red, 0.20f), darken(red, 0.08f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, pillH / 2f, pillH / 2f, pillP)
        ringP.color = Color.argb(120, 255, 255, 255)
        rect.inset(d * 0.4f, d * 0.4f)
        c.drawRoundRect(rect, pillH / 2f, pillH / 2f, ringP)
        val fm = textP.fontMetrics
        c.drawText("${progress + valueMin}%", cx, cy - (fm.ascent + fm.descent) / 2f, textP)
    }
}
