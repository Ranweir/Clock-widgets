package com.example.clockwidget

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * "Kit" look for the clock customisation page: soft glossy cards, raised 3D pill buttons
 * and sliders with a glossy knob. Sirf app ke apne rang (gold / surface); koi naya rang nahi.
 */
private fun mixc(a: Int, b: Int, t: Float): Int = Color.rgb(
    (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
    (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
    (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
)
private fun lighten(c: Int, t: Float) = mixc(c, Color.WHITE, t)
private fun darken(c: Int, t: Float) = mixc(c, Color.BLACK, t)

/** Ek soft raised card; sections isi ke andar jaate hain. */
fun Context.kitCard(parent: LinearLayout): LinearLayout {
    val dark = Pal.dark
    val top = if (dark) lighten(Pal.uSurface, 0.07f) else Color.WHITE
    val bot = if (dark) Pal.uSurface else mixc(Pal.uSurface2, Color.WHITE, 0.6f)
    val card = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(20))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot)).apply {
            cornerRadius = dp(26).toFloat()
            setStroke(dp(1), if (dark) Color.argb(46, 255, 255, 255) else (Pal.uStroke and 0x00FFFFFF) or (0x8C shl 24))
        }
        elevation = dp(if (dark) 4 else 6).toFloat()
    }
    parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(18) })
    return card
}

/** Card ka section heading. */
fun Context.sec(text: String) =
    tv(text, 16f, Pal.uTitle, Typeface.create("sans-serif-medium", Typeface.BOLD))

/** Slider ki value (right side). */
fun Context.kval(text: String) =
    tv(text, 13f, Pal.uTitle, Typeface.create("sans-serif-medium", Typeface.NORMAL))

/** Raised 3D pill button. */
fun Context.kchip(text: String) = TextView(this).apply {
    this.text = text
    textSize = 12f
    letterSpacing = 0.14f
    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    gravity = Gravity.CENTER
    setPadding(dp(20), dp(12), dp(20), dp(12))
    stateListAnimator = null
    pressFeedback(0.95f)
}

fun Context.kstyle(t: TextView, selected: Boolean) {
    val dark = Pal.dark
    val r = dp(26).toFloat()
    if (selected) {
        val g = Pal.uGold
        t.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(lighten(g, 0.35f), g, darken(g, 0.18f))).apply {
            cornerRadius = r
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
        t.setTextColor(Pal.uOnGold)
        t.elevation = dp(2).toFloat()
    } else {
        val top = if (dark) lighten(Pal.uSurface2, 0.10f) else Color.WHITE
        val bot = if (dark) Pal.uSurface2 else mixc(Pal.uSurface2, Color.WHITE, 0.35f)
        t.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot)).apply {
            cornerRadius = r
            setStroke(dp(1), if (dark) Color.argb(40, 255, 255, 255) else Pal.uStroke)
        }
        t.setTextColor(Pal.uText)
        t.elevation = dp(4).toFloat()
    }
}

/** SeekBar ko inset track + gradient fill + glossy white knob deta hai (behaviour same). */
fun SeekBar.kit() {
    val c = context
    val dark = Pal.dark
    val h = c.dp(10)
    val track = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(darken(Pal.uSurface2, if (dark) 0.35f else 0.10f), Pal.uSurface2)).apply { cornerRadius = h / 2f }
    val fillG = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(mixc(Pal.uGold, Pal.uSurface2, 0.65f), Pal.uGold)).apply { cornerRadius = h / 2f }
    val prog = ClipDrawable(fillG, Gravity.START, ClipDrawable.HORIZONTAL)
    val layers = LayerDrawable(arrayOf(track, prog)).apply {
        setId(0, android.R.id.background)
        setId(1, android.R.id.progress)
        for (i in 0..1) { setLayerHeight(i, h); setLayerGravity(i, Gravity.CENTER_VERTICAL) }
    }
    progressDrawable = layers

    val d = c.dp(30)
    val shadow = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.argb(if (dark) 110 else 55, 0, 0, 0))
        setSize(d, d)
    }
    val knob = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.WHITE, Color.rgb(214, 214, 220))).apply {
        shape = GradientDrawable.OVAL
        setSize(d, d)
        setStroke(c.dp(1), Color.argb(200, 255, 255, 255))
    }
    thumb = LayerDrawable(arrayOf(shadow, knob)).apply {
        setLayerInset(0, c.dp(2), c.dp(4), c.dp(2), 0)
        setLayerInset(1, c.dp(2), 0, c.dp(2), c.dp(3))
    }
    thumbOffset = 0
    splitTrack = false
    setPadding(c.dp(14), 0, c.dp(14), 0)
}

/** Title + bold value + kit slider. */
fun Context.ksliderRow(col: LinearLayout, title: String, value: Int, onChange: (Int) -> Unit) {
    val head = LinearLayout(this)
    head.addView(tv(title, 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val v = kval("$value%")
    head.addView(v)
    col.addView(spacer(16))
    col.addView(head)
    col.addView(spacer(6))
    col.addView(SeekBar(this).apply {
        kit()
        max = 100
        progress = value
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                v.text = "$p%"
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    })
}
