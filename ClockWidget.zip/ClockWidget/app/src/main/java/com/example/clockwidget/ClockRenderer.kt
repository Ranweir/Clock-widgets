package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

/** Xiaomi/MAML clock manifest ka simplified renderer: Var, Group, Image, Text, DateTime. */
object ClockRenderer {
    /** Widget ka design-height (theme 1080px chaudi maan ke). */
    const val DESIGN_H = 900

    fun render(root: File, outW: Int): Bitmap? {
        val doc = try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(File(root, "manifest.xml"))
        } catch (e: Exception) {
            return null
        }
        val el = doc.documentElement
        val designW = el.getAttribute("screenWidth").toDoubleOrNull() ?: 1080.0
        val scale = (outW / designW).toFloat()
        val outH = (DESIGN_H * scale).toInt().coerceAtLeast(1)

        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.scale(scale, scale)

        val cal = Calendar.getInstance()
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        var h12 = h24 % 12
        if (h12 == 0) h12 = 12
        val vars = HashMap<String, Any>()
        vars["hour24"] = h24.toDouble()
        vars["hour12"] = h12.toDouble()
        vars["minute"] = cal.get(Calendar.MINUTE).toDouble()
        vars["second"] = cal.get(Calendar.SECOND).toDouble()
        vars["date"] = cal.get(Calendar.DAY_OF_MONTH).toDouble()
        vars["month"] = cal.get(Calendar.MONTH).toDouble()
        vars["year"] = cal.get(Calendar.YEAR).toDouble()
        vars["day_of_week"] = cal.get(Calendar.DAY_OF_WEEK).toDouble()
        vars["view_width"] = designW
        vars["view_height"] = DESIGN_H.toDouble()
        // Weather provider (Xiaomi) ColorOS me nahi hota, isliye "no weather"
        vars["hasWeather"] = 0.0
        vars["weather_id"] = 0.0
        vars["weather_temp"] = 0.0

        Run(root, canvas, vars).children(el, 0f, 0f)
        return bmp
    }

    private class Run(val root: File, val canvas: Canvas, val vars: HashMap<String, Any>) {
        val expr = Expr { vars[it] }
        val cache = HashMap<String, Bitmap?>()
        val rootPath = root.canonicalPath + File.separator

        fun num(e: Element, n: String, def: Double = 0.0): Double =
            if (e.hasAttribute(n)) expr.evalNum(e.getAttribute(n)) else def

        fun visible(e: Element) = !e.hasAttribute("visibility") || num(e, "visibility") != 0.0

        fun children(parent: Element, ox: Float, oy: Float) {
            var n: Node? = parent.firstChild
            while (n != null) {
                if (n is Element) {
                    try {
                        handle(n, ox, oy)
                    } catch (ex: Exception) {
                        // ek element kharab ho to baaki chalte rahein
                    }
                }
                n = n.nextSibling
            }
        }

        fun handle(e: Element, ox: Float, oy: Float) {
            when (e.tagName) {
                "Var" -> {
                    val name = e.getAttribute("name")
                    if (name.isNotEmpty()) vars[name] = expr.eval(e.getAttribute("expression"))
                }
                "Group" -> if (visible(e)) {
                    children(e, ox + num(e, "x").toFloat(), oy + num(e, "y").toFloat())
                }
                "Image" -> if (visible(e)) drawImage(e, ox, oy)
                "Text" -> if (visible(e)) {
                    val txt = when {
                        e.hasAttribute("textExp") -> Expr.fmt(expr.eval(e.getAttribute("textExp")))
                        else -> e.getAttribute("text")
                    }
                    drawText(e, txt, ox, oy)
                }
                "DateTime" -> if (visible(e)) {
                    val f = e.getAttribute("format").ifEmpty { "HH:mm" }
                    val txt = try {
                        SimpleDateFormat(f, Locale.getDefault()).format(Date())
                    } catch (ex: Exception) {
                        ""
                    }
                    drawText(e, txt, ox, oy)
                }
            }
        }

        fun load(path: String): Bitmap? = cache.getOrPut(path) {
            val f = File(root, path)
            if (!f.canonicalPath.startsWith(rootPath) || !f.exists()) null
            else BitmapFactory.decodeFile(f.absolutePath)
        }

        fun drawImage(e: Element, ox: Float, oy: Float) {
            var src = e.getAttribute("src")
            if (e.hasAttribute("srcid")) {
                val idx = num(e, "srcid").toInt()
                src = src.replace(Regex("\\.(\\w+)$"), "_$idx.$1")
            }
            val bm = load(src) ?: return
            val w = num(e, "w", bm.width.toDouble()).toFloat()
            val h = num(e, "h", bm.height.toDouble()).toFloat()
            val x = ox + num(e, "x").toFloat()
            val y = oy + num(e, "y").toFloat()
            val left = when (e.getAttribute("align")) {
                "center" -> x - w / 2
                "right" -> x - w
                else -> x
            }
            val top = when (e.getAttribute("alignV")) {
                "center" -> y - h / 2
                "bottom" -> y - h
                else -> y
            }
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            paint.alpha = num(e, "alpha", 255.0).toInt().coerceIn(0, 255)
            canvas.drawBitmap(bm, null, RectF(left, top, left + w, top + h), paint)
        }

        fun drawText(e: Element, text: String, ox: Float, oy: Float) {
            if (text.isEmpty()) return
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.textSize = num(e, "size", 20.0).toFloat()
            val color = try {
                Color.parseColor(e.getAttribute("color").ifEmpty { "#FFFFFFFF" })
            } catch (ex: Exception) {
                Color.WHITE
            }
            paint.color = color
            val a = num(e, "alpha", 255.0).coerceIn(0.0, 255.0)
            paint.alpha = (Color.alpha(color) * a / 255.0).toInt()
            val fam = e.getAttribute("fontFamily")
            if (fam.isNotEmpty()) paint.typeface = Typeface.create(fam, Typeface.NORMAL)
            paint.textAlign = when (e.getAttribute("align")) {
                "center" -> Paint.Align.CENTER
                "right" -> Paint.Align.RIGHT
                else -> Paint.Align.LEFT
            }
            val x = ox + num(e, "x").toFloat()
            var y = oy + num(e, "y").toFloat()
            val fm = paint.fontMetrics
            y += when (e.getAttribute("alignV")) {
                "center" -> -(fm.ascent + fm.descent) / 2
                "bottom" -> -fm.descent
                else -> -fm.ascent
            }
            canvas.drawText(text, x, y, paint)
        }
    }
}
