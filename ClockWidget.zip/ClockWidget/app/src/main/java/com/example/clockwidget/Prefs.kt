package com.example.clockwidget

import android.content.Context
import android.graphics.Color

object Pal {
    val BG = Color.parseColor("#0A0A0D")
    val SURFACE = Color.parseColor("#15151B")
    val SURFACE2 = Color.parseColor("#1E1E26")
    val STROKE = Color.parseColor("#2C2C36")
    val GOLD = Color.parseColor("#D4AF37")
    val CHAMPAGNE = Color.parseColor("#EBDDB2")
    val IVORY = Color.parseColor("#F4F1EA")
    val MUTED = Color.parseColor("#8E8C96")
    val ICE = Color.parseColor("#D6E6FF")
    /** 0 = "match": clock ke apne rang (rang badalta nahi). */
    val glowColors = listOf(
        0,
        Color.parseColor("#FFFFFF"),
        GOLD,
        Color.parseColor("#E8A0A8"),
        Color.parseColor("#8FE3C0"),
        Color.parseColor("#C9A6FF"),
        Color.parseColor("#FF7A45")
    )
    val accents = listOf(
        GOLD,
        Color.parseColor("#EBDDB2"),
        Color.parseColor("#F4F1EA"),
        Color.parseColor("#E8A0A8"),
        Color.parseColor("#7FB2FF"),
        Color.parseColor("#8FE3C0"),
        Color.parseColor("#FF7A45"),
        Color.parseColor("#C9A6FF")
    )
}

/** Ek widget ki settings. */
data class Cfg(
    val clockId: String,
    val scale: Int = 100,
    val accent: Int = Pal.GOLD,
    val use12h: Boolean = true,
    val glow: Int = 35,
    val glass: Boolean = true,
    val glowColor: Int = 0,
    val flux: Boolean = false,
    val blur: Int = 0,
    val bgGlow: Int = 50,
    val clear: Int = 45,
    val wallY: Int = 20,
    val colon: Boolean = true,
    val showDate: Boolean = true,
    val dateGlow: Int = -1,
    val dateClear: Int = -1,
    val colGlow: Int = -1,
    val colClear: Int = -1
) {
    fun enc() = "$clockId|$scale|$accent|${if (use12h) 1 else 0}|$glow|${if (glass) 1 else 0}|$glowColor|${if (flux) 1 else 0}|$blur|$bgGlow|$clear|$wallY|${if (colon) 1 else 0}|${if (showDate) 1 else 0}|$dateGlow|$dateClear|$colGlow|$colClear"

    companion object {
        fun dec(s: String?): Cfg? {
            if (s == null) return null
            val p = s.split("|")
            if (p.size < 4) return null
            return try {
                Cfg(
                    p[0], p[1].toInt(), p[2].toInt(), p[3] == "1",
                    p.getOrNull(4)?.toIntOrNull() ?: 35,
                    (p.getOrNull(5) ?: "1") == "1",
                    p.getOrNull(6)?.toIntOrNull()?.let { if (it == Pal.ICE) 0 else it } ?: 0,
                    (p.getOrNull(7) ?: "0") == "1",
                    p.getOrNull(8)?.toIntOrNull() ?: 0,
                    p.getOrNull(9)?.toIntOrNull() ?: 50,
                    p.getOrNull(10)?.toIntOrNull() ?: 45,
                    p.getOrNull(11)?.toIntOrNull() ?: 20,
                    (p.getOrNull(12) ?: "1") == "1",
                    (p.getOrNull(13) ?: "1") == "1",
                    p.getOrNull(14)?.toIntOrNull() ?: -1,
                    p.getOrNull(15)?.toIntOrNull() ?: -1,
                    p.getOrNull(16)?.toIntOrNull() ?: -1,
                    p.getOrNull(17)?.toIntOrNull() ?: -1
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("aurum", Context.MODE_PRIVATE)

    fun draft(ctx: Context): Cfg =
        Cfg.dec(sp(ctx).getString("draft", null)) ?: Cfg(Builtins.list.first().id)

    fun setDraft(ctx: Context, c: Cfg) {
        sp(ctx).edit().putString("draft", c.enc()).apply()
    }

    fun widget(ctx: Context, id: Int): Cfg? = Cfg.dec(sp(ctx).getString("w$id", null))

    fun setWidget(ctx: Context, id: Int, c: Cfg) {
        sp(ctx).edit().putString("w$id", c.enc()).apply()
    }

    fun removeWidget(ctx: Context, id: Int) {
        sp(ctx).edit().remove("w$id").apply()
    }

    fun getInt(ctx: Context, key: String, def: Int): Int = sp(ctx).getInt(key, def)

    fun setInt(ctx: Context, key: String, v: Int) {
        sp(ctx).edit().putInt(key, v).apply()
    }
}
