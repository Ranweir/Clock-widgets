package com.example.clockwidget

import android.content.Context
import android.graphics.Color

object Pal {
    val BG = Color.parseColor("#0A0A0D")
    val SURFACE = Color.parseColor("#15151B")
    val SURFACE2 = Color.parseColor("#1E1E26")
    val STROKE = Color.parseColor("#2C2C36")
    val GOLD = Color.parseColor("#D4AF37")
    val CHAMPAGNE = Color.parseColor("#EBDDB2")
    val IVORY = Color.parseColor("#F4F1EA")
    val MUTED = Color.parseColor("#8E8C96")
    val accents = listOf(
        GOLD,
        Color.parseColor("#EBDDB2"),
        Color.parseColor("#F4F1EA"),
        Color.parseColor("#E8A0A8"),
        Color.parseColor("#7FB2FF"),
        Color.parseColor("#8FE3C0"),
        Color.parseColor("#FF7A45"),
        Color.parseColor("#C9A6FF")
    )
}

/** Ek widget ki settings. */
data class Cfg(
    val clockId: String,
    val scale: Int = 100,
    val accent: Int = Pal.GOLD,
    val use12h: Boolean = false
) {
    fun enc() = "$clockId|$scale|$accent|${if (use12h) 1 else 0}"

    companion object {
        fun dec(s: String?): Cfg? {
            if (s == null) return null
            val p = s.split("|")
            if (p.size < 4) return null
            return try {
                Cfg(p[0], p[1].toInt(), p[2].toInt(), p[3] == "1")
            } catch (e: Exception) {
                null
            }
        }
    }
}

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("aurum", Context.MODE_PRIVATE)

    fun draft(ctx: Context): Cfg =
        Cfg.dec(sp(ctx).getString("draft", null)) ?: Cfg(Builtins.list.first().id)

    fun setDraft(ctx: Context, c: Cfg) {
        sp(ctx).edit().putString("draft", c.enc()).apply()
    }

    fun widget(ctx: Context, id: Int): Cfg? = Cfg.dec(sp(ctx).getString("w$id", null))

    fun setWidget(ctx: Context, id: Int, c: Cfg) {
        sp(ctx).edit().putString("w$id", c.enc()).apply()
    }

    fun removeWidget(ctx: Context, id: Int) {
        sp(ctx).edit().remove("w$id").apply()
    }
}
