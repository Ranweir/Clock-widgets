package com.example.clockwidget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.os.Build

/** Glow + frosted-glass look (ColorOS style) jo kisi bhi clock bitmap par lagta hai. */
object Effects {

    fun apply(base: Bitmap, glass: Boolean, glow: Int, glowColor: Int): Bitmap {
        if (!glass && glow <= 0) return base
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (glass) {
            // halka drop shadow, taaki glass hawa me tairta dikhe
            blurredMask(c, base, m * 0.014f, Color.BLACK, 70, m * 0.008f)
            c.drawBitmap(glassBody(base, m), 0f, 0f, null)
        } else {
            c.drawBitmap(base, 0f, 0f, null)
        }

        // Glow sirf digits ke ANDAR (kinaron se andar ki taraf), bahar kuch nahi phailta
        if (glow > 0) {
            val k = glow / 100f
            if (glowColor == 0) {
                // Clock ke apne rang ko hi roshan karte hain, rang feeka nahi hota
                val bright = boost(base, 1.45f)
                edgeLight(c, base, bright, m * 0.035f, (255 * 0.90f * k).toInt())
                edgeLight(c, base, bright, m * 0.014f, (255 * 0.80f * k).toInt())
                bright.recycle()
            } else {
                innerGlow(c, base, m * 0.035f, glowColor, (255 * 0.90f * k).toInt())
                innerGlow(c, base, m * 0.014f, glowColor, (255 * 0.80f * k).toInt())
            }
        }
        return out
    }

    /** Digit ke kinare se andar ki taraf nikalta rang: (digit) minus (INNER-blur digit). */
    private fun innerGlow(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int) {
        if (alpha <= 0 || radius < 1f) return
        val w = base.width
        val h = base.height
        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.INNER)
        }, off)
        val mask = base.extractAlpha()
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { this.color = Color.WHITE })
        lc.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(),
            Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            this.alpha = alpha.coerceIn(0, 255)
        })
        layer.recycle()
        blurred.recycle()
        mask.recycle()
    }

    // ───────────── ColorOS 17 "Flux Glow" / Counter Glow ─────────────

    /** Wallpaper ke primary + secondary rang (API 27+); na mile to halka neela. Thoda vivid rakhte hain. */
    fun wallpaperTints(ctx: Context): Pair<Int, Int> {
        var p = Pal.ICE
        var s = Pal.ICE
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (wc != null) {
                    p = wc.primaryColor.toArgb()
                    s = wc.secondaryColor?.toArgb() ?: p
                }
            } catch (e: Exception) {
            }
        }
        return Pair(vivid(p), vivid(s))
    }

    /** Widget ke PEECHE ke wallpaper hisse se upar/neeche ke rang (glow/flux usi ke hisaab se). */
    fun tintsFrom(area: Bitmap): Pair<Int, Int> {
        return try {
            val t = Bitmap.createScaledBitmap(area, 1, 3, true)
            val top = t.getPixel(0, 0)
            val bot = t.getPixel(0, 2)
            if (t !== area) t.recycle()
            Pair(vivid(top), vivid(bot))
        } catch (e: Exception) {
            Pair(Pal.ICE, Pal.ICE)
        }
    }

    private fun vivid(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.35f)
        hsv[2] = hsv[2].coerceAtLeast(0.85f)
        return Color.HSVToColor(hsv)
    }

    /** a se b ki taraf t (0..1) mix. */
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun withAlpha(c: Int, a: Int) = (a shl 24) or (c and 0xFFFFFF)

    /**
     * ColorOS 17 jaisa "edge-lit glass". Font/shape nahi badalta, aur digits ka APNA rang (jaise laal "1") bacha rehta hai.
     * Sirf kam-saturation (safed/grey) hisse wallpaper ka rang lete hain.
     * 1) halo (digits ke rang ka)  2) translucent body  3) naram andar ki roshni  4) kinare ki patli chamak
     * Intensity = glow slider.
     */
    fun flux(base: Bitmap, top: Int, bottom: Int, glow: Int, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val r = 28f * (m / 900f).coerceIn(0.5f, 1.8f)
        val t = (glow / 100f).coerceIn(0f, 1f)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        val (y0, y1) = verticalExtent(base)
        val tinted = glassColors(base, top, bottom, y0, y1, clear)

        // 1) halo: blurred shape, rang digit ke apne rang se
        val off = IntArray(2)
        val blurMask = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(r * 1.2f, BlurMaskFilter.Blur.NORMAL)
        }, off)
        val hm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(hm).drawBitmap(blurMask, off[0].toFloat(), off[1].toFloat(), Paint().apply { color = Color.WHITE })
        blurMask.recycle()
        val field = softBlur(tinted, 20)
        Canvas(field).drawBitmap(hm, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        hm.recycle()
        c.drawBitmap(field, 0f, 0f, Paint().apply { alpha = (40 + 110 * t).toInt() })
        field.recycle()

        // 2) body
        c.drawBitmap(tinted, 0f, 0f, null)

        // 3) + 4) kinaron ki roshni, rang = digit ka rang + safed
        val soft = boost(tinted, 1.2f)
        edgeLight(c, base, soft, r * 0.9f, (60 + 90 * t).toInt())
        soft.recycle()
        val crisp = boost(tinted, 1.55f)
        edgeLight(c, base, crisp, r * 0.30f, (140 + 90 * t).toInt())
        crisp.recycle()
        tinted.recycle()
        return out
    }

    /**
     * Per-pixel: coloured pixels (laal/orange etc.) apna rang rakhte hain (halka glassy lighten + zyada opaque),
     * safed/grey pixels wallpaper-gradient ka rang lete hain aur zyada translucent hote hain.
     */
    private fun glassColors(base: Bitmap, top: Int, bottom: Int, y0: Float, y1: Float, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        val gTop = mix(Color.WHITE, top, 0.45f)
        val gBot = mix(Color.WHITE, bottom, 0.65f)
        val span = (y1 - y0).coerceAtLeast(1f)
        for (y in 0 until h) {
            val ty = ((y - y0) / span).coerceIn(0f, 1f)
            val gr = Color.red(gTop) + (Color.red(gBot) - Color.red(gTop)) * ty
            val gg = Color.green(gTop) + (Color.green(gBot) - Color.green(gTop)) * ty
            val gb = Color.blue(gTop) + (Color.blue(gBot) - Color.blue(gTop)) * ty
            val aScale = (0.95f - 0.55f * clear / 100f) - 0.15f * ty
            for (x in 0 until w) {
                val i = y * w + x
                val p = px[i]
                val a = p ushr 24
                if (a == 0) continue
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val sc = (sat * 2.5f).coerceAtMost(1f)          // 1 = poora rangeen
                val wt = (1f - sc) * 0.85f                       // wallpaper tint ka weight
                val lt = 0.06f * (1f - sc)                       // coloured pixels ko lighten nahi karte
                val r1 = r + (255 - r) * lt
                val g1 = g + (255 - g) * lt
                val b1 = b + (255 - b) * lt
                val r2 = (r1 + (gr - r1) * wt).toInt().coerceIn(0, 255)
                val g2 = (g1 + (gg - g1) * wt).toInt().coerceIn(0, 255)
                val b2 = (b1 + (gb - b1) * wt).toInt().coerceIn(0, 255)
                val a2 = (a * (aScale + (1f - aScale) * 0.8f * sc)).toInt().coerceIn(0, 255)
                px[i] = (a2 shl 24) or (r2 shl 16) or (g2 shl 8) or b2
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /**
     * Rang ko k guna roshan karta hai (hue wahi rehta hai, safed nahi milta).
     * Per-pixel, UNPREMULTIPLIED me clamp ke saath: ColorMatrix premultiplied pixels par overflow karke
     * laal/peele glitch deta tha (jab alpha kam ho).
     */
    private fun boost(src: Bitmap, k: Float): Bitmap = mapRgb(src) { v -> v * k }

    /** Bitmap ke rang ko safed ki taraf t se mila deta hai (alpha same). */
    private fun lighten(src: Bitmap, t: Float): Bitmap = mapRgb(src) { v -> v + (255f - v) * t }

    private inline fun mapRgb(src: Bitmap, f: (Float) -> Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            val a = p ushr 24
            if (a == 0) continue
            val r = f(((p shr 16) and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            val g = f(((p shr 8) and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            val b = f((p and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Kinare se andar ki taraf roshni, rang `colors` bitmap se aata hai. */
    private fun edgeLight(c: Canvas, base: Bitmap, colors: Bitmap, radius: Float, alpha: Int) {
        if (alpha <= 0 || radius < 1f) return
        val w = base.width
        val h = base.height
        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.INNER)
        }, off)
        val mask = base.extractAlpha()
        val edge = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ec = Canvas(edge)
        ec.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        ec.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(),
            Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        blurred.recycle()
        mask.recycle()

        val colored = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cc = Canvas(colored)
        cc.drawBitmap(colors, 0f, 0f, null)
        cc.drawBitmap(edge, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        edge.recycle()
        c.drawBitmap(colored, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.alpha = alpha.coerceIn(0, 255) })
        colored.recycle()
    }

    /** Bahut naram blur (chhota karke bada karna). Result mutable, original size. */
    private fun softBlur(src: Bitmap, factor: Int): Bitmap {
        val tw = (src.width / factor).coerceAtLeast(2)
        val th = (src.height / factor).coerceAtLeast(2)
        var cur = src
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val big = Bitmap.createScaledBitmap(cur, src.width, src.height, true)
        if (cur !== src) cur.recycle()
        return if (big.isMutable) big else big.copy(Bitmap.Config.ARGB_8888, true).also { big.recycle() }
    }

    /**
     * Font ke peeche frosted "blur" panel (dock jaisa). Widget ke peeche ka asli wallpaper padha nahi ja sakta,
     * isliye wallpaper ke rang se bana naram frosted layer digits ke shape me, kinare blur ke saath.
     * blur = kinaron ka phailav/naramii, glow = us layer ki roshni.
     */
    fun withBackdrop(base: Bitmap, fx: Bitmap, blur: Int, glow: Int, top: Int, bottom: Int, wall: Bitmap? = null, inner: Int = 35, innerColor: Int = 0): Bitmap {
        if (wall != null) return wallBackdrop(base, fx, blur, glow, wall, inner, innerColor)
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val rad = m * (0.008f + 0.07f * blur / 100f)
        val g = (glow / 100f).coerceIn(0f, 1f)

        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(rad, BlurMaskFilter.Blur.NORMAL)
        }, off)
        val plain = base.extractAlpha()
        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mask)
        val white = Paint().apply { color = Color.WHITE }
        mc.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(), white)
        mc.drawBitmap(plain, 0f, 0f, white)
        blurred.recycle()
        plain.recycle()

        val (y0, y1) = verticalExtent(base)
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(layer).drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, y0, 0f, y1,
                mix(Color.WHITE, top, 0.5f), mix(Color.WHITE, bottom, 0.5f), Shader.TileMode.CLAMP
            )
        })
        Canvas(layer).drawBitmap(mask, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        mask.recycle()
        // sirf font/digits ke andar: blur ka phailav bahar na jaye
        Canvas(layer).drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(layer, 0f, 0f, Paint().apply { alpha = (255 * (0.08f + 0.55f * g)).toInt() })
        layer.recycle()
        c.drawBitmap(fx, 0f, 0f, null)
        return out
    }

    /** Asli frosted glass: digits ke andar wallpaper ka blurred hissa (chuni hui wallpaper image se). */
    /**
     * ColorOS 17 jaisa asli frosted glass: digits ke andar peeche ka wallpaper (blurred), halka safed tint,
     * andar ki taraf naram chamakta kinara + patli crisp rim. Bahar koi halo nahi.
     * blur = wallpaper ka dhundhlapan, glow = glass ki roshni (tint + kinare ki chamak).
     */
    private fun wallBackdrop(base: Bitmap, fx: Bitmap, blur: Int, glow: Int, wall: Bitmap, inner: Int, innerColor: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val g = (glow / 100f).coerceIn(0f, 1f)          // Backdrop glow = glass ki brightness
        val gi = (inner / 100f).coerceIn(0f, 1f)        // Inner glow slider = kinare se andar ka chamak
        val bt = (blur / 100f).coerceIn(0f, 1f)

        val blurred = softBlur(wall, 3 + (bt * 14f).toInt())
        // body: blurred wallpaper + safed ki taraf halka mix (glow se roshan)
        // (safed se mix karne par rang feeka/grey ho jata tha: ab roshni badha kar rang/saturation bachate hain)
        val lit = boost(blurred, 1.15f + 0.55f * g)
        val body = lighten(lit, 0.07f)
        lit.recycle()
        val bright = boost(blurred, 1.5f + 0.7f * g)
        var pale = lighten(bright, 0.30f)
        bright.recycle()
        if (innerColor != 0) {
            // glow colour chuna ho to wahi rang
            pale.recycle()
            pale = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.eraseColor(innerColor or (0xFF shl 24)) }
        }
        blurred.recycle()

        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(body, 0f, 0f, null)
        body.recycle()
        // sirf digits ke shape me
        lc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(layer, 0f, 0f, null)
        layer.recycle()

        // Koi rim/outline nahi: sirf font ke andar naram, chauda glow (kinare se andar ki taraf fade hota)
        edgeLight(c, base, pale, m * 0.060f, (30 + 215 * gi).toInt())
        edgeLight(c, base, pale, m * 0.026f, (20 + 150 * gi).toInt())
        pale.recycle()
        return out
    }

    /** Digits kis y-range me hain (gradient us range me phailta hai). */
    private fun verticalExtent(base: Bitmap): Pair<Float, Float> {
        val sw = 160
        val sh = (160f * base.height / base.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(base, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        var minY = sh
        var maxY = -1
        for (y in 0 until sh) {
            for (x in 0 until sw) {
                if ((px[y * sw + x] ushr 24) > 16) {
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    break
                }
            }
        }
        if (maxY < 0) return Pair(0f, base.height.toFloat())
        val k = base.height.toFloat() / sh
        return Pair(minY * k, (maxY + 1) * k)
    }

    private fun blurredMask(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int, dy: Float) {
        if (alpha <= 0 || radius < 1f) return
        val bp = Paint().apply { maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = base.extractAlpha(bp, off)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha.coerceIn(0, 255)
        }
        c.drawBitmap(a, off[0].toFloat(), off[1] + dy, p)
        a.recycle()
    }

    private fun glassBody(base: Bitmap, m: Float): Bitmap {
        val w = base.width
        val h = base.height
        val body = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(body)

        // 1. clock ka rang halka safed ki taraf + translucent (frosted fill)
        // (per-pixel, unpremultiplied: ColorMatrix offset premultiplied par overflow/glitch deta tha)
        val frost = mapRgb(base) { v -> 0.45f * v + 140f }
        val fp = IntArray(w * h)
        frost.getPixels(fp, 0, w, 0, 0, w, h)
        for (i in fp.indices) {
            val p = fp[i]
            fp[i] = ((((p ushr 24) * 0.62f).toInt().coerceIn(0, 255)) shl 24) or (p and 0xFFFFFF)
        }
        frost.setPixels(fp, 0, w, 0, 0, w, h)
        c.drawBitmap(frost, 0f, 0f, null)
        frost.recycle()

        val mask = base.extractAlpha()

        // 2. upar se neeche sheen (glass ki chamak), sirf letters ke andar
        val sheen = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheen)
        sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(Color.argb(150, 255, 255, 255), Color.argb(40, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        })
        // NOTE: ALPHA_8 mask par DST_IN coverage-based hota hai (mask ke bahar ka area clear nahi hota),
        // isliye yahan ARGB bitmap (base) use karte hain, taaki sheen sirf letters me rahe.
        sc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(sheen, 0f, 0f, null)
        sheen.recycle()

        // 3. rim: upar-left ka chamakta kinara, neeche-right ka halka kinara
        val d = maxOf(2f, m * 0.004f)
        rim(c, mask, w, h, d, d, 235)
        rim(c, mask, w, h, -d, -d, 90)
        mask.recycle()
        return body
    }

    /** mask minus (mask shifted by dx,dy) = ek taraf ka patla kinara. */
    private fun rim(c: Canvas, mask: Bitmap, w: Int, h: Int, dx: Float, dy: Float, alpha: Int) {
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        lc.drawBitmap(mask, dx, dy, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha })
        layer.recycle()
    }
}
