package com.example.clockwidget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.os.Build

/** Glow + frosted-glass look (ColorOS style) jo kisi bhi clock bitmap par lagta hai. */
object Effects {

    fun apply(base: Bitmap, glass: Boolean, glow: Int, glowColor: Int): Bitmap {
        if (!glass && glow <= 0) return base
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (glow > 0) {
            val k = glow / 100f
            blurredMask(c, base, m * 0.050f, glowColor, (255 * 0.80f * k).toInt(), 0f)
            blurredMask(c, base, m * 0.016f, glowColor, (255 * 0.75f * k).toInt(), 0f)
        }

        if (glass) {
            // halka drop shadow, taaki glass hawa me tairta dikhe
            blurredMask(c, base, m * 0.014f, Color.BLACK, 70, m * 0.008f)
            c.drawBitmap(glassBody(base, m), 0f, 0f, null)
        } else {
            c.drawBitmap(base, 0f, 0f, null)
        }
        return out
    }

    // ───────────── ColorOS 17 "Flux Glow" / Counter Glow ─────────────

    /** Wallpaper ka primary rang (API 27+); na mile to halka neela. Thoda vibrant rakhte hain. */
    fun wallpaperTint(ctx: Context): Int {
        var c = Pal.ICE
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (wc != null) c = wc.primaryColor.toArgb()
            } catch (e: Exception) {
            }
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.35f)
        hsv[2] = hsv[2].coerceAtLeast(0.80f)
        return Color.HSVToColor(hsv)
    }

    /**
     * Font/shape bilkul nahi badalta, koi border/rim nahi.
     * 1) peeche wallpaper-rang ka aura (BlurMaskFilter NORMAL)
     * 2) digits ka fill: upar #F2FFFFFF -> neeche (#73 alpha, safed + 45% wallpaper tint), SRC_IN/DST_IN se
     * 3) digits ke andar halka tinted glow (BlurMaskFilter INNER)
     */
    fun flux(base: Bitmap, tint: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val r = 28f * (m / 900f).coerceIn(0.5f, 1.8f)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        // 1) aura (peeche)
        blurredMask(c, base, r, tint, 150, 0f)

        // 2) vertical gradient fill (digits ke upar se neeche tak)
        val (top, bottom) = verticalExtent(base)
        val bottomColor = Color.argb(
            0x73,
            (255 * 0.55f + Color.red(tint) * 0.45f).toInt(),
            (255 * 0.55f + Color.green(tint) * 0.45f).toInt(),
            (255 * 0.55f + Color.blue(tint) * 0.45f).toInt()
        )
        val fill = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fc = Canvas(fill)
        fc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, top, 0f, bottom,
                Color.parseColor("#F2FFFFFF"), bottomColor, Shader.TileMode.CLAMP
            )
        })
        fc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(fill, 0f, 0f, null)
        fill.recycle()

        // 3) andar ka tinted glow
        val ip = Paint().apply { maskFilter = BlurMaskFilter(r, BlurMaskFilter.Blur.INNER) }
        val off = IntArray(2)
        val inner = base.extractAlpha(ip, off)
        c.drawBitmap(inner, off[0].toFloat(), off[1].toFloat(), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            alpha = 90
        })
        inner.recycle()
        return out
    }

    /** Digits kis y-range me hain (gradient us range me phailta hai). */
    private fun verticalExtent(base: Bitmap): Pair<Float, Float> {
        val sw = 160
        val sh = (160f * base.height / base.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(base, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        var minY = sh
        var maxY = -1
        for (y in 0 until sh) {
            for (x in 0 until sw) {
                if ((px[y * sw + x] ushr 24) > 16) {
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    break
                }
            }
        }
        if (maxY < 0) return Pair(0f, base.height.toFloat())
        val k = base.height.toFloat() / sh
        return Pair(minY * k, (maxY + 1) * k)
    }

    private fun blurredMask(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int, dy: Float) {
        if (alpha <= 0 || radius < 1f) return
        val bp = Paint().apply { maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = base.extractAlpha(bp, off)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha.coerceIn(0, 255)
        }
        c.drawBitmap(a, off[0].toFloat(), off[1] + dy, p)
        a.recycle()
    }

    private fun glassBody(base: Bitmap, m: Float): Bitmap {
        val w = base.width
        val h = base.height
        val body = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(body)

        // 1. clock ka rang halka safed ki taraf + translucent (frosted fill)
        val cm = ColorMatrix(
            floatArrayOf(
                0.45f, 0f, 0f, 0f, 140f,
                0f, 0.45f, 0f, 0f, 140f,
                0f, 0f, 0.45f, 0f, 140f,
                0f, 0f, 0f, 0.62f, 0f
            )
        )
        c.drawBitmap(base, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) })

        val mask = base.extractAlpha()

        // 2. upar se neeche sheen (glass ki chamak), sirf letters ke andar
        val sheen = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheen)
        sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(Color.argb(150, 255, 255, 255), Color.argb(40, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        })
        // NOTE: ALPHA_8 mask par DST_IN coverage-based hota hai (mask ke bahar ka area clear nahi hota),
        // isliye yahan ARGB bitmap (base) use karte hain, taaki sheen sirf letters me rahe.
        sc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(sheen, 0f, 0f, null)
        sheen.recycle()

        // 3. rim: upar-left ka chamakta kinara, neeche-right ka halka kinara
        val d = maxOf(2f, m * 0.004f)
        rim(c, mask, w, h, d, d, 235)
        rim(c, mask, w, h, -d, -d, 90)
        mask.recycle()
        return body
    }

    /** mask minus (mask shifted by dx,dy) = ek taraf ka patla kinara. */
    private fun rim(c: Canvas, mask: Bitmap, w: Int, h: Int, dx: Float, dy: Float, alpha: Int) {
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        lc.drawBitmap(mask, dx, dy, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha })
        layer.recycle()
    }
}
