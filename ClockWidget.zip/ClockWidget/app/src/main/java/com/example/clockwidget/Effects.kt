package com.example.clockwidget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.os.Build

/** Glow + frosted-glass look (ColorOS style) jo kisi bhi clock bitmap par lagta hai. */
object Effects {

    fun apply(base: Bitmap, glass: Boolean, glow: Int, glowColor: Int): Bitmap {
        if (!glass && glow <= 0) return base
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (glass) {
            // halka drop shadow, taaki glass hawa me tairta dikhe
            blurredMask(c, base, m * 0.014f, Color.BLACK, 70, m * 0.008f)
            c.drawBitmap(glassBody(base, m), 0f, 0f, null)
        } else {
            c.drawBitmap(base, 0f, 0f, null)
        }

        addGlow(c, base, glow, glowColor, m)
        return out
    }

    /** Glow sirf digits ke ANDAR (kinaron se andar ki taraf), bahar kuch nahi phailta. */
    private fun addGlow(c: Canvas, base: Bitmap, glow: Int, glowColor: Int, m: Float) {
        if (glow <= 0) return
        val k = glow / 100f
        if (glowColor == 0) {
            // Clock ke apne rang ko hi roshan karte hain, rang feeka nahi hota
            val bright = boost(base, 1.45f)
            edgeLight(c, base, bright, m * 0.035f, (255 * 0.90f * k).toInt())
            edgeLight(c, base, bright, m * 0.014f, (255 * 0.80f * k).toInt())
            bright.recycle()
        } else {
            innerGlow(c, base, m * 0.035f, glowColor, (255 * 0.90f * k).toInt())
            innerGlow(c, base, m * 0.014f, glowColor, (255 * 0.80f * k).toInt())
        }
    }

    // ───────────── Glass styles: 0 Frosted, 1 Liquid, 2 Blur, 3 Gradient, 4 Solid, 5 Glow ─────────────

    /** Style slider ki value; -1 ho to us style ka default. */
    fun pv(v: Int, d: Int) = if (v < 0) d else v.coerceIn(0, 100)

    fun styled(base: Bitmap, style: Int, glow: Int, glowColor: Int, accent: Int, cfg: Cfg): Bitmap = when (style) {
        0 -> frosted(base, glow, glowColor, cfg)
        1 -> liquid(base, glow, glowColor, cfg)
        2 -> base                                   // Blur: ClockEngine backdrop blur lagata hai
        3 -> gradient(base, glow, glowColor, accent, cfg)
        4 -> solid(base, glow, glowColor, cfg)
        5 -> glowStyle(base, glow, glowColor, cfg)
        else -> frosted(base, glow, glowColor, cfg)
    }

    /** layer me draw karo, phir sirf letters ke andar rakho. */
    private fun lettersOnly(base: Bitmap, draw: (Canvas) -> Unit): Bitmap {
        val l = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
        val lc = Canvas(l)
        draw(lc)
        lc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        return l
    }

    /** src ka shape/alpha, rang `color` (SRC_IN). */
    private fun tinted(src: Bitmap, color: Int): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = PorterDuffColorFilter(color or (0xFF shl 24), PorterDuff.Mode.SRC_IN)
        })
        return out
    }

    /** Digits ka bounding box (pixels). */
    private fun contentBounds(base: Bitmap): android.graphics.RectF {
        val sw = 160
        val sh = (160f * base.height / base.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(base, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        var x0 = sw; var x1 = -1; var y0 = sh; var y1 = -1
        for (y in 0 until sh) for (x in 0 until sw) {
            if ((px[y * sw + x] ushr 24) > 16) {
                if (x < x0) x0 = x; if (x > x1) x1 = x
                if (y < y0) y0 = y; if (y > y1) y1 = y
            }
        }
        if (x1 < 0) return android.graphics.RectF(0f, 0f, base.width.toFloat(), base.height.toFloat())
        val kx = base.width.toFloat() / sw
        val ky = base.height.toFloat() / sh
        return android.graphics.RectF(x0 * kx, y0 * ky, (x1 + 1) * kx, (y1 + 1) * ky)
    }

    /** Clock ka average rang (alpha-weighted). Safed/grey ho to wahi rakhta hai, rangeen ho to roshan karta hai. */
    private fun avgColor(base: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(base, 32, 32, true)
        val px = IntArray(32 * 32)
        s.getPixels(px, 0, 32, 0, 0, 32, 32)
        s.recycle()
        var r = 0f; var g = 0f; var b = 0f; var wsum = 0f
        for (p in px) {
            val a = (p ushr 24) / 255f
            if (a <= 0f) continue
            r += ((p shr 16) and 0xFF) * a; g += ((p shr 8) and 0xFF) * a; b += (p and 0xFF) * a; wsum += a
        }
        if (wsum <= 0f) return Color.WHITE
        val c = Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (b / wsum).toInt())
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        if (hsv[1] >= 0.15f) { hsv[2] = hsv[2].coerceAtLeast(0.9f); return Color.HSVToColor(hsv) }
        return c
    }

    // ── Frosted ──
    private fun frosted(base: Bitmap, glow: Int, glowColor: Int, cfg: Cfg): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        blurredMask(c, base, m * 0.014f, Color.BLACK, 70, m * 0.008f)
        c.drawBitmap(glassBody(base, m,
            frostA = pv(cfg.s1, 62) / 100f,
            sheenK = pv(cfg.s2, 60) / 60f,
            rimK = pv(cfg.s3, 70) / 70f,
            tint = cfg.sc1), 0f, 0f, null)
        addGlow(c, base, glow, glowColor, m)
        return out
    }

    /**
     * Liquid glass (iOS 26 jaisa): bahut clear body, upar andar dabi hui shade, neeche chamak,
     * tirchi sheen, aur neeche ka kinara tez safed. Bar ke liquid glass se match karta hai.
     */
    private fun liquid(base: Bitmap, glow: Int, glowColor: Int, cfg: Cfg): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val clarity = pv(cfg.s1, 72) / 100f            // zyada = zyada transparent
        val depthK = pv(cfg.s2, 60) / 60f              // andar ki dark shade
        val edgeK = pv(cfg.s3, 75) / 75f               // kinare / neeche ki roshni
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        blurredMask(c, base, m * 0.02f, Color.BLACK, 60, m * 0.01f)

        // 1. clear body (rang halka safed ki taraf, ya chuna hua tint)
        val clear = if (cfg.sc1 != 0) tinted(base, mix(cfg.sc1, Color.WHITE, 0.2f)) else mapRgb(base) { v -> 0.38f * v + 150f }
        val bodyA = (1f - clarity).coerceIn(0.05f, 1f)
        val px = IntArray(w * h)
        clear.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            px[i] = ((((p ushr 24) * bodyA).toInt().coerceIn(0, 255)) shl 24) or (p and 0xFFFFFF)
        }
        clear.setPixels(px, 0, w, 0, 0, w, h)
        c.drawBitmap(clear, 0f, 0f, null)
        clear.recycle()

        val (y0, y1) = verticalExtent(base)
        val span = (y1 - y0).coerceAtLeast(1f)

        // 2. upar andar ki dark shade (depth)
        val shade = lettersOnly(base) { lc ->
            lc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
                shader = LinearGradient(0f, y0, 0f, y0 + span * 0.6f,
                    Color.argb((150 * depthK).toInt().coerceIn(0, 255), 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            })
        }
        c.drawBitmap(shade, 0f, 0f, null); shade.recycle()

        // 3. neeche ki chamak
        val glowB = lettersOnly(base) { lc ->
            lc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
                shader = LinearGradient(0f, y0 + span * 0.4f, 0f, y1,
                    Color.TRANSPARENT, Color.argb((190 * edgeK).toInt().coerceIn(0, 255), 255, 255, 255), Shader.TileMode.CLAMP)
            })
        }
        c.drawBitmap(glowB, 0f, 0f, null); glowB.recycle()

        // 4. tirchi sheen
        val sheen = lettersOnly(base) { lc ->
            lc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
                shader = LinearGradient(0f, y0, w * 0.5f, y1, Color.argb(85, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            })
        }
        c.drawBitmap(sheen, 0f, 0f, null); sheen.recycle()

        // 5. rim: neeche ka kinara tez, upar/side halke
        val mask = base.extractAlpha()
        val d = maxOf(2f, m * 0.0045f)
        rim(c, mask, w, h, 0f, -d * 1.7f, (250 * edgeK).toInt().coerceIn(0, 255))
        rim(c, mask, w, h, 0f, d, (120 * edgeK).toInt().coerceIn(0, 255))
        rim(c, mask, w, h, d, 0f, (55 * edgeK).toInt().coerceIn(0, 255))
        rim(c, mask, w, h, -d, 0f, (55 * edgeK).toInt().coerceIn(0, 255))
        mask.recycle()

        addGlow(c, base, glow, glowColor, m)
        return out
    }

    private fun hueShift(color: Int, deg: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[0] = (hsv[0] + deg + 360f) % 360f
        hsv[1] = hsv[1].coerceAtLeast(0.45f)
        hsv[2] = hsv[2].coerceAtLeast(0.9f)
        return Color.HSVToColor(hsv)
    }

    /** Gradient: start/end colour + direction + spread + shine (sab customisable). */
    private fun gradient(base: Bitmap, glow: Int, glowColor: Int, accent: Int, cfg: Cfg): Bitmap {
        val b = contentBounds(base)
        val c1 = if (cfg.sc1 != 0) cfg.sc1 else mix(accent, Color.WHITE, 0.25f)
        val c2 = when {
            cfg.sc2 != 0 -> cfg.sc2
            glowColor != 0 -> glowColor
            else -> hueShift(accent, 55f)
        }
        val a = Math.toRadians(pv(cfg.s1, 25) * 3.6)       // 25 = upar se neeche
        val dx = Math.cos(a).toFloat()
        val dy = Math.sin(a).toFloat()
        val spread = (pv(cfg.s2, 50) / 50f).coerceIn(0.2f, 2f)
        val half = (Math.abs(dx) * b.width() + Math.abs(dy) * b.height()) / 2f * spread
        val cx = b.centerX()
        val cy = b.centerY()
        val fill = lettersOnly(base) { lc ->
            lc.drawRect(0f, 0f, base.width.toFloat(), base.height.toFloat(), Paint().apply {
                shader = LinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half, c1, c2, Shader.TileMode.CLAMP)
            })
        }
        val shine = pv(cfg.s3, 0) / 100f
        if (shine > 0f) {
            val sh = lettersOnly(base) { lc ->
                lc.drawRect(0f, 0f, base.width.toFloat(), base.height.toFloat(), Paint().apply {
                    shader = LinearGradient(0f, b.top, 0f, b.top + b.height() * 0.6f,
                        Color.argb((170 * shine).toInt(), 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                })
            }
            Canvas(fill).drawBitmap(sh, 0f, 0f, null)
            sh.recycle()
        }
        return apply(fill, false, glow, glowColor)
    }

    /**
     * Glow: digits ke bahar neon halo (do parat) + andar garam/roshan core + kinare ki chamak.
     * Halo ka phailav digits ke aas-paas ke khali hisse tak seemit hai, warna widget ke kinare par kat jaata.
     */
    private fun glowStyle(base: Bitmap, glow: Int, glowColor: Int, cfg: Cfg): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val k = (glow / 100f).coerceIn(0f, 1f)
        val sizeK = pv(cfg.s1, 60) / 100f
        val coreK = pv(cfg.s2, 55) / 100f
        val haloK = pv(cfg.s3, 75) / 100f
        val b = contentBounds(base)
        val margin = minOf(b.left, b.top, w - b.right, h - b.bottom).coerceAtLeast(m * 0.012f)
        val radius = (margin * 0.9f * (0.3f + 0.7f * sizeK)).coerceAtLeast(m * 0.008f)
        val gc = if (glowColor != 0) glowColor else avgColor(base)

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        // halo: chauda naram + beech ka tez + digits ke paas ka bahut tez
        blurredMask(c, base, radius, gc, (255 * haloK * (0.30f + 0.70f * k)).toInt(), 0f)
        blurredMask(c, base, radius * 0.5f, gc, (255 * haloK * (0.45f + 0.55f * k)).toInt(), 0f)
        blurredMask(c, base, radius * 0.22f, mix(gc, Color.WHITE, 0.35f), (255 * haloK * (0.55f + 0.45f * k)).toInt(), 0f)

        // core: clock ke rang safed ki taraf = "garam" roshan akshar
        val core = mapRgb(base) { v -> v + (255f - v) * coreK * 0.75f }
        c.drawBitmap(core, 0f, 0f, null)
        core.recycle()

        // kinare se andar ki chamak
        addGlow(c, base, glow, glowColor, m)
        return out
    }

    /** Solid: apna rang (ya clock ke rang) + opacity + shadow + outline. */
    private fun solid(base: Bitmap, glow: Int, glowColor: Int, cfg: Cfg): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val op = pv(cfg.s1, 100) / 100f
        val shK = pv(cfg.s2, 0) / 100f
        val olK = pv(cfg.s3, 0) / 100f
        val fill = if (cfg.sc1 != 0) tinted(base, cfg.sc1) else base
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (shK > 0f) blurredMask(c, base, m * 0.02f, Color.BLACK, (210 * shK).toInt(), m * 0.014f)
        if (olK > 0f) {
            val o = maxOf(1.5f, m * 0.014f * olK)
            val ob = tinted(base, if (cfg.sc2 != 0) cfg.sc2 else Color.BLACK)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            for (i in 0 until 12) {
                val ang = Math.toRadians(i * 30.0)
                c.drawBitmap(ob, (Math.cos(ang) * o).toFloat(), (Math.sin(ang) * o).toFloat(), p)
            }
            ob.recycle()
        }
        c.drawBitmap(fill, 0f, 0f, Paint().apply { alpha = (255 * op).toInt() })
        addGlow(c, fill, glow, glowColor, m)
        return out
    }

    /** Digit ke kinare se andar ki taraf nikalta rang: (digit) minus (INNER-blur digit). */
    private fun innerGlow(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int) {
        if (alpha <= 0 || radius < 1f) return
        val w = base.width
        val h = base.height
        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.INNER)
        }, off)
        val mask = base.extractAlpha()
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { this.color = Color.WHITE })
        lc.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(),
            Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            this.alpha = alpha.coerceIn(0, 255)
        })
        layer.recycle()
        blurred.recycle()
        mask.recycle()
    }

    // ───────────── ColorOS 17 "Flux Glow" / Counter Glow ─────────────

    /** Wallpaper ke primary + secondary rang (API 27+); na mile to halka neela. Thoda vivid rakhte hain. */
    fun wallpaperTints(ctx: Context): Pair<Int, Int> {
        var p = Pal.ICE
        var s = Pal.ICE
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (wc != null) {
                    p = wc.primaryColor.toArgb()
                    s = wc.secondaryColor?.toArgb() ?: p
                }
            } catch (e: Exception) {
            }
        }
        return Pair(vivid(p), vivid(s))
    }

    /** Widget ke PEECHE ke wallpaper hisse se upar/neeche ke rang (glow/flux usi ke hisaab se). */
    fun tintsFrom(area: Bitmap): Pair<Int, Int> {
        return try {
            val t = Bitmap.createScaledBitmap(area, 1, 3, true)
            val top = t.getPixel(0, 0)
            val bot = t.getPixel(0, 2)
            if (t !== area) t.recycle()
            Pair(vivid(top), vivid(bot))
        } catch (e: Exception) {
            Pair(Pal.ICE, Pal.ICE)
        }
    }

    private fun vivid(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.35f)
        hsv[2] = hsv[2].coerceAtLeast(0.85f)
        return Color.HSVToColor(hsv)
    }

    /** a se b ki taraf t (0..1) mix. */
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun withAlpha(c: Int, a: Int) = (a shl 24) or (c and 0xFFFFFF)

    /**
     * ColorOS 17 jaisa "edge-lit glass". Font/shape nahi badalta, aur digits ka APNA rang (jaise laal "1") bacha rehta hai.
     * Sirf kam-saturation (safed/grey) hisse wallpaper ka rang lete hain.
     * 1) halo (digits ke rang ka)  2) translucent body  3) naram andar ki roshni  4) kinare ki patli chamak
     * Intensity = glow slider.
     */
    fun flux(base: Bitmap, top: Int, bottom: Int, glow: Int, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val r = 28f * (m / 900f).coerceIn(0.5f, 1.8f)
        val t = (glow / 100f).coerceIn(0f, 1f)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        val (y0, y1) = verticalExtent(base)
        val tinted = glassColors(base, top, bottom, y0, y1, clear)

        // 1) halo: blurred shape, rang digit ke apne rang se
        val off = IntArray(2)
        val blurMask = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(r * 1.2f, BlurMaskFilter.Blur.NORMAL)
        }, off)
        val hm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(hm).drawBitmap(blurMask, off[0].toFloat(), off[1].toFloat(), Paint().apply { color = Color.WHITE })
        blurMask.recycle()
        val field = softBlur(tinted, 20)
        Canvas(field).drawBitmap(hm, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        hm.recycle()
        c.drawBitmap(field, 0f, 0f, Paint().apply { alpha = (40 + 110 * t).toInt() })
        field.recycle()

        // 2) body
        c.drawBitmap(tinted, 0f, 0f, null)

        // 3) + 4) kinaron ki roshni, rang = digit ka rang + safed
        val soft = boost(tinted, 1.2f)
        edgeLight(c, base, soft, r * 0.9f, (60 + 90 * t).toInt())
        soft.recycle()
        val crisp = boost(tinted, 1.55f)
        edgeLight(c, base, crisp, r * 0.30f, (140 + 90 * t).toInt())
        crisp.recycle()
        tinted.recycle()
        return out
    }

    /**
     * Per-pixel: coloured pixels (laal/orange etc.) apna rang rakhte hain (halka glassy lighten + zyada opaque),
     * safed/grey pixels wallpaper-gradient ka rang lete hain aur zyada translucent hote hain.
     */
    private fun glassColors(base: Bitmap, top: Int, bottom: Int, y0: Float, y1: Float, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        val gTop = mix(Color.WHITE, top, 0.45f)
        val gBot = mix(Color.WHITE, bottom, 0.65f)
        val span = (y1 - y0).coerceAtLeast(1f)
        for (y in 0 until h) {
            val ty = ((y - y0) / span).coerceIn(0f, 1f)
            val gr = Color.red(gTop) + (Color.red(gBot) - Color.red(gTop)) * ty
            val gg = Color.green(gTop) + (Color.green(gBot) - Color.green(gTop)) * ty
            val gb = Color.blue(gTop) + (Color.blue(gBot) - Color.blue(gTop)) * ty
            val aScale = (0.95f - 0.55f * clear / 100f) - 0.15f * ty
            for (x in 0 until w) {
                val i = y * w + x
                val p = px[i]
                val a = p ushr 24
                if (a == 0) continue
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val sc = (sat * 2.5f).coerceAtMost(1f)          // 1 = poora rangeen
                val wt = (1f - sc) * 0.85f                       // wallpaper tint ka weight
                val lt = 0.06f * (1f - sc)                       // coloured pixels ko lighten nahi karte
                val r1 = r + (255 - r) * lt
                val g1 = g + (255 - g) * lt
                val b1 = b + (255 - b) * lt
                val r2 = (r1 + (gr - r1) * wt).toInt().coerceIn(0, 255)
                val g2 = (g1 + (gg - g1) * wt).toInt().coerceIn(0, 255)
                val b2 = (b1 + (gb - b1) * wt).toInt().coerceIn(0, 255)
                val a2 = (a * (aScale + (1f - aScale) * 0.8f * sc)).toInt().coerceIn(0, 255)
                px[i] = (a2 shl 24) or (r2 shl 16) or (g2 shl 8) or b2
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /**
     * Rang ko k guna roshan karta hai (hue wahi rehta hai, safed nahi milta).
     * Per-pixel, UNPREMULTIPLIED me clamp ke saath: ColorMatrix premultiplied pixels par overflow karke
     * laal/peele glitch deta tha (jab alpha kam ho).
     */
    private fun boost(src: Bitmap, k: Float): Bitmap = mapRgb(src) { v -> v * k }

    /** Bitmap ke rang ko safed ki taraf t se mila deta hai (alpha same). */
    private fun lighten(src: Bitmap, t: Float): Bitmap = mapRgb(src) { v -> v + (255f - v) * t }

    private inline fun mapRgb(src: Bitmap, f: (Float) -> Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            val a = p ushr 24
            if (a == 0) continue
            val r = f(((p shr 16) and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            val g = f(((p shr 8) and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            val b = f((p and 0xFF).toFloat()).toInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Kinare se andar ki taraf roshni, rang `colors` bitmap se aata hai. */
    private fun edgeLight(c: Canvas, base: Bitmap, colors: Bitmap, radius: Float, alpha: Int) {
        if (alpha <= 0 || radius < 1f) return
        val w = base.width
        val h = base.height
        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.INNER)
        }, off)
        val mask = base.extractAlpha()
        val edge = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ec = Canvas(edge)
        ec.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        ec.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(),
            Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        blurred.recycle()
        mask.recycle()

        val colored = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cc = Canvas(colored)
        cc.drawBitmap(colors, 0f, 0f, null)
        cc.drawBitmap(edge, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        edge.recycle()
        c.drawBitmap(colored, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.alpha = alpha.coerceIn(0, 255) })
        colored.recycle()
    }

    /** Bahut naram blur (chhota karke bada karna). Result mutable, original size. */
    /**
     * Asli smooth frosted blur: chhota karo, box-blur (3 pass) lagao, phir progressive bada karo.
     * Wallpaper ki lakeerein/arc poori tarah ghul jaati hain (pehle sirf downscale tha, isliye streaks dikhte the).
     * bt 0..1: zyada = zyada dhundhla.
     */
    private fun smoothBlur(src: Bitmap, bt: Float): Bitmap {
        val tw = (80 - 62 * bt).toInt().coerceIn(14, 80)
        val th = (tw * src.height / src.width.toFloat()).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(src, tw, th, true)
        val px = IntArray(tw * th)
        small.getPixels(px, 0, tw, 0, 0, tw, th)
        if (small !== src) small.recycle()
        val r = 3
        val tmp = IntArray(tw * th)
        repeat(3) {
            boxPass(px, tmp, tw, th, r, true)
            boxPass(tmp, px, tw, th, r, false)
        }
        var cur = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        cur.setPixels(px, 0, tw, 0, 0, tw, th)
        while (cur.width * 2 <= src.width && cur.height * 2 <= src.height) {
            val next = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
            cur.recycle()
            cur = next
        }
        val big = Bitmap.createScaledBitmap(cur, src.width, src.height, true)
        if (big !== cur) cur.recycle()
        return if (big.isMutable) big else big.copy(Bitmap.Config.ARGB_8888, true).also { big.recycle() }
    }

    /** Ek disha me box blur (edge clamp), alpha ko 255 maante hain (wallpaper opaque). */
    private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val n = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val win = 2 * r + 1
        for (l in 0 until lines) {
            var sr = 0; var sg = 0; var sb = 0
            fun at(i: Int): Int {
                val k = i.coerceIn(0, n - 1)
                return if (horizontal) src[l * w + k] else src[k * w + l]
            }
            for (i in -r..r) {
                val p = at(i)
                sr += (p shr 16) and 0xFF; sg += (p shr 8) and 0xFF; sb += p and 0xFF
            }
            for (i in 0 until n) {
                val o = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                if (horizontal) dst[l * w + i] = o else dst[i * w + l] = o
                val add = at(i + r + 1)
                val rem = at(i - r)
                sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
                sb += (add and 0xFF) - (rem and 0xFF)
            }
        }
    }

    private fun softBlur(src: Bitmap, factor: Int): Bitmap {
        val tw = (src.width / factor).coerceAtLeast(2)
        val th = (src.height / factor).coerceAtLeast(2)
        var cur = src
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val big = Bitmap.createScaledBitmap(cur, src.width, src.height, true)
        if (cur !== src) cur.recycle()
        return if (big.isMutable) big else big.copy(Bitmap.Config.ARGB_8888, true).also { big.recycle() }
    }

    /**
     * Font ke peeche frosted "blur" panel (dock jaisa). Widget ke peeche ka asli wallpaper padha nahi ja sakta,
     * isliye wallpaper ke rang se bana naram frosted layer digits ke shape me, kinare blur ke saath.
     * blur = kinaron ka phailav/naramii, glow = us layer ki roshni.
     */
    fun withBackdrop(base: Bitmap, fx: Bitmap, blur: Int, glow: Int, top: Int, bottom: Int, wall: Bitmap? = null, inner: Int = 35, innerColor: Int = 0, clear: Int = 45): Bitmap {
        // Wallpaper mila to digits ke andar asli blurred wallpaper; warna tinted frosted glass.
        if (wall != null) return wallBackdrop(base, fx, blur, glow, wall, inner, innerColor, clear)
        return glassFree(base, blur, glow, top, bottom, inner, innerColor, clear)
    }

    @Suppress("unused")
    private fun legacyBackdrop(base: Bitmap, fx: Bitmap, blur: Int, glow: Int, top: Int, bottom: Int, wall: Bitmap?, inner: Int, innerColor: Int, clear: Int): Bitmap {
        if (wall != null) return wallBackdrop(base, fx, blur, glow, wall, inner, innerColor, clear)
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val rad = m * (0.008f + 0.07f * blur / 100f)
        val g = (glow / 100f).coerceIn(0f, 1f)

        val off = IntArray(2)
        val blurred = base.extractAlpha(Paint().apply {
            maskFilter = BlurMaskFilter(rad, BlurMaskFilter.Blur.NORMAL)
        }, off)
        val plain = base.extractAlpha()
        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mask)
        val white = Paint().apply { color = Color.WHITE }
        mc.drawBitmap(blurred, off[0].toFloat(), off[1].toFloat(), white)
        mc.drawBitmap(plain, 0f, 0f, white)
        blurred.recycle()
        plain.recycle()

        val (y0, y1) = verticalExtent(base)
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(layer).drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, y0, 0f, y1,
                mix(Color.WHITE, top, 0.5f), mix(Color.WHITE, bottom, 0.5f), Shader.TileMode.CLAMP
            )
        })
        Canvas(layer).drawBitmap(mask, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        mask.recycle()
        // sirf font/digits ke andar: blur ka phailav bahar na jaye
        Canvas(layer).drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(layer, 0f, 0f, Paint().apply { alpha = (255 * (0.08f + 0.55f * g)).toInt() })
        layer.recycle()
        c.drawBitmap(fx, 0f, 0f, null)
        return out
    }

    /** Asli frosted glass: digits ke andar wallpaper ka blurred hissa (chuni hui wallpaper image se). */
    /**
     * Wallpaper ke bina frosted glass:
     * - body: upar se neeche halka gradient (wallpaper/system rang + safed), translucent (Transparency slider)
     * - frost: kinare ghane, beech ka hissa zyada saaf (Blur slider = kitna/kitna chauda) => "andar se blurred" look
     * - Backdrop glow: glass ki roshni; Inner glow: kinare se andar ki chamak (colour chunne par wahi rang)
     * Bahar koi halo / rim nahi.
     */
    private fun glassFree(base: Bitmap, blur: Int, glow: Int, top: Int, bottom: Int, inner: Int, innerColor: Int, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val g = (glow / 100f).coerceIn(0f, 1f)
        val gi = (inner / 100f).coerceIn(0f, 1f)
        val bt = (blur / 100f).coerceIn(0f, 1f)
        val ct = (clear / 100f).coerceIn(0f, 1f)

        val (y0, y1) = verticalExtent(base)
        val cTop = mix(mix(Color.WHITE, top, 0.40f), Color.WHITE, 0.10f + 0.40f * g)
        val cBot = mix(mix(Color.WHITE, bottom, 0.60f), Color.WHITE, 0.05f + 0.30f * g)
        val aTop = (0.95f - 0.50f * ct).coerceIn(0.2f, 1f)
        val aBot = aTop * 0.70f

        val body = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val bc = Canvas(body)
        bc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, y0, 0f, y1,
                withAlpha(cTop, (255 * aTop).toInt()), withAlpha(cBot, (255 * aBot).toInt()),
                Shader.TileMode.CLAMP
            )
        })
        bc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

        // frost: beech ka hissa halka saaf (kinare ghane) => andar se blur hua glass
        if (bt > 0f) {
            val off = IntArray(2)
            val interior = base.extractAlpha(Paint().apply {
                maskFilter = BlurMaskFilter(m * (0.03f + 0.11f * bt), BlurMaskFilter.Blur.INNER)
            }, off)
            bc.drawBitmap(interior, off[0].toFloat(), off[1].toFloat(), Paint().apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
                alpha = (255 * 0.60f * bt).toInt()
            })
            interior.recycle()
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(body, 0f, 0f, null)
        body.recycle()

        // Inner glow: kinare se andar ki taraf naram chamak
        val glowCol = if (innerColor != 0) innerColor or (0xFF shl 24) else mix(Color.WHITE, top, 0.20f)
        val solid = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.eraseColor(glowCol) }
        edgeLight(c, base, solid, m * 0.065f, (10 + 245 * gi).toInt())
        edgeLight(c, base, solid, m * 0.028f, (10 + 190 * gi).toInt())
        solid.recycle()
        return out
    }

    /**
     * ColorOS 17 jaisa asli frosted glass: digits ke andar peeche ka wallpaper (blurred), halka safed tint,
     * andar ki taraf naram chamakta kinara + patli crisp rim. Bahar koi halo nahi.
     * blur = wallpaper ka dhundhlapan, glow = glass ki roshni (tint + kinare ki chamak).
     */
    private fun wallBackdrop(base: Bitmap, fx: Bitmap, blur: Int, glow: Int, wall: Bitmap, inner: Int, innerColor: Int, clear: Int): Bitmap {
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val g = (glow / 100f).coerceIn(0f, 1f)          // Backdrop glow = glass ki brightness
        val gi = (inner / 100f).coerceIn(0f, 1f)        // Inner glow slider = kinare se andar ka chamak
        val bt = (blur / 100f).coerceIn(0f, 1f)

        val blurred = smoothBlur(wall, bt)
        // body: blurred wallpaper, roshni (Backdrop glow) se kaafi badhti hai: 0 = wallpaper jaisa, 100 = bahut roshan glass
        val lit = boost(blurred, 1.15f + 1.15f * g)
        val body = lighten(lit, 0.04f + 0.30f * g)
        lit.recycle()
        // kinare ki chamak: body se hamesha zyada roshan/safed taaki Inner glow saaf dikhe
        val bright = boost(blurred, 2.2f + 0.8f * g)
        var pale = lighten(bright, 0.45f + 0.25f * g)
        bright.recycle()
        if (innerColor != 0) {
            pale.recycle()
            pale = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.eraseColor(innerColor or (0xFF shl 24)) }
        }
        blurred.recycle()

        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(body, 0f, 0f, null)
        body.recycle()
        // sirf digits ke shape me
        lc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        // Transparency slider: kam = opaque glass, zyada = see-through (peeche ka asli wallpaper jhalakta hai)
        val bodyA = (255 * (0.97f - 0.60f * (clear / 100f).coerceIn(0f, 1f))).toInt().coerceIn(40, 255)
        c.drawBitmap(layer, 0f, 0f, Paint().apply { alpha = bodyA })
        layer.recycle()

        // Koi rim/outline nahi: sirf font ke andar naram, chauda glow (kinare se andar ki taraf fade hota)
        edgeLight(c, base, pale, m * 0.060f, (10 + 245 * gi).toInt())
        edgeLight(c, base, pale, m * 0.026f, (10 + 180 * gi).toInt())
        pale.recycle()
        return out
    }

    /** Digits kis y-range me hain (gradient us range me phailta hai). */
    private fun verticalExtent(base: Bitmap): Pair<Float, Float> {
        val sw = 160
        val sh = (160f * base.height / base.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(base, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        var minY = sh
        var maxY = -1
        for (y in 0 until sh) {
            for (x in 0 until sw) {
                if ((px[y * sw + x] ushr 24) > 16) {
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    break
                }
            }
        }
        if (maxY < 0) return Pair(0f, base.height.toFloat())
        val k = base.height.toFloat() / sh
        return Pair(minY * k, (maxY + 1) * k)
    }

    private fun blurredMask(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int, dy: Float) {
        if (alpha <= 0 || radius < 1f) return
        val bp = Paint().apply { maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = base.extractAlpha(bp, off)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha.coerceIn(0, 255)
        }
        c.drawBitmap(a, off[0].toFloat(), off[1] + dy, p)
        a.recycle()
    }

    private fun glassBody(base: Bitmap, m: Float, frostA: Float = 0.62f, sheenK: Float = 1f, rimK: Float = 1f, tint: Int = 0): Bitmap {
        val w = base.width
        val h = base.height
        val body = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(body)

        // 1. clock ka rang halka safed ki taraf + translucent (frosted fill)
        // (per-pixel, unpremultiplied: ColorMatrix offset premultiplied par overflow/glitch deta tha)
        val frost = if (tint != 0) tinted(base, mix(tint, Color.WHITE, 0.3f)) else mapRgb(base) { v -> 0.45f * v + 140f }
        val fp = IntArray(w * h)
        frost.getPixels(fp, 0, w, 0, 0, w, h)
        for (i in fp.indices) {
            val p = fp[i]
            fp[i] = ((((p ushr 24) * frostA).toInt().coerceIn(0, 255)) shl 24) or (p and 0xFFFFFF)
        }
        frost.setPixels(fp, 0, w, 0, 0, w, h)
        c.drawBitmap(frost, 0f, 0f, null)
        frost.recycle()

        val mask = base.extractAlpha()

        // 2. upar se neeche sheen (glass ki chamak), sirf letters ke andar
        val sheen = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheen)
        sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(Color.argb((150 * sheenK).toInt().coerceIn(0, 255), 255, 255, 255), Color.argb((40 * sheenK).toInt().coerceIn(0, 255), 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        })
        // NOTE: ALPHA_8 mask par DST_IN coverage-based hota hai (mask ke bahar ka area clear nahi hota),
        // isliye yahan ARGB bitmap (base) use karte hain, taaki sheen sirf letters me rahe.
        sc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(sheen, 0f, 0f, null)
        sheen.recycle()

        // 3. rim: upar-left ka chamakta kinara, neeche-right ka halka kinara
        val d = maxOf(2f, m * 0.004f)
        rim(c, mask, w, h, d, d, (235 * rimK).toInt().coerceIn(0, 255))
        rim(c, mask, w, h, -d, -d, (90 * rimK).toInt().coerceIn(0, 255))
        mask.recycle()
        return body
    }

    /** mask minus (mask shifted by dx,dy) = ek taraf ka patla kinara. */
    private fun rim(c: Canvas, mask: Bitmap, w: Int, h: Int, dx: Float, dy: Float, alpha: Int) {
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        lc.drawBitmap(mask, dx, dy, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha })
        layer.recycle()
    }
}
