package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader

/** Glow + frosted-glass look (ColorOS style) jo kisi bhi clock bitmap par lagta hai. */
object Effects {

    fun apply(base: Bitmap, glass: Boolean, glow: Int, glowColor: Int): Bitmap {
        if (!glass && glow <= 0) return base
        val w = base.width
        val h = base.height
        val m = minOf(w, h).toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        if (glow > 0) {
            val k = glow / 100f
            blurredMask(c, base, m * 0.050f, glowColor, (255 * 0.80f * k).toInt(), 0f)
            blurredMask(c, base, m * 0.016f, glowColor, (255 * 0.75f * k).toInt(), 0f)
        }

        if (glass) {
            // halka drop shadow, taaki glass hawa me tairta dikhe
            blurredMask(c, base, m * 0.014f, Color.BLACK, 70, m * 0.008f)
            c.drawBitmap(glassBody(base, m), 0f, 0f, null)
        } else {
            c.drawBitmap(base, 0f, 0f, null)
        }
        return out
    }

    private fun blurredMask(c: Canvas, base: Bitmap, radius: Float, color: Int, alpha: Int, dy: Float) {
        if (alpha <= 0 || radius < 1f) return
        val bp = Paint().apply { maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = base.extractAlpha(bp, off)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha.coerceIn(0, 255)
        }
        c.drawBitmap(a, off[0].toFloat(), off[1] + dy, p)
        a.recycle()
    }

    private fun glassBody(base: Bitmap, m: Float): Bitmap {
        val w = base.width
        val h = base.height
        val body = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(body)

        // 1. clock ka rang halka safed ki taraf + translucent (frosted fill)
        val cm = ColorMatrix(
            floatArrayOf(
                0.45f, 0f, 0f, 0f, 140f,
                0f, 0.45f, 0f, 0f, 140f,
                0f, 0f, 0.45f, 0f, 140f,
                0f, 0f, 0f, 0.62f, 0f
            )
        )
        c.drawBitmap(base, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) })

        val mask = base.extractAlpha()

        // 2. upar se neeche sheen (glass ki chamak), sirf letters ke andar
        val sheen = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheen)
        sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(Color.argb(150, 255, 255, 255), Color.argb(40, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        })
        // NOTE: ALPHA_8 mask par DST_IN coverage-based hota hai (mask ke bahar ka area clear nahi hota),
        // isliye yahan ARGB bitmap (base) use karte hain, taaki sheen sirf letters me rahe.
        sc.drawBitmap(base, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(sheen, 0f, 0f, null)
        sheen.recycle()

        // 3. rim: upar-left ka chamakta kinara, neeche-right ka halka kinara
        val d = maxOf(2f, m * 0.004f)
        rim(c, mask, w, h, d, d, 235)
        rim(c, mask, w, h, -d, -d, 90)
        mask.recycle()
        return body
    }

    /** mask minus (mask shifted by dx,dy) = ek taraf ka patla kinara. */
    private fun rim(c: Canvas, mask: Bitmap, w: Int, h: Int, dx: Float, dy: Float, alpha: Int) {
        val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        lc.drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        lc.drawBitmap(mask, dx, dy, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
        c.drawBitmap(layer, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha })
        layer.recycle()
    }
}
