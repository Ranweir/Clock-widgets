package com.example.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** User ka chuna hua wallpaper image (real backdrop blur ke liye). */
object WallStore {
    private var cached: Bitmap? = null
    private var cachedStamp = 0L

    private fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun has(ctx: Context) = file(ctx).exists()

    fun clear(ctx: Context) {
        file(ctx).delete()
        cached = null
    }

    fun save(ctx: Context, uri: Uri) {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 1800) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("Cannot read this image")
        file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        cached = null
    }

    private fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        if (cached == null || cachedStamp != f.lastModified()) {
            cached = BitmapFactory.decodeFile(f.absolutePath)
            cachedStamp = f.lastModified()
        }
        return cached
    }

    /**
     * Widget ke peeche ka hissa (andaza): wallpaper ko screen par center-crop maan kar,
     * widget horizontally center me, vertically wallY% position par.
     */
    fun crop(ctx: Context, w: Int, h: Int, wallY: Int): Bitmap? {
        val wall = load(ctx) ?: return null
        val dm = ctx.resources.displayMetrics
        val sw = dm.widthPixels.toFloat()
        val sh = dm.heightPixels.toFloat()
        val screenAspect = sw / sh
        val visW: Float
        val visH: Float
        if (wall.width.toFloat() / wall.height > screenAspect) {
            visH = wall.height.toFloat()
            visW = visH * screenAspect
        } else {
            visW = wall.width.toFloat()
            visH = visW / screenAspect
        }
        val x0 = (wall.width - visW) / 2f
        val y0 = (wall.height - visH) / 2f
        val s = visW / sw
        val cw = (w * s).coerceIn(2f, visW)
        val ch = (h * s).coerceIn(2f, visH)
        val left = x0 + (visW - cw) / 2f
        val top = y0 + (wallY / 100f).coerceIn(0f, 1f) * (visH - ch)
        val part = Bitmap.createBitmap(wall, left.toInt(), top.toInt(), cw.toInt().coerceAtLeast(1), ch.toInt().coerceAtLeast(1))
        val out = Bitmap.createScaledBitmap(part, w, h, true)
        if (out !== part) part.recycle()
        return out
    }
}
