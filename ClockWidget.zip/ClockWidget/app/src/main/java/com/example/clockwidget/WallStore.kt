package com.example.clockwidget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** User ka chuna hua wallpaper image (real backdrop blur ke liye). */
object WallStore {
    private var cached: Bitmap? = null
    private var cachedStamp = 0L

    private fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun has(ctx: Context) = file(ctx).exists()

    @Synchronized fun clear(ctx: Context) {
        file(ctx).delete()
        cached = null
    }

    @Synchronized fun save(ctx: Context, uri: Uri) {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 1800) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("Cannot read this image")
        file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        cached = null
    }

    // ── Auto: phone ka asli home-screen wallpaper (permission milne par) ──
    private var sysBmp: Bitmap? = null
    private var sysStamp = 0L

    fun autoOn(ctx: Context) = Prefs.getInt(ctx, "wall_auto", 0) == 1
    fun setAuto(ctx: Context, on: Boolean) {
        Prefs.setInt(ctx, "wall_auto", if (on) 1 else 0)
        synchronized(this) { sysBmp = null; sysStamp = 0L }
    }

    /** System wallpaper (permission na ho / live wallpaper ho to null). Result 2 minute cache hota hai. */
    @Synchronized fun system(ctx: Context, force: Boolean = false): Bitmap? {
        val now = System.currentTimeMillis()
        if (!force && sysBmp != null && now - sysStamp < 120_000) return sysBmp
        val b = try {
            val d = WallpaperManager.getInstance(ctx.applicationContext).drawable
            val raw = if (d is BitmapDrawable) d.bitmap else {
                val w = d.intrinsicWidth.coerceAtLeast(1)
                val h = d.intrinsicHeight.coerceAtLeast(1)
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
                    d.setBounds(0, 0, w, h)
                    d.draw(Canvas(it))
                }
            }
            val big = maxOf(raw.width, raw.height)
            if (big > 1800) {
                val k = 1800f / big
                Bitmap.createScaledBitmap(raw, (raw.width * k).toInt().coerceAtLeast(1), (raw.height * k).toInt().coerceAtLeast(1), true)
            } else raw
        } catch (t: Throwable) {
            null
        }
        if (b != null) { sysBmp = b; sysStamp = now }
        return b ?: sysBmp
    }

    /** Backdrop ke liye koi bhi wallpaper (auto ya chuna hua) mil sakta hai? */
    fun usable(ctx: Context) = has(ctx) || (autoOn(ctx) && system(ctx) != null)

    @Synchronized private fun load(ctx: Context): Bitmap? {
        if (autoOn(ctx)) system(ctx)?.let { return it }
        val f = file(ctx)
        if (!f.exists()) return null
        if (cached == null || cachedStamp != f.lastModified()) {
            cached = BitmapFactory.decodeFile(f.absolutePath)
            cachedStamp = f.lastModified()
        }
        return cached
    }

    /** Picker ke liye: jo wallpaper use ho raha hai (auto ya chuna hua). */
    fun peek(ctx: Context): Bitmap? = load(ctx)

    /**
     * Widget ke peeche ka hissa (andaza): wallpaper ko screen par center-crop maan kar,
     * widget horizontally center me, vertically wallY% position par.
     */
    fun crop(ctx: Context, w: Int, h: Int, wallY: Int, wallX: Int = 50): Bitmap? {
        val wall = load(ctx) ?: return null
        val (swi, shi) = screenSize(ctx)
        val sw = swi.toFloat()
        val sh = shi.toFloat()
        val screenAspect = sw / sh
        val visW: Float
        val visH: Float
        if (wall.width.toFloat() / wall.height > screenAspect) {
            visH = wall.height.toFloat()
            visW = visH * screenAspect
        } else {
            visW = wall.width.toFloat()
            visH = visW / screenAspect
        }
        val x0 = (wall.width - visW) / 2f
        val y0 = (wall.height - visH) / 2f
        val s = visW / sw
        val cw = (w * s).coerceIn(2f, visW)
        val ch = (h * s).coerceIn(2f, visH)
        val left = x0 + (wallX / 100f).coerceIn(0f, 1f) * (visW - cw)
        val top = y0 + (wallY / 100f).coerceIn(0f, 1f) * (visH - ch)
        val part = Bitmap.createBitmap(wall, left.toInt(), top.toInt(), cw.toInt().coerceAtLeast(1), ch.toInt().coerceAtLeast(1))
        val out = Bitmap.createScaledBitmap(part, w, h, true)
        if (out !== part) part.recycle()
        return out
    }

    /** Poori screen (nav/status bar samet) ka size, accessibility ke screen-coordinates ke barabar. */
    fun screenSize(ctx: Context): Pair<Int, Int> {
        return try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                Pair(b.width(), b.height())
            } else {
                val p = android.graphics.Point()
                @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
                Pair(p.x, p.y)
            }
        } catch (t: Throwable) {
            val dm = ctx.resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }
}
