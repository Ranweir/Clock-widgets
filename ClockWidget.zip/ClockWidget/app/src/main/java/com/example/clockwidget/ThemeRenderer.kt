package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.hypot
import kotlin.math.max

/**
 * Xiaomi/MIUI/HyperOS (MAML) clock manifest renderer.
 * Supported: Var, Group, Image (srcid, rotation, pivot), ImageNumber, Text, DateTime, Rectangle, Circle.
 * Pehle ek "dry" pass se content ki bounds nikalte hain, phir widget me fit karke draw karte hain.
 */
object ThemeRenderer {

    fun draw(root: File, canvas: Canvas, W: Int, H: Int, pct: Int, fill: Float = 0.98f, colon: Boolean = true): Boolean {
        val doc = try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(File(root, "manifest.xml"))
        } catch (e: Exception) {
            return false
        }
        val el = doc.documentElement
        val designW = el.getAttribute("screenWidth").toDoubleOrNull() ?: 1080.0
        val designH = designW * 0.95

        val run = Run(root, designW, designH, colon)
        run.children(el, 0f, 0f)
        val b = run.bounds ?: return false
        if (b.width() < 1f || b.height() < 1f) return false

        run.dry = false
        run.canvas = canvas
        canvas.save()
        Fit.apply(canvas, b.width(), b.height(), W, H, pct, b.left, b.top, fill)
        run.children(el, 0f, 0f)
        canvas.restore()
        return true
    }

    private class Run(val root: File, designW: Double, designH: Double, colon: Boolean) {
        var dry = true
        var canvas: Canvas? = null
        var bounds: RectF? = null
        val vars = HashMap<String, Any>()
        val expr = Expr { vars[it] }
        val cache = HashMap<String, Bitmap?>()
        val rootPath = root.canonicalPath + File.separator

        init {
            val cal = Calendar.getInstance()
            val h24 = cal.get(Calendar.HOUR_OF_DAY)
            var h12 = h24 % 12
            if (h12 == 0) h12 = 12
            vars["hour24"] = h24.toDouble()
            vars["hour12"] = h12.toDouble()
            vars["ampm"] = if (h24 >= 12) 1.0 else 0.0
            vars["minute"] = cal.get(Calendar.MINUTE).toDouble()
            vars["second"] = cal.get(Calendar.SECOND).toDouble()
            vars["date"] = cal.get(Calendar.DAY_OF_MONTH).toDouble()
            vars["month"] = cal.get(Calendar.MONTH).toDouble()
            vars["year"] = cal.get(Calendar.YEAR).toDouble()
            vars["day_of_week"] = cal.get(Calendar.DAY_OF_WEEK).toDouble()
            vars["time"] = cal.timeInMillis.toDouble()
            vars["view_width"] = designW
            vars["view_height"] = designH
            // Xiaomi weather provider is phone par nahi hota
            vars["show_colon"] = if (colon) 1.0 else 0.0
            vars["hasWeather"] = 0.0
            vars["weather_id"] = 0.0
            vars["weather_temp"] = 0.0
        }

        fun add(l: Float, t: Float, r: Float, b: Float) {
            val cur = bounds
            if (cur == null) bounds = RectF(l, t, r, b) else cur.union(l, t, r, b)
        }

        fun num(e: Element, n: String, def: Double = 0.0): Double =
            if (e.hasAttribute(n)) expr.evalNum(e.getAttribute(n)) else def

        fun visible(e: Element) = !e.hasAttribute("visibility") || num(e, "visibility") != 0.0

        fun colorAttr(e: Element, n: String): Int? {
            if (!e.hasAttribute(n)) return null
            return try {
                Color.parseColor(e.getAttribute(n))
            } catch (ex: Exception) {
                null
            }
        }

        fun children(parent: Element, ox: Float, oy: Float) {
            var n: Node? = parent.firstChild
            while (n != null) {
                if (n is Element) {
                    try {
                        handle(n, ox, oy)
                    } catch (ex: Exception) {
                        // ek element kharab ho to baaki chalte rahein
                    }
                }
                n = n.nextSibling
            }
        }

        fun handle(e: Element, ox: Float, oy: Float) {
            when (e.tagName) {
                "Var" -> {
                    val name = e.getAttribute("name")
                    if (name.isNotEmpty()) vars[name] = expr.eval(e.getAttribute("expression"))
                }
                "Group" -> if (visible(e)) children(e, ox + num(e, "x").toFloat(), oy + num(e, "y").toFloat())
                "Image" -> if (visible(e)) drawImage(e, ox, oy)
                "ImageNumber" -> if (visible(e)) drawImageNumber(e, ox, oy)
                "Rectangle" -> if (visible(e)) drawRect(e, ox, oy, false)
                "Circle" -> if (visible(e)) drawRect(e, ox, oy, true)
                "Text" -> if (visible(e)) {
                    val txt = if (e.hasAttribute("textExp")) Expr.fmt(expr.eval(e.getAttribute("textExp")))
                    else e.getAttribute("text")
                    drawText(e, txt, ox, oy)
                }
                "DateTime" -> if (visible(e)) {
                    val f = e.getAttribute("format").ifEmpty { "HH:mm" }
                    val txt = try {
                        SimpleDateFormat(f, Locale.getDefault()).format(Date())
                    } catch (ex: Exception) {
                        ""
                    }
                    drawText(e, txt, ox, oy)
                }
            }
        }

        fun load(path: String): Bitmap? = cache.getOrPut(path) {
            val f = File(root, path)
            if (!f.canonicalPath.startsWith(rootPath) || !f.exists()) null
            else BitmapFactory.decodeFile(f.absolutePath)
        }

        fun withId(src: String, id: String) = src.replace(Regex("\\.(\\w+)$"), "_$id.$1")

        fun alignX(a: String, x: Float, w: Float) = when (a) {
            "center" -> x - w / 2
            "right" -> x - w
            else -> x
        }

        fun alignY(a: String, y: Float, h: Float) = when (a) {
            "center" -> y - h / 2
            "bottom" -> y - h
            else -> y
        }

        fun drawImage(e: Element, ox: Float, oy: Float) {
            var src = e.getAttribute("src")
            if (e.hasAttribute("srcid")) src = withId(src, num(e, "srcid").toInt().toString())
            val bm = load(src) ?: return
            val w = num(e, "w", bm.width.toDouble()).toFloat()
            val h = num(e, "h", bm.height.toDouble()).toFloat()
            val x = ox + num(e, "x").toFloat()
            val y = oy + num(e, "y").toFloat()
            val left = alignX(e.getAttribute("align"), x, w)
            val top = alignY(e.getAttribute("alignV"), y, h)
            val rot = num(e, "rotation").toFloat()
            val px = left + (if (e.hasAttribute("pivotX")) num(e, "pivotX").toFloat() else w / 2)
            val py = top + (if (e.hasAttribute("pivotY")) num(e, "pivotY").toFloat() else h / 2)

            if (dry) {
                if (rot == 0f) {
                    add(left, top, left + w, top + h)
                } else {
                    // rotate hone wali images (analog hands) ke liye pivot ke around gola, taaki size stable rahe
                    val r = max(
                        max(hypot(left - px, top - py), hypot(left + w - px, top - py)),
                        max(hypot(left - px, top + h - py), hypot(left + w - px, top + h - py))
                    )
                    add(px - r, py - r, px + r, py + r)
                }
                return
            }
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            paint.alpha = num(e, "alpha", 255.0).toInt().coerceIn(0, 255)
            val c = canvas!!
            c.save()
            if (rot != 0f) c.rotate(rot, px, py)
            c.drawBitmap(bm, null, RectF(left, top, left + w, top + h), paint)
            c.restore()
        }

        fun drawImageNumber(e: Element, ox: Float, oy: Float) {
            val src = e.getAttribute("src")
            val s = Expr.fmt(expr.eval(e.getAttribute("number")))
            val space = num(e, "space").toFloat()
            val bms = ArrayList<Bitmap>()
            for (ch in s) {
                val id = when {
                    ch.isDigit() -> ch.toString()
                    ch == '.' -> "dot"
                    ch == '-' -> "minus"
                    else -> continue
                }
                load(withId(src, id))?.let { bms.add(it) }
            }
            if (bms.isEmpty()) return
            var total = space * (bms.size - 1)
            var hh = 0f
            for (b in bms) {
                total += b.width
                hh = max(hh, b.height.toFloat())
            }
            val x = ox + num(e, "x").toFloat()
            val y = oy + num(e, "y").toFloat()
            var cx = alignX(e.getAttribute("align"), x, total)
            val top = alignY(e.getAttribute("alignV"), y, hh)
            if (dry) {
                add(cx, top, cx + total, top + hh)
                return
            }
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            paint.alpha = num(e, "alpha", 255.0).toInt().coerceIn(0, 255)
            for (b in bms) {
                canvas!!.drawBitmap(b, cx, top, paint)
                cx += b.width + space
            }
        }

        fun drawRect(e: Element, ox: Float, oy: Float, circle: Boolean) {
            val x = ox + num(e, "x").toFloat()
            val y = oy + num(e, "y").toFloat()
            val w: Float
            val h: Float
            val left: Float
            val top: Float
            if (circle) {
                val r = num(e, "r").toFloat()
                w = r * 2
                h = r * 2
                left = x - r
                top = y - r
            } else {
                w = num(e, "w").toFloat()
                h = num(e, "h").toFloat()
                left = alignX(e.getAttribute("align"), x, w)
                top = alignY(e.getAttribute("alignV"), y, h)
            }
            if (dry) {
                add(left, top, left + w, top + h)
                return
            }
            val c = canvas!!
            val fill = colorAttr(e, "fillColor")
            val stroke = colorAttr(e, "color")
            val weight = num(e, "weight").toFloat()
            val alpha = num(e, "alpha", 255.0).coerceIn(0.0, 255.0)
            val rect = RectF(left, top, left + w, top + h)
            val cr = num(e, "cornerRadius").toFloat()
            fun shape(p: Paint) {
                if (circle) c.drawOval(rect, p) else c.drawRoundRect(rect, cr, cr, p)
            }
            if (fill != null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = fill
                p.alpha = (Color.alpha(fill) * alpha / 255.0).toInt()
                shape(p)
            }
            if (stroke != null && weight > 0f) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.style = Paint.Style.STROKE
                p.strokeWidth = weight
                p.color = stroke
                p.alpha = (Color.alpha(stroke) * alpha / 255.0).toInt()
                shape(p)
            }
        }

        fun drawText(e: Element, text: String, ox: Float, oy: Float) {
            if (text.isEmpty()) return
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.textSize = num(e, "size", 20.0).toFloat()
            val color = colorAttr(e, "color") ?: Color.WHITE
            paint.color = color
            val a = num(e, "alpha", 255.0).coerceIn(0.0, 255.0)
            paint.alpha = (Color.alpha(color) * a / 255.0).toInt()
            val fam = e.getAttribute("fontFamily")
            if (fam.isNotEmpty()) paint.typeface = Typeface.create(fam, Typeface.NORMAL)
            paint.textAlign = when (e.getAttribute("align")) {
                "center" -> Paint.Align.CENTER
                "right" -> Paint.Align.RIGHT
                else -> Paint.Align.LEFT
            }
            val x = ox + num(e, "x").toFloat()
            var y = oy + num(e, "y").toFloat()
            val fm = paint.fontMetrics
            y += when (e.getAttribute("alignV")) {
                "center" -> -(fm.ascent + fm.descent) / 2
                "bottom" -> -fm.descent
                else -> -fm.ascent
            }
            if (dry) {
                val tw = paint.measureText(text)
                val l = when (paint.textAlign) {
                    Paint.Align.CENTER -> x - tw / 2
                    Paint.Align.RIGHT -> x - tw
                    else -> x
                }
                add(l, y + fm.ascent, l + tw, y + fm.descent)
                return
            }
            canvas!!.drawText(text, x, y, paint)
        }
    }
}
