package com.example.clockwidget

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private enum class Screen { GALLERY, EDITOR, ACTIVE }

    private lateinit var host: FrameLayout
    private var screen = Screen.GALLERY
    private var galleryTab = 0 // 0 = Built-in, 1 = Imported
    private var editorBoundId: Int? = null
    private var editorClockId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Pal.init(this)
        host = FrameLayout(this)
        applyChrome()
        setContentView(host)

        val wid = intent?.getIntExtra(EXTRA_WIDGET_ID, -1) ?: -1
        if (wid != -1) {
            val cfg = Prefs.widget(this, wid)
            if (cfg != null) {
                showEditor(cfg.clockId, wid)
                return
            }
        }
        showGallery()
        if (savedInstanceState == null) showJoinDialog()
    }

    /** Status/navigation bar aur background ko current (dark/light) theme ke mutabiq karta hai. */
    @Suppress("DEPRECATION")
    private fun applyChrome() {
        window.statusBarColor = Pal.uBg
        window.navigationBarColor = Pal.uBg
        host.setBackgroundColor(Pal.uBg)
        var f = window.decorView.systemUiVisibility
        f = if (Pal.dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            f = if (Pal.dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    private fun dialogTheme() =
        if (Pal.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    /** Theme badli (settings se ya system se): chrome + current screen dobara banao. */
    private fun refreshTheme() {
        Pal.init(this)
        applyChrome()
        when (screen) {
            Screen.GALLERY -> showGallery()
            Screen.ACTIVE -> showActive()
            Screen.EDITOR -> showEditor(editorClockId, editorBoundId)
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (Prefs.getInt(this, "app_theme", 0) == 0) refreshTheme()
    }

    private fun show(content: View) {
        host.removeAllViews()
        host.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun page(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Pal.uBg)
            addView(col)
        }
        return Pair(sv, col)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ───────────────────────── Gallery ─────────────────────────

    // Floating bar state
    private var pager: SwipeFrame? = null
    private var barView: GlassBar? = null
    private var galleryRoot: FrameLayout? = null

    private val barAccents = intArrayOf(
        Pal.GOLD, 0xFFFFFFFF.toInt(), 0xFFFF8FA3.toInt(), 0xFF7EE0B5.toInt(),
        0xFFB59CFF.toInt(), 0xFFFF9A5C.toInt(), 0xFF6CB8FF.toInt()
    )

    private fun showGallery() {
        screen = Screen.GALLERY
        val root = FrameLayout(this).apply { setBackgroundColor(Pal.uBg) }
        galleryRoot = root
        val pg = SwipeFrame(this) { dir -> setTab((galleryTab + dir).coerceIn(0, 2), dir) }
        pager = pg
        pg.addView(buildTab(galleryTab), FrameLayout.LayoutParams(-1, -1))
        root.addView(pg, FrameLayout.LayoutParams(-1, -1))
        val bar = GlassBar(this).apply {
            onSelect = { i -> setTab(i, if (i > galleryTab) 1 else -1, fromBar = true) }
        }
        barView = bar
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        styleBar()
        show(root)
    }

    /** Tab badalna: naya page slide+fade me aata hai. dir: +1 = right-to-left, -1 = left-to-right. */
    private fun setTab(i: Int, dir: Int, fromBar: Boolean = false) {
        if (i == galleryTab) return
        galleryTab = i
        if (!fromBar) barView?.select(i)
        val pg = pager ?: return
        val old = if (pg.childCount > 0) pg.getChildAt(0) else null
        val fresh = buildTab(i)
        pg.addView(fresh, FrameLayout.LayoutParams(-1, -1))
        val w = pg.width.toFloat().coerceAtLeast(1f)
        fresh.translationX = dir * w * 0.25f
        fresh.alpha = 0f
        fresh.animate().translationX(0f).alpha(1f).setDuration(220).start()
        old?.animate()?.translationX(-dir * w * 0.25f)?.alpha(0f)?.setDuration(180)
            ?.withEndAction { pg.removeView(old) }?.start()
    }

    private fun buildTab(tab: Int): View {
        val (sv, col) = page()
        col.setPadding(dp(20), dp(24), dp(20), dp(150))
        when (tab) {
            0, 1 -> {
                galleryHeader(col)
                col.addView(spacer(24))
                if (tab == 0) {
                    col.addView(label("Built-in collection  ·  ${Builtins.list.size}"))
                    col.addView(spacer(12))
                    addGrid(col, Builtins.list.map { Card("Cfg", it.id, it.name, it.kind, false) })
                } else {
                    col.addView(label("Imported & Xiaomi themes"))
                    col.addView(spacer(12))
                    val themes = ThemeStore.list(this)
                        .sortedByDescending { ThemeStore.isBundled(it.id) }
                        .map {
                            val b = ThemeStore.isBundled(it.id)
                            Card("T", "t:${it.id}", it.name, if (b) "Xiaomi · built-in" else "Imported · hold to delete", !b)
                        }
                    addGrid(col, themes, withImport = true)
                    col.addView(spacer(24))
                    col.addView(tv(
                        "Works with Xiaomi / MIUI / HyperOS clock themes (.zip or .mtz with manifest.xml). Tap ＋ to import — as many as you like. Need help? Tap ? at the top.",
                        12f, Pal.uMuted
                    ))
                }
                col.addView(spacer(28))
                col.addView(tv("CRAFTED BY RANWEIR  ·  v3.0", 11f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.25f).apply {
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            else -> buildSettings(col)
        }
        return sv
    }

    private fun galleryHeader(col: LinearLayout) {
        val header = LinearLayout(this).apply { gravity = Gravity.TOP }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("Aurum"))
        left.addView(spacer(6))
        left.addView(serif("Clock Atelier", 32f))
        left.addView(spacer(4))
        left.addView(tv("by Ranweir", 12f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.14f))
        left.addView(spacer(12))
        val active = ClockWidgetProvider.ids(this).size
        left.addView(TextView(this).apply {
            text = "$active ACTIVE  ›"
            textSize = 12f
            letterSpacing = 0.16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Pal.uGold)
            background = rounded(0, 20, Pal.uGold, 1)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showActive() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(circleButton("＋") { galleryTab = 1; pickFile() })
        header.addView(spacer(0).apply { layoutParams = LinearLayout.LayoutParams(dp(10), 1) })
        header.addView(circleButton("?") { showHelp() })
        col.addView(header)
    }

    // ───────────── Floating frosted-glass bar ─────────────

    private fun styleBar() {
        val bar = barView ?: return
        val frost = Prefs.getInt(this, "bar_frost", 55)
        val size = Prefs.getInt(this, "bar_size", 50)
        val lift = Prefs.getInt(this, "bar_lift", 30)
        val accent = Pal.readable(Prefs.getInt(this, "bar_accent", Pal.GOLD))
        val labels = Prefs.getInt(this, "bar_labels", 0) == 1   // default: OFF

        val a = (80 + frost * 1.5f).toInt().coerceIn(0, 235)
        val top: Int
        val bottom: Int
        val edge: Int
        if (Pal.dark) {
            top = android.graphics.Color.argb(a, 70, 72, 86); bottom = android.graphics.Color.argb(a, 26, 27, 34)
            edge = android.graphics.Color.argb(70, 255, 255, 255)
        } else {
            top = android.graphics.Color.argb(a, 255, 255, 255); bottom = android.graphics.Color.argb(a, 232, 229, 222)
            edge = android.graphics.Color.argb(60, 0, 0, 0)
        }
        bar.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)
        ).apply {
            cornerRadius = dp(40).toFloat()
            setStroke(dp(1), edge)
        }
        bar.elevation = dp(10).toFloat()
        val padV = dp(6 + size / 12)
        bar.setPadding(dp(8), padV, dp(8), padV)
        (bar.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(8 + lift)
        bar.requestLayout()

        bar.accent = accent
        bar.idleColor = Pal.uMuted
        bar.removeAllViews()
        val names = listOf("Built-in", "Imported", "Settings")
        val icon = dp(20 + size / 14)
        for (i in 0..2) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(7), dp(20), dp(7))
            }
            item.addView(BarIcon(this, i).apply { tint = Pal.uMuted }, LinearLayout.LayoutParams(icon, icon))
            if (labels) {
                item.addView(spacer(3))
                item.addView(tv(names[i], 10f, Pal.uMuted,
                    Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.06f).apply { gravity = Gravity.CENTER })
            }
            bar.addView(item, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(2)
            })
        }
        bar.resetTo(galleryTab)
    }

    private fun buildSettings(col: LinearLayout) {
        col.addView(label("Aurum"))
        col.addView(spacer(6))
        col.addView(serif("Settings", 32f))
        col.addView(spacer(4))
        col.addView(tv("Customise the app and the floating bar. Changes show live.", 12f, Pal.uMuted))
        col.addView(spacer(26))

        col.addView(label("Appearance"))
        col.addView(spacer(12))
        val themeRow = LinearLayout(this)
        val modeNames = listOf("SYSTEM", "DARK", "LIGHT")
        val modeChips = modeNames.map { chip(it) }
        for ((i, c) in modeChips.withIndex()) {
            styleChip(c, Pal.mode == i)
            c.setOnClickListener {
                if (Pal.mode != i) { Prefs.setInt(this, "app_theme", i); refreshTheme() }
            }
            themeRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(10)
            })
        }
        col.addView(themeRow)
        col.addView(spacer(4))
        col.addView(tv("System follows your phone's dark / light setting.", 11f, Pal.uMuted).apply { setPadding(0, dp(8), 0, 0) })
        col.addView(spacer(26))

        col.addView(label("Floating bar"))
        sliderRow(col, "Frost opacity", Prefs.getInt(this, "bar_frost", 55)) { Prefs.setInt(this, "bar_frost", it); styleBar() }
        sliderRow(col, "Bar size", Prefs.getInt(this, "bar_size", 50)) { Prefs.setInt(this, "bar_size", it); styleBar() }
        sliderRow(col, "Height from bottom", Prefs.getInt(this, "bar_lift", 30)) { Prefs.setInt(this, "bar_lift", it); styleBar() }

        col.addView(spacer(22))
        col.addView(tv("Accent colour", 13f, Pal.uText))
        col.addView(spacer(10))
        val sw = LinearLayout(this)
        val dots = ArrayList<View>()
        buildAccentDots(sw, dots)
        col.addView(sw)

        col.addView(spacer(22))
        val lab = chip("")
        fun styleLab() {
            val on = Prefs.getInt(this, "bar_labels", 0) == 1
            lab.text = if (on) "LABELS  ·  ON" else "LABELS  ·  OFF"
            styleChip(lab, on)
        }
        styleLab()
        lab.setOnClickListener {
            Prefs.setInt(this, "bar_labels", 1 - Prefs.getInt(this, "bar_labels", 0))
            styleLab(); styleBar()
        }
        col.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(spacer(14))
        val reset = chip("RESET BAR")
        styleChip(reset, false)
        reset.setOnClickListener {
            for (k in listOf("bar_frost", "bar_size", "bar_lift", "bar_accent", "bar_labels"))
                getSharedPreferences("aurum", MODE_PRIVATE).edit().remove(k).apply()
            styleBar()
            pager?.let { pg ->
                pg.removeAllViews()
                pg.addView(buildTab(2), FrameLayout.LayoutParams(-1, -1))
            }
        }
        col.addView(reset, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(spacer(34))
        col.addView(label("About"))
        col.addView(spacer(12))
        col.addView(tv("Aurum Clock  ·  v3.0", 14f, Pal.uText))
        col.addView(spacer(4))
        col.addView(tv("Crafted by Ranweir", 12f, Pal.uMuted))
        col.addView(spacer(14))
        col.addView(tv("How to use  ›", 13f, Pal.uGold).apply {
            setPadding(0, dp(6), 0, dp(6)); setOnClickListener { showHelp() }
        })
        col.addView(tv("Join the channel on Telegram  ›", 13f, Pal.uGold).apply {
            setPadding(0, dp(6), 0, dp(6)); setOnClickListener { openTelegram() }
        })
    }

    private fun buildAccentDots(sw: LinearLayout, dots: ArrayList<View>) {
        val cur = Prefs.getInt(this, "bar_accent", Pal.GOLD)
        for (c in barAccents) {
            val d = View(this)
            d.background = rounded(c, 18, if (cur == c) Pal.uTitle else Pal.uStroke, 2)
            d.setOnClickListener {
                Prefs.setInt(this, "bar_accent", c)
                styleBar()
                sw.removeAllViews(); dots.clear()
                buildAccentDots(sw, dots)
            }
            dots.add(d)
            sw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
    }

    private class Card(val kind: String, val clockId: String, val name: String, val caption: String, val isTheme: Boolean)

    private fun addGrid(col: LinearLayout, cards: List<Card>, withImport: Boolean = false) {
        val views = ArrayList<View>()
        for (c in cards) views.add(clockCard(c))
        if (withImport) views.add(importCard())
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(this)
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(if (j == 0) 0 else dp(6), dp(6), if (j == 0) dp(6) else 0, dp(6))
                if (i + j < views.size) row.addView(views[i + j], lp)
                else row.addView(View(this), lp)
            }
            col.addView(row)
            i += 2
        }
    }

    private fun clockCard(c: Card): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Pal.uSurface, 26, Pal.uStroke, 1)
            setPadding(dp(10), dp(10), dp(10), dp(14))
        }
        val iv = ImageView(this).apply {
            background = previewBackdrop(18)
            clipToOutline = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        Previews.load(this, iv, Cfg(c.clockId), 400, 300)
        card.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(124)))
        card.addView(spacer(10))
        card.addView(tv(c.name, 14f, Pal.uText, Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply {
            setPadding(dp(4), 0, dp(4), 0)
            maxLines = 1
        })
        card.addView(spacer(3))
        card.addView(tv(c.caption, 11f, Pal.uMuted).apply { setPadding(dp(4), 0, dp(4), 0) })
        card.setOnClickListener { showEditor(c.clockId, null) }
        if (c.isTheme) {
            card.setOnLongClickListener {
                AlertDialog.Builder(this, dialogTheme())
                    .setTitle("Delete theme?")
                    .setMessage("“${c.name}” will be removed. Widgets using it will fall back to a built-in clock.")
                    .setPositiveButton("Delete") { _, _ ->
                        ThemeStore.delete(this, c.clockId.substring(2))
                        ClockWidgetProvider.refresh(this)
                        showGallery()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
        return card
    }

    private fun importCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0, 26, Pal.uGold, 1, dashed = true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        card.addView(tv("＋", 30f, Pal.uGold, Typeface.create("sans-serif-thin", Typeface.NORMAL)))
        card.addView(spacer(8))
        card.addView(tv("IMPORT THEME", 12f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.18f))
        card.addView(spacer(4))
        card.addView(tv(".zip file", 11f, Pal.uMuted))
        card.minimumHeight = dp(190)
        card.setOnClickListener { pickFile() }
        return card
    }

    private fun openTelegram() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)))
        } catch (e: Exception) {
            toast("Could not open Telegram")
        }
    }

    private fun showJoinDialog() {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(26), dp(24), dp(22))
            background = rounded(Pal.uSurface, 28, Pal.uGold, 1)
        }
        box.addView(label("Community"))
        box.addView(spacer(8))
        box.addView(serif("Join Ranweir's Inventory", 24f))
        box.addView(spacer(10))
        box.addView(tv("New clock styles, themes and updates are shared on Telegram. Join the channel to stay in the loop.", 13.5f, Pal.uMuted))
        box.addView(spacer(22))
        val row = LinearLayout(this)
        row.addView(pill("Close", false) { d.dismiss() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(10) })
        row.addView(pill("Telegram", true) {
            openTelegram()
            d.dismiss()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        d.setContentView(box)
        d.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }


    private fun showHelp() {
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("How to use")
            .setMessage(
                "ADD A CLOCK\n" +
                    "1. Pick a clock and customise it.\n" +
                    "2. Tap “Add to home screen” (or long-press your home screen › Widgets › Aurum Clock).\n" +
                    "3. Resize the widget by long-pressing it — the clock scales automatically.\n" +
                    "4. Tap a widget any time to edit it.\n\n" +
                    "IMPORT A XIAOMI CLOCK THEME\n" +
                    "1. Download a clock theme as a .zip or .mtz file (from the Xiaomi Themes app, a theme site or a Telegram channel). If it came as a folder, zip it so manifest.xml is inside.\n" +
                    "2. In Aurum open the Imported tab (middle icon in the bottom bar) and tap “＋” (top right) or “IMPORT THEME”.\n" +
                    "3. Choose the downloaded file. When it says “Theme imported”, the clock appears in the Imported tab.\n" +
                    "4. Tap it to customise, then “Add to home screen”. Long-press a theme to delete it.\n" +
                    "Note: buttons, animations, music controls and Xiaomi weather inside a theme are not supported (weather shows --°).\n\n" +
                    "FLOATING BAR\n" +
                    "Tap an icon, or press and slide your finger along the bar, to switch between Built-in, Imported and Settings. You can also swipe the page left / right.\n\n" +
                    "APP THEME\n" +
                    "Settings › Appearance: System (follows your phone), Dark or Light.\n\n" +
                    "Tip (ColorOS): Settings › Battery › Aurum Clock › Unrestricted, and allow auto-launch, so the time keeps updating.\n\nMade by Ranweir · t.me/ranweirsinventory"
            )
            .setPositiveButton("Got it", null)
            .show()
    }

    // ───────────────────────── Active widgets ─────────────────────────

    private fun showActive() {
        screen = Screen.ACTIVE
        val (sv, col) = page()
        col.addView(topBar("Active widgets") { showGallery() })
        col.addView(spacer(20))
        val mgr = AppWidgetManager.getInstance(this)
        val ids = ClockWidgetProvider.ids(this)
        if (ids.isEmpty()) {
            col.addView(tv("No widgets on your home screen yet.\nPick a clock and tap “Add to home screen”.", 14f, Pal.uMuted))
        }
        for (id in ids) {
            val cfg = Prefs.widget(this, id) ?: Prefs.draft(this)
            val (w, h) = ClockWidgetProvider.sizeFor(this, mgr, id)
            val pw = 480
            val ph = (pw.toFloat() * h / w).toInt().coerceIn(160, 480)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Pal.uSurface, 24, Pal.uStroke, 1)
                setPadding(dp(12), dp(12), dp(16), dp(12))
            }
            val iv = ImageView(this).apply {
                background = previewBackdrop(16)
                clipToOutline = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            Previews.load(this, iv, cfg, pw, ph)
            row.addView(iv, LinearLayout.LayoutParams(dp(150), dp(90)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(tv(ClockEngine.nameOf(this, cfg.clockId), 15f, Pal.uText, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
            info.addView(spacer(4))
            info.addView(tv("Size ${cfg.scale}%  ·  Tap to edit", 12f, Pal.uMuted))
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
            row.addView(tv("›", 24f, Pal.uGold))
            row.setOnClickListener { showEditor(cfg.clockId, id) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            col.addView(row, lp)
        }
        show(sv)
    }

    // ───────────────────────── Editor ─────────────────────────

    private fun topBar(title: String, onBack: () -> Unit): View {
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(circleButton("‹") { onBack() })
        bar.addView(serif(title, 24f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(14) })
        return bar
    }

    private fun showEditor(clockId: String, boundId: Int?) {
        screen = Screen.EDITOR
        editorBoundId = boundId
        editorClockId = clockId
        val isTheme = clockId.startsWith("t:")
        var cfg = (if (boundId != null) Prefs.widget(this, boundId) ?: Prefs.draft(this) else Prefs.draft(this))
            .copy(clockId = clockId)

        val mgr = AppWidgetManager.getInstance(this)
        val (ww, wh) = if (boundId != null) ClockWidgetProvider.sizeFor(this, mgr, boundId) else Pair(960, 480)
        val pw = 900
        val ph = (pw.toFloat() * wh / ww).toInt().coerceIn(300, 900)

        val (sv, col) = page()
        col.addView(topBar(ClockEngine.nameOf(this, clockId)) {
            if (boundId != null) showActive() else showGallery()
        })
        col.addView(spacer(20))

        val preview = ImageView(this).apply {
            background = previewBackdrop(28)
            clipToOutline = true
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(tv(
            if (boundId != null) "Preview matches your widget's current shape" else "Preview · widget size follows how you resize it",
            11f, Pal.uMuted
        ).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun commit() {
            Previews.live(this, preview, cfg, pw, ph) { c ->
                if (boundId != null) {
                    Prefs.setWidget(this, boundId, c)
                    ClockWidgetProvider.refreshOne(this, mgr, boundId)
                } else {
                    Prefs.setDraft(this, c)
                }
            }
        }

        // Size
        col.addView(spacer(24))
        val sizeHead = LinearLayout(this)
        sizeHead.addView(label("Size"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sizeVal = tv("${cfg.scale}%", 13f, Pal.uText)
        sizeHead.addView(sizeVal)
        col.addView(sizeHead)
        col.addView(spacer(8))
        val seek = SeekBar(this).apply {
            max = 70                // 30% .. 100%
            progress = (cfg.scale - 30).coerceIn(0, 70)
            progressTintList = android.content.res.ColorStateList.valueOf(Pal.uGold)
            thumbTintList = android.content.res.ColorStateList.valueOf(Pal.uText)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(scale = p + 30)
                    sizeVal.text = "${cfg.scale}%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(seek)
        col.addView(tv("100% fills the widget. To make the clock bigger, resize the widget on your home screen (long-press the widget).", 11f, Pal.uMuted))

        // Effects
        col.addView(spacer(24))
        col.addView(label("Effects"))
        col.addView(spacer(12))
        val fluxChip = chip("FLUX GLOW · COLOROS 17")
        fun restyleFlux() = styleChip(fluxChip, cfg.flux)
        fluxChip.setOnClickListener { cfg = cfg.copy(flux = !cfg.flux); restyleFlux(); commit() }
        restyleFlux()
        col.addView(fluxChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(spacer(6))
        col.addView(tv("Edge-lit translucent glass in your wallpaper colours with a soft halo, like ColorOS 17. Font and shape stay untouched. The glow slider sets its intensity; it replaces Frosted glass.", 11f, Pal.uMuted))
        sliderRow(col, "Flux glass transparency", cfg.clear) { cfg = cfg.copy(clear = it); commit() }
        col.addView(spacer(16))
        val glassChip = chip("FROSTED GLASS")
        fun restyleGlass() = styleChip(glassChip, cfg.glass)
        glassChip.setOnClickListener { cfg = cfg.copy(glass = !cfg.glass); restyleGlass(); commit() }
        restyleGlass()
        col.addView(glassChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(spacer(18))
        val glowHead = LinearLayout(this)
        glowHead.addView(tv("Inner glow", 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val glowVal = tv("${cfg.glow}%", 13f, Pal.uText)
        glowHead.addView(glowVal)
        col.addView(glowHead)
        col.addView(spacer(8))
        col.addView(SeekBar(this).apply {
            max = 100
            progress = cfg.glow
            progressTintList = android.content.res.ColorStateList.valueOf(Pal.uGold)
            thumbTintList = android.content.res.ColorStateList.valueOf(Pal.uText)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(glow = p)
                    glowVal.text = "$p%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(spacer(16))
        col.addView(tv("Inner glow colour  (A = keep the clock's own colours)", 13f, Pal.uText))
        col.addView(spacer(10))
        val gsw = LinearLayout(this)
        val gdots = ArrayList<TextView>()
        fun restyleGlow() {
            for ((i, d) in gdots.withIndex()) {
                val colr = Pal.glowColors[i]
                val sel = colr == cfg.glowColor
                d.background = rounded(if (colr == 0) Pal.uSurface2 else colr, 18, if (sel) Pal.uTitle else Pal.uStroke, if (sel) 2 else 1)
            }
        }
        for (colr in Pal.glowColors) {
            val d = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(Pal.uText)
                text = if (colr == 0) "A" else ""
            }
            gdots.add(d)
            d.setOnClickListener { cfg = cfg.copy(glowColor = colr); restyleGlow(); commit() }
            gsw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
        restyleGlow()
        col.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(gsw)
        })

        // Date controls
        val hasDate = clockId != "b:analog"
        if (hasDate) {
            col.addView(spacer(28))
            col.addView(label("Date"))
            col.addView(spacer(12))
            val dateChip = chip("SHOW DATE")
            fun restyleDate() = styleChip(dateChip, cfg.showDate)
            dateChip.setOnClickListener { cfg = cfg.copy(showDate = !cfg.showDate); restyleDate(); commit() }
            restyleDate()
            col.addView(dateChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            sliderRow(col, "Date glow", if (cfg.dateGlow >= 0) cfg.dateGlow else cfg.glow) { cfg = cfg.copy(dateGlow = it); commit() }
            sliderRow(col, "Date transparency (Flux)", if (cfg.dateClear >= 0) cfg.dateClear else cfg.clear) { cfg = cfg.copy(dateClear = it); commit() }
        }

        // Colon controls
        val supportsColon = isTheme || Builtins.hasColon(clockId)
        if (supportsColon) {
            col.addView(spacer(28))
            col.addView(label("Colon  :"))
            col.addView(spacer(12))
            val colonChip = chip("SHOW COLON")
            fun restyleColon() = styleChip(colonChip, cfg.colon)
            colonChip.setOnClickListener { cfg = cfg.copy(colon = !cfg.colon); restyleColon(); commit() }
            restyleColon()
            col.addView(colonChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            sliderRow(col, "Colon glow", if (cfg.colGlow >= 0) cfg.colGlow else cfg.glow) { cfg = cfg.copy(colGlow = it); commit() }
            sliderRow(col, "Colon transparency (Flux)", if (cfg.colClear >= 0) cfg.colClear else cfg.clear) { cfg = cfg.copy(colClear = it); commit() }
        }

        // Backdrop blur
        col.addView(spacer(28))
        col.addView(label("Backdrop blur"))
        col.addView(spacer(6))
        val hasWall = WallStore.has(this)
        col.addView(tv(
            if (hasWall) "Real frosted glass: your wallpaper, blurred, shows through the digits. 0 = off."
            else "Choose your wallpaper image below for real frosted glass (a widget cannot read the wallpaper behind it). Without it, a soft tinted layer is used. 0 = off.",
            11f, Pal.uMuted
        ))
        col.addView(spacer(12))
        val wallRow = LinearLayout(this)
        wallRow.addView(chip(if (hasWall) "CHANGE WALLPAPER" else "CHOOSE WALLPAPER").also { c ->
            styleChip(c, false)
            c.setOnClickListener { pickWallpaper() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
        if (hasWall) {
            wallRow.addView(chip("REMOVE").also { c ->
                styleChip(c, false)
                c.setOnClickListener {
                    WallStore.clear(this)
                    showEditor(clockId, boundId)
                }
            })
        }
        col.addView(wallRow)
        sliderRow(col, "Blur", cfg.blur) { cfg = cfg.copy(blur = it); commit() }
        sliderRow(col, "Backdrop glow (brightness)", cfg.bgGlow) { cfg = cfg.copy(bgGlow = it); commit() }
        if (hasWall) {
            sliderRow(col, "Widget position on screen (top to bottom)", cfg.wallY) { cfg = cfg.copy(wallY = it); commit() }
        }

        if (!isTheme) {
            // Accent
            col.addView(spacer(24))
            col.addView(label("Accent colour"))
            col.addView(spacer(12))
            val sw = LinearLayout(this)
            val dots = ArrayList<View>()
            fun restyle() {
                for ((i, d) in dots.withIndex()) {
                    val sel = Pal.accents[i] == cfg.accent
                    d.background = rounded(Pal.accents[i], 18, if (sel) Pal.uTitle else Pal.uStroke, if (sel) 2 else 1)
                }
            }
            for (colr in Pal.accents) {
                val d = View(this)
                dots.add(d)
                d.setOnClickListener { cfg = cfg.copy(accent = colr); restyle(); commit() }
                sw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
            }
            restyle()
            col.addView(android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(sw)
            })

            // 12 / 24h
            col.addView(spacer(24))
            col.addView(label("Time format"))
            col.addView(spacer(12))
            val chips = LinearLayout(this)
            val chip24 = chip("24 HOUR")
            val chip12 = chip("12 HOUR")
            fun restyleChips() {
                styleChip(chip24, !cfg.use12h)
                styleChip(chip12, cfg.use12h)
            }
            chip24.setOnClickListener { cfg = cfg.copy(use12h = false); restyleChips(); commit() }
            chip12.setOnClickListener { cfg = cfg.copy(use12h = true); restyleChips(); commit() }
            restyleChips()
            chips.addView(chip24, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            chips.addView(chip12)
            col.addView(chips)
        } else {
            col.addView(spacer(20))
            col.addView(tv("Colours and fonts come from the imported theme.", 12f, Pal.uMuted))
        }

        col.addView(spacer(32))
        if (boundId != null) {
            col.addView(pill("Done", true) { showActive() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        } else {
            col.addView(pill("Add to home screen", true) { pin() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        show(sv)
        commit()
    }

    private fun sliderRow(col: LinearLayout, title: String, value: Int, onChange: (Int) -> Unit) {
        val head = LinearLayout(this)
        head.addView(tv(title, 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = tv("$value%", 13f, Pal.uText)
        head.addView(v)
        col.addView(spacer(16))
        col.addView(head)
        col.addView(spacer(8))
        col.addView(SeekBar(this).apply {
            max = 100
            progress = value
            progressTintList = android.content.res.ColorStateList.valueOf(Pal.uGold)
            thumbTintList = android.content.res.ColorStateList.valueOf(Pal.uText)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    v.text = "$p%"
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }


    private fun chip(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.16f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(18), dp(10), dp(18), dp(10))
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        t.setTextColor(if (selected) Pal.uOnGold else Pal.uText)
        t.background = if (selected) rounded(Pal.uGold, 20) else rounded(Pal.uSurface2, 20, Pal.uStroke, 1)
    }

    private fun pin() {
        val mgr = getSystemService(AppWidgetManager::class.java)
        if (mgr != null && mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
            toast("Confirm the widget on your home screen")
        } else {
            toast("Long-press your home screen › Widgets › Aurum Clock")
        }
    }

    // ───────────────────────── Import ─────────────────────────

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            // kuch phones par Documents picker nahi hota -> simple picker try karo
            try {
                val g = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(g, "Choose theme zip"), REQ_PICK)
            } catch (e2: Exception) {
                toast("No file picker found on this phone")
            }
        }
    }

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_WALL)
        } catch (e: Exception) {
            toast("No file picker found on this phone")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "theme"
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "theme"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == REQ_WALL) {
            val u = data?.data ?: return
            Thread {
                val r = runCatching { WallStore.save(this, u) }
                runOnUiThread {
                    if (r.isSuccess) {
                        showEditor(editorClockId, editorBoundId)
                    } else {
                        toast("Could not use this image: ${r.exceptionOrNull()?.message}")
                    }
                }
            }.start()
            return
        }
        if (requestCode != REQ_PICK) return
        val uri = data?.data ?: return
        val name = displayName(uri)
        toast("Importing…")
        Thread {
            galleryTab = 1
            val r = runCatching { ThemeStore.import(this, uri, name) }
            runOnUiThread {
                if (r.isSuccess) {
                    toast("Theme imported")
                    showGallery()
                } else {
                    toast("Import failed: ${r.exceptionOrNull()?.message}")
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.GALLERY -> super.onBackPressed()
            Screen.ACTIVE -> showGallery()
            Screen.EDITOR -> if (editorBoundId != null) showActive() else showGallery()
        }
    }

    companion object {
        const val EXTRA_WIDGET_ID = "widget_id"
        private const val TELEGRAM_URL = "https://t.me/ranweirsinventory"
        private const val REQ_PICK = 1
        private const val REQ_WALL = 2
    }
}
