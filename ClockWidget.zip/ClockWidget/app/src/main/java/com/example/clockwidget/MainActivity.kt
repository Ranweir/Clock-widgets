package com.example.clockwidget

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private enum class Screen { GALLERY, EDITOR, ACTIVE }

    private lateinit var host: FrameLayout
    private var screen = Screen.GALLERY
    private var galleryTab = 0 // 0 = Built-in, 1 = Imported
    private var editorBoundId: Int? = null
    private var editorClockId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Pal.init(this)
        host = FrameLayout(this)
        requestHighRefresh()
        applyChrome()
        setContentView(host)

        val wid = intent?.getIntExtra(EXTRA_WIDGET_ID, -1) ?: -1
        if (wid != -1) {
            val cfg = Prefs.widget(this, wid)
            if (cfg != null) {
                showEditor(cfg.clockId, wid)
                return
            }
        }
        showGallery()
        if (savedInstanceState == null) showJoinDialog()
    }

    /** Status/navigation bar aur background ko current (dark/light) theme ke mutabiq karta hai. */
    @Suppress("DEPRECATION")
    private fun applyChrome() {
        window.statusBarColor = Pal.uBg
        window.navigationBarColor = Pal.uBg
        host.setBackgroundColor(Pal.uBg)
        var f = window.decorView.systemUiVisibility
        f = if (Pal.dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            f = if (Pal.dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    private fun dialogTheme() =
        if (Pal.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    /** Theme badli (settings se ya system se): chrome + current screen dobara banao. */
    private fun refreshTheme() {
        Pal.init(this)
        applyChrome()
        when (screen) {
            Screen.GALLERY -> showGallery()
            Screen.ACTIVE -> showActive()
            Screen.EDITOR -> showEditor(editorClockId, editorBoundId)
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (Prefs.getInt(this, "app_theme", 0) == 0) refreshTheme()
    }

    /** Device ka sabse tez refresh-rate mode maango (90/120Hz) — kai phones default 60Hz par atke rehte hain. */
    @Suppress("DEPRECATION")
    private fun requestHighRefresh() {
        if (android.os.Build.VERSION.SDK_INT < 23) return
        try {
            val d = windowManager.defaultDisplay
            val cur = d.mode
            val best = d.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (_: Throwable) {}
    }

    private val easeOut = android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)

    private fun show(content: View) {
        host.removeAllViews()
        host.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // screen badalne par halka fade + upar uthna
        content.alpha = 0f
        content.translationY = dp(12).toFloat()
        content.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(easeOut).start()
    }

    private fun page(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Pal.uBg)
            addView(col)
        }
        return Pair(sv, col)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ───────────────────────── Gallery ─────────────────────────

    // Floating bar state
    private var pager: SwipeFrame? = null
    private var barView: GlassBar? = null
    private var galleryRoot: FrameLayout? = null

    private val barAccents = intArrayOf(
        Pal.RED, 0xFFFFFFFF.toInt(), 0xFFFF8FA3.toInt(), 0xFF7EE0B5.toInt(),
        0xFFB59CFF.toInt(), 0xFFFF9A5C.toInt(), 0xFF6CB8FF.toInt()
    )

    private val tabCache = HashMap<Int, View>()

    private fun tabView(i: Int): View = tabCache.getOrPut(i) { buildTab(i) }

    private fun showGallery() {
        screen = Screen.GALLERY
        tabCache.clear()
        val root = FrameLayout(this).apply { setBackgroundColor(Pal.uBg) }
        galleryRoot = root
        val pg = SwipeFrame(this) { dir -> setTab((galleryTab + dir).coerceIn(0, 2), dir) }
        pager = pg
        pg.addView(tabView(galleryTab), FrameLayout.LayoutParams(-1, -1))
        root.addView(pg, FrameLayout.LayoutParams(-1, -1))
        val bar = GlassBar(this).apply {
            onSelect = { i -> setTab(i, if (i > galleryTab) 1 else -1, fromBar = true) }
        }
        barView = bar
        barKinds = intArrayOf(0, 1, 2)
        barNames = listOf("Built-in", "Imported", "Settings")
        barSelected = { galleryTab }
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        bar.bindSource(pg)
        Previews.onReady = { barView?.refreshBackdrop() }
        styleBar()
        show(root)
        // baaki tabs thodi der baad, khali samay me pehle se bana + measure kar lo (swipe par lag nahi)
        host.postDelayed({
            val q = android.os.Looper.myQueue()
            q.addIdleHandler {
                if (galleryRoot !== root || screen != Screen.GALLERY) return@addIdleHandler false
                val next = (0..2).firstOrNull { !tabCache.containsKey(it) } ?: return@addIdleHandler false
                val v = buildTab(next)
                val w = pg.width; val h = pg.height
                if (w > 0 && h > 0) {
                    v.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
                    v.layout(0, 0, w, h)
                }
                tabCache[next] = v
                true
            }
        }, 700)
    }

    private var tabAnimGen = 0

    /**
     * Tab badalna: naya page opaque hokar upar se slide karta hai, purana halka parallax me peeche hat-ta hai.
     * Koi alpha/crossfade nahi (ghosting nahi), koi GPU-layer nahi, aur bar ka blur transition me freeze rehta hai.
     */
    private fun setTab(i: Int, dir: Int, fromBar: Boolean = false) {
        if (i == galleryTab) return
        galleryTab = i
        if (!fromBar) barView?.select(i)
        val pg = pager ?: return
        slidePage(pg, tabView(i), dir)
    }

    /** Gallery aur Editor dono ke page-transition: naya page slide hokar aata hai, bar ka blur transition me freeze. */
    private fun slidePage(pg: SwipeFrame, fresh: View, dir: Int) {
        val gen = ++tabAnimGen
        barView?.setBackdropFrozen(true)
        val kids = (0 until pg.childCount).map { pg.getChildAt(it) }
        val old = kids.lastOrNull { it !== fresh }
        for (ch in kids) {
            if (ch === old) continue
            ch.animate().cancel()
            ch.translationX = 0f
            pg.removeView(ch)
        }
        fresh.animate().cancel()
        pg.addView(fresh, FrameLayout.LayoutParams(-1, -1))
        val w = pg.width.toFloat().coerceAtLeast(1f)
        fresh.alpha = 1f
        fresh.translationX = dir * w * 0.35f
        fresh.animate().translationX(0f).setDuration(300).setInterpolator(easeOut)
            .withEndAction { if (gen == tabAnimGen) barView?.setBackdropFrozen(false) }.start()
        old?.animate()?.translationX(-dir * w * 0.22f)?.setDuration(300)?.setInterpolator(easeOut)
            ?.withEndAction {
                old.translationX = 0f
                if (old.parent === pg) pg.removeView(old)
            }?.start()
    }

    // ── Editor ke pages (Clock / Style / Details) bhi isi liquid bar se badalte hain ──
    private var editorTab = 0
    private var edPager: SwipeFrame? = null
    private var edPages: List<View> = emptyList()

    private fun setEditorTab(i: Int, dir: Int, fromBar: Boolean = false) {
        if (i == editorTab || i !in edPages.indices) return
        editorTab = i
        if (!fromBar) barView?.select(i)
        val pg = edPager ?: return
        slidePage(pg, edPages[i], dir)
    }

    /** Editor ka ek page: scroll + neeche bar ke liye jagah. */
    private fun editorPage(): Pair<ScrollView, LinearLayout> {
        val (sv, col) = page()
        col.setPadding(dp(20), dp(6), dp(20), dp(150))
        return Pair(sv, col)
    }

    private fun buildTab(tab: Int): View {
        val (sv, col) = page()
        col.setPadding(dp(20), dp(24), dp(20), dp(150))
        when (tab) {
            0, 1 -> {
                galleryHeader(col)
                col.addView(spacer(24))
                if (tab == 0) {
                    col.addView(label("Built-in collection  ·  ${Builtins.list.size}"))
                    col.addView(spacer(12))
                    addGrid(col, Builtins.list.map { Card("Cfg", it.id, it.name, it.kind, false) })
                } else {
                    col.addView(label("Imported & Xiaomi themes"))
                    col.addView(spacer(12))
                    val themes = ThemeStore.list(this)
                        .sortedByDescending { ThemeStore.isBundled(it.id) }
                        .map {
                            val b = ThemeStore.isBundled(it.id)
                            Card("T", "t:${it.id}", it.name, if (b) "Xiaomi · built-in" else "Imported · hold to delete", !b)
                        }
                    addGrid(col, themes, withImport = true)
                    col.addView(spacer(24))
                    col.addView(tv(
                        "Works with Xiaomi / MIUI / HyperOS clock themes (.zip or .mtz with manifest.xml). Tap ＋ to import — as many as you like. Need help? Tap ? at the top.",
                        12f, Pal.uMuted
                    ))
                }
                col.addView(spacer(28))
                col.addView(tv("CRAFTED BY RANWEIR  ·  v5.1", 11f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.25f).apply {
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            else -> buildSettings(col)
        }
        return sv
    }

    private fun galleryHeader(col: LinearLayout) {
        val header = LinearLayout(this).apply { gravity = Gravity.TOP }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("Aurum"))
        left.addView(spacer(6))
        left.addView(serif("Clock Atelier", 32f))
        left.addView(spacer(4))
        left.addView(tv("by Ranweir", 12f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.14f))
        left.addView(spacer(12))
        val active = ClockWidgetProvider.ids(this).size
        left.addView(TextView(this).apply {
            text = "$active ACTIVE  ›"
            textSize = 12f
            letterSpacing = 0.16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Pal.uGold)
            background = rounded(0, 20, Pal.uGold, 1)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showActive() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(circleButton("＋") { galleryTab = 1; pickFile() })
        header.addView(spacer(0).apply { layoutParams = LinearLayout.LayoutParams(dp(10), 1) })
        header.addView(circleButton("?") { showHelp() })
        col.addView(header)
    }

    // ───────────── Floating frosted-glass bar ─────────────

    private var barKinds = intArrayOf(0, 1, 2)
    private var barNames = listOf("Built-in", "Imported", "Settings")
    private var barSelected: () -> Int = { galleryTab }

    private fun styleBar() {
        val bar = barView ?: return
        val frost = Prefs.getInt(this, "bar_frost", 55)
        val size = Prefs.getInt(this, "bar_size", 50)
        val lift = Prefs.getInt(this, "bar_lift", 30)
        val accent = Pal.readable(Prefs.getInt(this, "bar_accent", Pal.RED))
        val labels = Prefs.getInt(this, "bar_labels", 0) == 1   // default: OFF

        bar.background = null
        bar.setGlass(frost, Pal.dark)
        bar.elevation = dp(8).toFloat()
        val padV = dp(6 + size / 12)
        bar.setPadding(dp(8), padV, dp(8), padV)
        (bar.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(8 + lift)
        bar.requestLayout()

        bar.accent = accent
        bar.idleColor = Pal.uMuted
        bar.removeAllViews()
        val names = barNames
        val icon = dp(20 + size / 14)
        for (i in barKinds.indices) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(7), dp(20), dp(7))
            }
            item.addView(BarIcon(this, barKinds[i]).apply { tint = Pal.uMuted }, LinearLayout.LayoutParams(icon, icon))
            if (labels) {
                item.addView(spacer(3))
                item.addView(tv(names[i], 10f, Pal.uMuted,
                    Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.06f).apply { gravity = Gravity.CENTER })
            }
            bar.addView(item, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(2)
            })
        }
        bar.resetTo(barSelected())
    }

    private fun buildSettings(col: LinearLayout) {
        col.addView(label("Aurum"))
        col.addView(spacer(6))
        col.addView(serif("Settings", 32f))
        col.addView(spacer(4))
        col.addView(tv("Customise the app and the floating bar. Changes show live.", 12f, Pal.uMuted))
        col.addView(spacer(26))

        col.addView(label("Appearance"))
        col.addView(spacer(12))
        val themeRow = LinearLayout(this)
        val modeNames = listOf("SYSTEM", "DARK", "LIGHT")
        val modeChips = modeNames.map { chip(it) }
        for ((i, c) in modeChips.withIndex()) {
            styleChip(c, Pal.mode == i)
            c.setOnClickListener {
                if (Pal.mode != i) { Prefs.setInt(this, "app_theme", i); refreshTheme() }
            }
            themeRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(10)
            })
        }
        col.addView(themeRow)
        col.addView(spacer(4))
        col.addView(tv("System follows your phone's dark / light setting.", 11f, Pal.uMuted).apply { setPadding(0, dp(8), 0, 0) })
        col.addView(spacer(26))

        col.addView(label("Floating bar"))
        sliderRow(col, "Glass tint", Prefs.getInt(this, "bar_frost", 55)) { Prefs.setInt(this, "bar_frost", it); styleBar() }
        sliderRow(col, "Bar size", Prefs.getInt(this, "bar_size", 50)) { Prefs.setInt(this, "bar_size", it); styleBar() }
        sliderRow(col, "Height from bottom", Prefs.getInt(this, "bar_lift", 30)) { Prefs.setInt(this, "bar_lift", it); styleBar() }

        col.addView(spacer(22))
        col.addView(tv("Accent colour", 13f, Pal.uText))
        col.addView(spacer(10))
        val sw = LinearLayout(this)
        val dots = ArrayList<View>()
        buildAccentDots(sw, dots)
        col.addView(sw)

        col.addView(spacer(22))
        val lab = chip("")
        fun styleLab() {
            val on = Prefs.getInt(this, "bar_labels", 0) == 1
            lab.text = if (on) "LABELS  ·  ON" else "LABELS  ·  OFF"
            styleChip(lab, on)
        }
        styleLab()
        lab.setOnClickListener {
            Prefs.setInt(this, "bar_labels", 1 - Prefs.getInt(this, "bar_labels", 0))
            styleLab(); styleBar()
        }
        col.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(spacer(14))
        val reset = chip("RESET BAR")
        styleChip(reset, false)
        reset.setOnClickListener {
            for (k in listOf("bar_frost", "bar_size", "bar_lift", "bar_accent", "bar_labels"))
                getSharedPreferences("aurum", MODE_PRIVATE).edit().remove(k).apply()
            styleBar()
            pager?.let { pg ->
                pg.removeAllViews()
                pg.addView(buildTab(2), FrameLayout.LayoutParams(-1, -1))
            }
        }
        col.addView(reset, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(spacer(34))
        col.addView(label("About"))
        col.addView(spacer(12))
        col.addView(tv("Aurum Clock  ·  v5.1", 14f, Pal.uText))
        col.addView(spacer(4))
        col.addView(tv("Crafted by Ranweir", 12f, Pal.uMuted))
        col.addView(spacer(14))
        col.addView(tv("How to use  ›", 13f, Pal.uGold).apply {
            setPadding(0, dp(6), 0, dp(6)); setOnClickListener { showHelp() }
        })
        col.addView(tv("Join the channel on Telegram  ›", 13f, Pal.uGold).apply {
            setPadding(0, dp(6), 0, dp(6)); setOnClickListener { openTelegram() }
        })
    }

    private fun buildAccentDots(sw: LinearLayout, dots: ArrayList<View>) {
        val cur = Prefs.getInt(this, "bar_accent", Pal.RED)
        for (c in barAccents) {
            val d = View(this)
            d.background = rounded(c, 18, if (cur == c) Pal.uTitle else Pal.uStroke, 2)
            d.setOnClickListener {
                Prefs.setInt(this, "bar_accent", c)
                styleBar()
                sw.removeAllViews(); dots.clear()
                buildAccentDots(sw, dots)
            }
            dots.add(d)
            sw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
    }

    private class Card(val kind: String, val clockId: String, val name: String, val caption: String, val isTheme: Boolean)

    private fun addGrid(col: LinearLayout, cards: List<Card>, withImport: Boolean = false) {
        val views = ArrayList<View>()
        for (c in cards) views.add(clockCard(c))
        if (withImport) views.add(importCard())
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(this)
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(if (j == 0) 0 else dp(6), dp(6), if (j == 0) dp(6) else 0, dp(6))
                if (i + j < views.size) row.addView(views[i + j], lp)
                else row.addView(View(this), lp)
            }
            col.addView(row)
            i += 2
        }
    }

    private fun clockCard(c: Card): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Pal.uSurface, 26, Pal.uStroke, 1)
            setPadding(dp(10), dp(10), dp(10), dp(14))
        }
        val iv = ImageView(this).apply {
            background = previewBackdrop(18)
            clipToOutline = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        Previews.load(this, iv, Cfg(c.clockId), 400, 300)
        card.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(124)))
        card.addView(spacer(10))
        card.addView(tv(c.name, 14f, Pal.uText, Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply {
            setPadding(dp(4), 0, dp(4), 0)
            maxLines = 1
        })
        card.addView(spacer(3))
        card.addView(tv(c.caption, 11f, Pal.uMuted).apply { setPadding(dp(4), 0, dp(4), 0) })
        card.setOnClickListener { showEditor(c.clockId, null) }
        card.pressFeedback(0.965f)
        if (c.isTheme) {
            card.setOnLongClickListener {
                AlertDialog.Builder(this, dialogTheme())
                    .setTitle("Delete theme?")
                    .setMessage("“${c.name}” will be removed. Widgets using it will fall back to a built-in clock.")
                    .setPositiveButton("Delete") { _, _ ->
                        ThemeStore.delete(this, c.clockId.substring(2))
                        ClockWidgetProvider.refresh(this)
                        showGallery()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
        return card
    }

    private fun importCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0, 26, Pal.uGold, 1, dashed = true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        card.addView(tv("＋", 30f, Pal.uGold, Typeface.create("sans-serif-thin", Typeface.NORMAL)))
        card.addView(spacer(8))
        card.addView(tv("IMPORT THEME", 12f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.18f))
        card.addView(spacer(4))
        card.addView(tv(".zip file", 11f, Pal.uMuted))
        card.minimumHeight = dp(190)
        card.setOnClickListener { pickFile() }
        card.pressFeedback(0.965f)
        return card
    }

    private fun openTelegram() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)))
        } catch (e: Exception) {
            toast("Could not open Telegram")
        }
    }

    private fun showJoinDialog() {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(26), dp(24), dp(22))
        }
        box.addView(label("Community"))
        box.addView(spacer(8))
        box.addView(serif("Join Ranweir's Inventory", 24f))
        box.addView(spacer(10))
        box.addView(tv("New clock styles, themes and updates are shared on Telegram. Join the channel to stay in the loop.", 13.5f, Pal.uMuted))
        box.addView(spacer(22))
        val row = LinearLayout(this)
        row.addView(pill("Close", false) { d.dismiss() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(10) })
        row.addView(pill("Telegram", true) {
            openTelegram()
            d.dismiss()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        d.setContentView(box)
        // Liquid glass: Android 12+ par asli backdrop blur, purane par zyada opaque glass
        var blur = false
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            blur = try { windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
        }
        val glass = GlassPanelDrawable(dp(30).toFloat(), Pal.dark, blur, dp(1).toFloat() * 1.5f, Pal.RED)
        d.window?.setBackgroundDrawable(glass)
        d.window?.setDimAmount(if (blur) 0.30f else 0.50f)
        d.setOnDismissListener { glass.stopShimmer() }
        d.show()
        if (blur && android.os.Build.VERSION.SDK_INT >= 31) {
            d.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            d.window?.attributes = d.window?.attributes?.apply { blurBehindRadius = dp(34) }
            d.window?.setBackgroundBlurRadius(dp(120))
        }
        // premium entrance: halka zoom + fade, phir shimmer
        d.window?.decorView?.apply {
            scaleX = 0.92f; scaleY = 0.92f; alpha = 0f
            animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(380)
                .setInterpolator(android.view.animation.OvershootInterpolator(0.9f)).start()
        }
        glass.startShimmer()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }


    private fun showHelp() {
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("How to use")
            .setMessage(
                "ADD A CLOCK\n" +
                    "1. Pick a clock and customise it.\n" +
                    "2. Tap “Add to home screen” (or long-press your home screen › Widgets › Aurum Clock).\n" +
                    "3. Resize the widget by long-pressing it — the clock scales automatically.\n" +
                    "4. Tap a widget any time to edit it.\n\n" +
                    "IMPORT A XIAOMI CLOCK THEME\n" +
                    "1. Download a clock theme as a .zip or .mtz file (from the Xiaomi Themes app, a theme site or a Telegram channel). If it came as a folder, zip it so manifest.xml is inside.\n" +
                    "2. In Aurum open the Imported tab (middle icon in the bottom bar) and tap “＋” (top right) or “IMPORT THEME”.\n" +
                    "3. Choose the downloaded file. When it says “Theme imported”, the clock appears in the Imported tab.\n" +
                    "4. Tap it to customise, then “Add to home screen”. Long-press a theme to delete it.\n" +
                    "Note: buttons, animations, music controls and Xiaomi weather inside a theme are not supported (weather shows --°).\n\n" +
                    "FLOATING BAR\n" +
                    "Tap an icon, or press and slide your finger along the bar, to switch between Built-in, Imported and Settings. You can also swipe the page left / right.\n\n" +
                    "APP THEME\n" +
                    "Settings › Appearance: System (follows your phone), Dark or Light.\n\n" +
                    "Tip (ColorOS): Settings › Battery › Aurum Clock › Unrestricted, and allow auto-launch, so the time keeps updating.\n\nMade by Ranweir · t.me/ranweirsinventory"
            )
            .setPositiveButton("Got it", null)
            .show()
    }

    // ───────────────────────── Active widgets ─────────────────────────

    private fun showActive() {
        screen = Screen.ACTIVE
        val (sv, col) = page()
        col.addView(topBar("Active widgets") { showGallery() })
        col.addView(spacer(20))
        val mgr = AppWidgetManager.getInstance(this)
        val ids = ClockWidgetProvider.ids(this)
        if (ids.isEmpty()) {
            col.addView(tv("No widgets on your home screen yet.\nPick a clock and tap “Add to home screen”.", 14f, Pal.uMuted))
        }
        for (id in ids) {
            val cfg = Prefs.widget(this, id) ?: Prefs.draft(this)
            val (w, h) = ClockWidgetProvider.sizeFor(this, mgr, id)
            val pw = 480
            val ph = (pw.toFloat() * h / w).toInt().coerceIn(160, 480)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Pal.uSurface, 24, Pal.uStroke, 1)
                setPadding(dp(12), dp(12), dp(16), dp(12))
            }
            val iv = ImageView(this).apply {
                background = previewBackdrop(16)
                clipToOutline = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            Previews.load(this, iv, cfg, pw, ph)
            row.addView(iv, LinearLayout.LayoutParams(dp(150), dp(90)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(tv(ClockEngine.nameOf(this, cfg.clockId), 15f, Pal.uText, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
            info.addView(spacer(4))
            info.addView(tv("Size ${cfg.scale}%  ·  Tap to edit", 12f, Pal.uMuted))
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
            row.addView(tv("›", 24f, Pal.uGold))
            row.setOnClickListener { showEditor(cfg.clockId, id) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            col.addView(row, lp)
        }
        show(sv)
    }

    // ───────────────────────── Editor ─────────────────────────

    private fun topBar(title: String, onBack: () -> Unit): View {
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(circleButton("‹") { onBack() })
        bar.addView(serif(title, 24f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(14) })
        return bar
    }

    private fun showEditor(clockId: String, boundId: Int?) {
        val sameEditor = screen == Screen.EDITOR && editorClockId == clockId && editorBoundId == boundId
        if (!sameEditor) editorTab = 0          // naya editor = pehla page; rebuild (wallpaper etc.) = wahi page
        screen = Screen.EDITOR
        editorBoundId = boundId
        editorClockId = clockId
        val isTheme = clockId.startsWith("t:")
        var cfg = (if (boundId != null) Prefs.widget(this, boundId) ?: Prefs.draft(this) else Prefs.draft(this))
            .copy(clockId = clockId)

        val mgr = AppWidgetManager.getInstance(this)
        val (ww, wh) = if (boundId != null) ClockWidgetProvider.sizeFor(this, mgr, boundId) else Pair(960, 480)
        val pw = 900
        val ph = (pw.toFloat() * wh / ww).toInt().coerceIn(300, 900)

        val (svA, colA) = editorPage()      // Clock: size, accent, time format
        val (svB, colB) = editorPage()      // Style: effects + glass style
        val (svC, colC) = editorPage()      // Details: date + colon
        var col = colA

        // Upar fixed: back + naam + Done/Add, aur live preview (har page par dikhta hai)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(8))
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(circleButton("‹") { if (boundId != null) showActive() else showGallery() })
        topRow.addView(serif(ClockEngine.nameOf(this, clockId), 22f).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14); rightMargin = dp(10) })
        val actionChip = kchip(if (boundId != null) "DONE" else "ADD")
        kstyle(actionChip, true)
        actionChip.setOnClickListener { if (boundId != null) showActive() else pin() }
        topRow.addView(actionChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(topRow)
        header.addView(spacer(14))

        val preview = ImageView(this).apply {
            background = previewBackdrop(28)
            clipToOutline = true
            elevation = dp(8).toFloat()
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        header.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        fun commit() {
            Previews.live(this, preview, cfg, pw, ph) { c ->
                if (boundId != null) {
                    Prefs.setWidget(this, boundId, c)
                    ClockWidgetProvider.refreshOne(this, mgr, boundId)
                } else {
                    Prefs.setDraft(this, c)
                }
            }
        }

        // Size
        col = kitCard(colA)
        val sizeHead = LinearLayout(this)
        sizeHead.addView(sec("Size"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sizeVal = kval("${cfg.scale}%")
        sizeHead.addView(sizeVal.apply { visibility = View.GONE })
        col.addView(sizeHead)
        col.addView(spacer(8))
        val seek = GlowSeekBar(this).apply {
            valueMin = 30
            kit()
            max = 70                // 30% .. 100%
            progress = (cfg.scale - 30).coerceIn(0, 70)
                                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(scale = p + 30)
                    sizeVal.text = "${cfg.scale}%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(seek)
        col.addView(tv("100% fills the widget. To make the clock bigger, resize the widget on your home screen (long-press the widget).", 11f, Pal.uMuted))

        // Effects
        col = kitCard(colB)
        col.addView(sec("Effects"))
        col.addView(spacer(12))
        val fluxChip = kchip("FLUX GLOW · COLOROS 17")
        fun restyleFlux() = kstyle(fluxChip, cfg.flux)
        fluxChip.setOnClickListener { cfg = cfg.copy(flux = !cfg.flux); restyleFlux(); commit() }
        restyleFlux()
        col.addView(fluxChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(spacer(6))
        col.addView(tv("Edge-lit translucent glass in your wallpaper colours with a soft halo, like ColorOS 17. Font and shape stay untouched. The glow slider sets its intensity; it replaces the glass style below.", 11f, Pal.uMuted))
        ksliderRow(col, "Flux glass transparency", cfg.clear) { cfg = cfg.copy(clear = it); commit() }
        col = kitCard(colB)
        val styleCard = col
        col.addView(sec("Glass style"))
        col.addView(spacer(6))
        val activeLine = tv("", 12f, Pal.uGold, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        col.addView(activeLine)
        col.addView(spacer(12))

        // id -> chip: 0 Frosted, 1 Liquid, 2 Blur, 3 Gradient, 5 Glow, 4 Solid
        val styleIds = listOf(0, 1, 2, 3, 5, 4)
        val styleNames = mapOf(0 to "FROSTED", 1 to "LIQUID", 2 to "BLUR", 3 to "GRADIENT", 5 to "GLOW", 4 to "SOLID")
        val styleHints = mapOf(
            0 to "Frosted: milky translucent glass with a bright rim.",
            1 to "Liquid: very clear glass with inner depth, a glowing bottom edge and a bright rim, like iOS 26.",
            2 to "Blur: the digits show your blurred wallpaper (home wallpaper or a chosen image). Without a wallpaper it uses a soft tinted blur.",
            3 to "Gradient: colours blend across the digits. Pick start and end colours, direction and spread.",
            5 to "Glow: a neon halo around the digits, a bright hot core and light on the edges. Lower the Size slider if the halo looks cut off.",
            4 to "Solid: flat colour with optional opacity, shadow and outline."
        )
        val styleChips = HashMap<Int, TextView>()
        for (id in styleIds) styleChips[id] = kchip(styleNames[id]!!)
        val styleHint = tv("", 11f, Pal.uMuted)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ── Inner glow (common) — Glow style ka apna intensity slider hai, isliye wahan chhupa rehta hai ──
        val innerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun saveNow() {
            if (boundId != null) Prefs.setWidget(this, boundId, cfg) else Prefs.setDraft(this, cfg)
        }

        fun colorRow(target: LinearLayout, title: String, current: Int, onPick: (Int) -> Unit) {
            target.addView(spacer(16))
            target.addView(tv(title, 13f, Pal.uText))
            target.addView(spacer(10))
            val row = LinearLayout(this)
            val dotsL = ArrayList<TextView>()
            var cur = current
            fun paint() {
                for ((i, d) in dotsL.withIndex()) {
                    val colr = Pal.glowColors[i]
                    val sel = colr == cur
                    d.background = rounded(if (colr == 0) Pal.uSurface2 else colr, 18, if (sel) Pal.uTitle else Pal.uStroke, if (sel) 2 else 1)
                }
            }
            for (colr in Pal.glowColors) {
                val d = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 13f
                    setTextColor(Pal.uText)
                    text = if (colr == 0) "A" else ""
                }
                dotsL.add(d)
                d.setOnClickListener { cur = colr; paint(); onPick(colr) }
                row.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
            }
            paint()
            target.addView(android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            })
        }

        fun styleSlider(target: LinearLayout, title: String, cur: Int, def: Int, set: (Int) -> Unit) {
            ksliderRow(target, title, Effects.pv(cur, def)) { set(it); commit() }
        }

        // ── Blur style: wallpaper + sliders ──
        fun backdropUi(target: LinearLayout) {
            val auto = WallStore.autoOn(this)
            val hasWall = WallStore.usable(this)
            target.addView(spacer(8))
            target.addView(tv(
                if (hasWall) "Wallpaper connected ✓  Your blurred wallpaper shows through the digits."
                else "No wallpaper yet. Tap USE HOME WALLPAPER and allow the permission, or choose an image. Without either, a soft tinted blur is used.",
                11f, if (hasWall) Pal.uGold else Pal.uMuted
            ))
            target.addView(spacer(12))
            val autoChip = kchip(if (auto) "HOME WALLPAPER  ·  ON" else "USE HOME WALLPAPER")
            kstyle(autoChip, auto)
            autoChip.setOnClickListener {
                saveNow()
                if (WallStore.autoOn(this)) {
                    WallStore.setAuto(this, false)
                    ClockWidgetProvider.refresh(this)
                    showEditor(clockId, boundId)
                } else if (!hasWallPermission()) {
                    pendingAuto = true
                    requestWallPermission()
                } else tryEnableAuto()
            }
            target.addView(autoChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            target.addView(spacer(10))
            val wallRow = LinearLayout(this)
            wallRow.addView(kchip(if (WallStore.has(this)) "CHANGE IMAGE" else "CHOOSE IMAGE").also { c ->
                kstyle(c, false)
                c.setOnClickListener { saveNow(); pickWallpaper() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            if (WallStore.has(this)) {
                wallRow.addView(kchip("REMOVE").also { c ->
                    kstyle(c, false)
                    c.setOnClickListener {
                        saveNow()
                        WallStore.clear(this)
                        showEditor(clockId, boundId)
                    }
                })
            }
            target.addView(wallRow)
            if (hasWall) {
                target.addView(spacer(14))
                val useChip = kchip("")
                fun restyleUse() {
                    val on = Effects.pv(cfg.s3, 1) == 1
                    useChip.text = if (on) "USE WALLPAPER  ·  ON" else "USE WALLPAPER  ·  OFF"
                    kstyle(useChip, on)
                }
                useChip.setOnClickListener {
                    cfg = cfg.copy(s3 = if (Effects.pv(cfg.s3, 1) == 1) 0 else 1)
                    restyleUse(); commit()
                }
                restyleUse()
                target.addView(useChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            ksliderRow(target, "Blur amount", cfg.blur) { cfg = cfg.copy(blur = it); commit() }
            ksliderRow(target, "Brightness", cfg.bgGlow) { cfg = cfg.copy(bgGlow = it); commit() }
            ksliderRow(target, "Transparency", cfg.clear) { cfg = cfg.copy(clear = it); commit() }
            if (hasWall) {
                ksliderRow(target, "Wallpaper position · top to bottom", cfg.wallY) { cfg = cfg.copy(wallY = it); commit() }
                ksliderRow(target, "Wallpaper position · left to right", cfg.wallX) { cfg = cfg.copy(wallX = it); commit() }
            }
        }

        fun buildPanel() {
            panel.removeAllViews()
            innerBox.visibility = if (cfg.style == 5 || cfg.style == 2) View.GONE else View.VISIBLE
            when (cfg.style) {
                0 -> {
                    styleSlider(panel, "Frost opacity", cfg.s1, 62) { cfg = cfg.copy(s1 = it) }
                    styleSlider(panel, "Shine", cfg.s2, 60) { cfg = cfg.copy(s2 = it) }
                    styleSlider(panel, "Rim light", cfg.s3, 70) { cfg = cfg.copy(s3 = it) }
                    colorRow(panel, "Tint colour  (A = the clock's own colours)", cfg.sc1) { cfg = cfg.copy(sc1 = it); commit() }
                }
                1 -> {
                    styleSlider(panel, "Clarity", cfg.s1, 72) { cfg = cfg.copy(s1 = it) }
                    styleSlider(panel, "Depth", cfg.s2, 60) { cfg = cfg.copy(s2 = it) }
                    styleSlider(panel, "Edge light", cfg.s3, 75) { cfg = cfg.copy(s3 = it) }
                    colorRow(panel, "Tint colour  (A = clear glass)", cfg.sc1) { cfg = cfg.copy(sc1 = it); commit() }
                }
                2 -> backdropUi(panel)
                3 -> {
                    colorRow(panel, "Start colour  (A = your accent)", cfg.sc1) { cfg = cfg.copy(sc1 = it); commit() }
                    colorRow(panel, "End colour  (A = glow colour or shifted accent)", cfg.sc2) { cfg = cfg.copy(sc2 = it); commit() }
                    styleSlider(panel, "Direction", cfg.s1, 25) { cfg = cfg.copy(s1 = it) }
                    styleSlider(panel, "Spread", cfg.s2, 50) { cfg = cfg.copy(s2 = it) }
                    styleSlider(panel, "Shine", cfg.s3, 0) { cfg = cfg.copy(s3 = it) }
                }
                5 -> {
                    ksliderRow(panel, "Glow intensity", cfg.glow) { cfg = cfg.copy(glow = it); commit() }
                    styleSlider(panel, "Glow size", cfg.s1, 60) { cfg = cfg.copy(s1 = it) }
                    styleSlider(panel, "Halo strength", cfg.s3, 75) { cfg = cfg.copy(s3 = it) }
                    styleSlider(panel, "Core brightness", cfg.s2, 55) { cfg = cfg.copy(s2 = it) }
                    colorRow(panel, "Glow colour  (A = the clock's own colour)", cfg.glowColor) { cfg = cfg.copy(glowColor = it); commit() }
                }
                4 -> {
                    colorRow(panel, "Colour  (A = the clock's own colours)", cfg.sc1) { cfg = cfg.copy(sc1 = it); commit() }
                    styleSlider(panel, "Opacity", cfg.s1, 100) { cfg = cfg.copy(s1 = it) }
                    styleSlider(panel, "Shadow", cfg.s2, 0) { cfg = cfg.copy(s2 = it) }
                    styleSlider(panel, "Outline", cfg.s3, 0) { cfg = cfg.copy(s3 = it) }
                    colorRow(panel, "Outline colour  (A = black)", cfg.sc2) { cfg = cfg.copy(sc2 = it); commit() }
                }
            }
        }

        fun restyleStyles() {
            for (id in styleIds) kstyle(styleChips[id]!!, cfg.style == id)
            styleHint.text = styleHints[cfg.style] ?: ""
            activeLine.text = if (cfg.flux) "Flux Glow is ON — it replaces the glass style" else "Active: ${styleNames[cfg.style]?.lowercase()?.replaceFirstChar { it.uppercase() }}  ✓"
        }

        for (id in styleIds) {
            styleChips[id]!!.setOnClickListener {
                var n = cfg.copy(style = id, glass = id != 4, flux = false, blur = if (id == 2) (if (cfg.blur == 0) 60 else cfg.blur) else 0)
                if (id == 5) n = n.copy(glow = maxOf(n.glow, 70), scale = minOf(n.scale, 85))
                cfg = n
                restyleStyles(); restyleFlux(); buildPanel(); commit()
                // chhota "pop" taaki dikhe ki change lag gaya
                preview.animate().cancel()
                preview.scaleX = 0.97f; preview.scaleY = 0.97f
                preview.animate().scaleX(1f).scaleY(1f).setDuration(320)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
            }
        }

        val rowA = LinearLayout(this)
        val rowB = LinearLayout(this)
        styleIds.forEachIndexed { i, id ->
            (if (i < 3) rowA else rowB).addView(styleChips[id]!!, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
        }
        col.addView(rowA)
        col.addView(spacer(10))
        col.addView(rowB)
        col.addView(spacer(10))
        col.addView(styleHint)
        col.addView(panel)
        col.addView(innerBox)

        // Inner glow slider + colour (Frosted / Liquid / Gradient / Solid)
        col = innerBox
        col.addView(spacer(18))
        val glowHead = LinearLayout(this)
        glowHead.addView(tv("Inner glow", 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val glowVal = kval("${cfg.glow}%")
        glowHead.addView(glowVal.apply { visibility = View.GONE })
        col.addView(glowHead)
        col.addView(spacer(8))
        col.addView(GlowSeekBar(this).apply {
            kit()
            max = 100
            progress = cfg.glow
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(glow = p)
                    glowVal.text = "$p%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        colorRow(col, "Inner glow colour  (A = keep the clock's own colours)", cfg.glowColor) { cfg = cfg.copy(glowColor = it); commit() }
        col = styleCard
        restyleStyles()
        buildPanel()

        // Date controls
        val hasDate = clockId != "b:analog"
        if (hasDate) {
            col = kitCard(colC)
            col.addView(sec("Date"))
            col.addView(spacer(12))
            val dateChip = kchip("SHOW DATE")
            fun restyleDate() = kstyle(dateChip, cfg.showDate)
            dateChip.setOnClickListener { cfg = cfg.copy(showDate = !cfg.showDate); restyleDate(); commit() }
            restyleDate()
            col.addView(dateChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            ksliderRow(col, "Date glow", if (cfg.dateGlow >= 0) cfg.dateGlow else cfg.glow) { cfg = cfg.copy(dateGlow = it); commit() }
            ksliderRow(col, "Date transparency (Flux)", if (cfg.dateClear >= 0) cfg.dateClear else cfg.clear) { cfg = cfg.copy(dateClear = it); commit() }
        }

        // Colon controls
        val supportsColon = isTheme || Builtins.hasColon(clockId)
        if (supportsColon) {
            col = kitCard(colC)
            col.addView(sec("Colon  :"))
            col.addView(spacer(12))
            val colonChip = kchip("SHOW COLON")
            fun restyleColon() = kstyle(colonChip, cfg.colon)
            colonChip.setOnClickListener { cfg = cfg.copy(colon = !cfg.colon); restyleColon(); commit() }
            restyleColon()
            col.addView(colonChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            ksliderRow(col, "Colon glow", if (cfg.colGlow >= 0) cfg.colGlow else cfg.glow) { cfg = cfg.copy(colGlow = it); commit() }
            ksliderRow(col, "Colon transparency (Flux)", if (cfg.colClear >= 0) cfg.colClear else cfg.clear) { cfg = cfg.copy(colClear = it); commit() }
        }

        if (!isTheme) {
            // Accent
            col = kitCard(colA)
            col.addView(sec("Accent colour"))
            col.addView(spacer(12))
            val sw = LinearLayout(this)
            val dots = ArrayList<View>()
            fun restyle() {
                for ((i, d) in dots.withIndex()) {
                    val sel = Pal.accents[i] == cfg.accent
                    d.background = rounded(Pal.accents[i], 18, if (sel) Pal.uTitle else Pal.uStroke, if (sel) 2 else 1)
                }
            }
            for (colr in Pal.accents) {
                val d = View(this)
                dots.add(d)
                d.setOnClickListener { cfg = cfg.copy(accent = colr); restyle(); commit() }
                sw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
            }
            restyle()
            col.addView(android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(sw)
            })

            // 12 / 24h
            col.addView(spacer(22))
            col.addView(sec("Time format"))
            col.addView(spacer(12))
            val chips = LinearLayout(this)
            val chip24 = kchip("24 HOUR")
            val chip12 = kchip("12 HOUR")
            fun restyleChips() {
                kstyle(chip24, !cfg.use12h)
                kstyle(chip12, cfg.use12h)
            }
            chip24.setOnClickListener { cfg = cfg.copy(use12h = false); restyleChips(); commit() }
            chip12.setOnClickListener { cfg = cfg.copy(use12h = true); restyleChips(); commit() }
            restyleChips()
            chips.addView(chip24, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            chips.addView(chip12)
            col.addView(chips)
        } else {
            colA.addView(spacer(20))
            colA.addView(tv("Colours and fonts come from the imported theme.", 12f, Pal.uMuted))
        }

        // pages + liquid bar
        val tabK = ArrayList<Int>(); val tabN = ArrayList<String>(); val tabV = ArrayList<View>()
        tabK.add(10); tabN.add("Clock"); tabV.add(svA)
        tabK.add(11); tabN.add("Style"); tabV.add(svB)
        if (colC.childCount > 0) { tabK.add(12); tabN.add("Details"); tabV.add(svC) }
        edPages = tabV
        if (editorTab !in tabV.indices) editorTab = 0

        val root = FrameLayout(this).apply { setBackgroundColor(Pal.uBg) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val pg = SwipeFrame(this) { dir -> setEditorTab((editorTab + dir).coerceIn(0, edPages.size - 1), dir) }
        edPager = pg
        pg.addView(tabV[editorTab], FrameLayout.LayoutParams(-1, -1))
        content.addView(pg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        val bar = GlassBar(this).apply {
            onSelect = { i -> setEditorTab(i, if (i > editorTab) 1 else -1, fromBar = true) }
        }
        barView = bar
        barKinds = tabK.toIntArray()
        barNames = tabN
        barSelected = { editorTab }
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        bar.bindSource(pg)
        styleBar()
        show(root)
        commit()
    }

    private fun sliderRow(col: LinearLayout, title: String, value: Int, onChange: (Int) -> Unit) {
        val head = LinearLayout(this)
        head.addView(tv(title, 13f, Pal.uText), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = tv("$value%", 13f, Pal.uText)
        head.addView(v.apply { visibility = View.GONE })
        col.addView(spacer(16))
        col.addView(head)
        col.addView(spacer(8))
        col.addView(GlowSeekBar(this).apply {
            max = 100
            progress = value
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    v.text = "$p%"
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }


    private fun chip(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.16f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(18), dp(10), dp(18), dp(10))
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        t.setTextColor(if (selected) Pal.uOnGold else Pal.uText)
        t.background = if (selected) rounded(Pal.uGold, 20) else rounded(Pal.uSurface2, 20, Pal.uStroke, 1)
    }

    private fun pin() {
        val mgr = getSystemService(AppWidgetManager::class.java)
        if (mgr != null && mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
            toast("Confirm the widget on your home screen")
        } else {
            toast("Long-press your home screen › Widgets › Aurum Clock")
        }
    }

    // ───────────────────────── Import ─────────────────────────

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            // kuch phones par Documents picker nahi hota -> simple picker try karo
            try {
                val g = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(g, "Choose theme zip"), REQ_PICK)
            } catch (e2: Exception) {
                toast("No file picker found on this phone")
            }
        }
    }

    // ───────────── Home wallpaper permission ─────────────

    private var pendingAuto = false

    private fun hasWallPermission(): Boolean {
        val perm = if (android.os.Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_IMAGES
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun requestWallPermission() {
        val perm = if (android.os.Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_IMAGES
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(arrayOf(perm), REQ_PERM)
    }

    /** Auto wallpaper on karke test karta hai; na padh paye to image chunne ko kehta hai. */
    private fun tryEnableAuto() {
        WallStore.setAuto(this, true)
        Thread {
            val ok = WallStore.system(this, force = true) != null
            runOnUiThread {
                if (ok) {
                    pendingAuto = false
                    ClockWidgetProvider.refresh(this)
                    toast("Home wallpaper connected")
                    showEditor(editorClockId, editorBoundId)
                } else {
                    pendingAuto = false
                    WallStore.setAuto(this, false)
                    toast("Could not read the wallpaper (live wallpaper?). Choose an image instead.")
                    showEditor(editorClockId, editorBoundId)
                }
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return
        if (grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) tryEnableAuto()
        else { pendingAuto = false; toast("Permission denied. You can still choose an image yourself.") }
    }

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_WALL)
        } catch (e: Exception) {
            toast("No file picker found on this phone")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "theme"
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "theme"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == REQ_WALL) {
            val u = data?.data ?: return
            Thread {
                val r = runCatching { WallStore.save(this, u) }
                runOnUiThread {
                    if (r.isSuccess) {
                        showEditor(editorClockId, editorBoundId)
                    } else {
                        toast("Could not use this image: ${r.exceptionOrNull()?.message}")
                    }
                }
            }.start()
            return
        }
        if (requestCode != REQ_PICK) return
        val uri = data?.data ?: return
        val name = displayName(uri)
        toast("Importing…")
        Thread {
            galleryTab = 1
            val r = runCatching { ThemeStore.import(this, uri, name) }
            runOnUiThread {
                if (r.isSuccess) {
                    toast("Theme imported")
                    showGallery()
                } else {
                    toast("Import failed: ${r.exceptionOrNull()?.message}")
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.GALLERY -> super.onBackPressed()
            Screen.ACTIVE -> showGallery()
            Screen.EDITOR -> if (editorBoundId != null) showActive() else showGallery()
        }
    }

    companion object {
        const val EXTRA_WIDGET_ID = "widget_id"
        private const val TELEGRAM_URL = "https://t.me/ranweirsinventory"
        private const val REQ_PICK = 1
        private const val REQ_WALL = 2
        private const val REQ_PERM = 3
    }
}
