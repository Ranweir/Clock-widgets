package com.example.clockwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "Clock Widget"
            textSize = 24f
        })

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        col.addView(status)

        preview = ImageView(this).apply {
            setBackgroundColor(Color.parseColor("#FF222222"))
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(button("Theme import karo (.zip)") { pickFile() })
        col.addView(button("Widget home screen par lagao") { pinWidget() })
        col.addView(button("Refresh") {
            refreshPreview()
            ClockWidgetProvider.refresh(this)
        })

        col.addView(TextView(this).apply {
            textSize = 13f
            setPadding(0, pad, 0, 0)
            text = "Tip (ColorOS): Settings > Battery > Clock Widget ko 'Unrestricted' karo aur Auto-launch ON rakho, " +
                "warna widget minute par update hona band ho sakta hai."
        })

        setContentView(ScrollView(this).apply { addView(col) })
        refreshPreview()
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        status.text = "Import ho raha hai..."
        Thread {
            val r = runCatching { ThemeStore.import(this, uri) }
            runOnUiThread {
                if (r.isSuccess) {
                    Toast.makeText(this, "Theme import ho gayi", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
                refreshPreview()
                ClockWidgetProvider.refresh(this)
            }
        }.start()
    }

    private fun refreshPreview() {
        val root = ThemeStore.root(this)
        if (root == null) {
            status.text = "Abhi koi theme nahi hai. Neeche se clock_3x4 file import karo."
            preview.setImageDrawable(null)
            return
        }
        val bmp = ClockRenderer.render(root, 540)
        if (bmp == null) {
            status.text = "Theme padh nahi paye (manifest.xml kharab?)"
            preview.setImageDrawable(null)
        } else {
            status.text = "Theme loaded. Preview:"
            preview.setImageBitmap(bmp)
        }
    }

    private fun pinWidget() {
        val mgr = getSystemService(AppWidgetManager::class.java)
        if (mgr != null && mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(this, "Home screen par long-press > Widgets > Clock Widget", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val REQ_PICK = 1
    }
}
