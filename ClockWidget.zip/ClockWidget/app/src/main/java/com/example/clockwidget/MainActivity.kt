package com.example.clockwidget

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private enum class Screen { GALLERY, EDITOR, ACTIVE }

    private lateinit var host: FrameLayout
    private var screen = Screen.GALLERY
    private var editorBoundId: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG
        host = FrameLayout(this).apply { setBackgroundColor(Pal.BG) }
        setContentView(host)

        val wid = intent?.getIntExtra(EXTRA_WIDGET_ID, -1) ?: -1
        if (wid != -1) {
            val cfg = Prefs.widget(this, wid)
            if (cfg != null) {
                showEditor(cfg.clockId, wid)
                return
            }
        }
        showGallery()
    }

    private fun show(content: View) {
        host.removeAllViews()
        host.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun page(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Pal.BG)
            addView(col)
        }
        return Pair(sv, col)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ───────────────────────── Gallery ─────────────────────────

    private fun showGallery() {
        screen = Screen.GALLERY
        val (sv, col) = page()

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.TOP }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("Aurum"))
        left.addView(spacer(6))
        left.addView(serif("Clock Atelier", 32f))
        left.addView(spacer(12))
        val active = ClockWidgetProvider.ids(this).size
        left.addView(TextView(this).apply {
            text = "$active ACTIVE  ›"
            textSize = 12f
            letterSpacing = 0.16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Pal.GOLD)
            background = rounded(0, 20, Pal.GOLD, 1)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showActive() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(circleButton("＋") { pickFile() })
        header.addView(spacer(0).apply { layoutParams = LinearLayout.LayoutParams(dp(10), 1) })
        header.addView(circleButton("?") { showHelp() })
        col.addView(header)
        col.addView(spacer(28))

        // Built-in
        col.addView(label("Built-in collection"))
        col.addView(spacer(12))
        addGrid(col, Builtins.list.map { Card("Cfg", it.id, it.name, it.kind, false) })

        // Imported
        col.addView(spacer(28))
        col.addView(label("Xiaomi themes"))
        col.addView(spacer(12))
        val themes = ThemeStore.list(this)
            .sortedByDescending { ThemeStore.isBundled(it.id) }
            .map {
                val b = ThemeStore.isBundled(it.id)
                Card("T", "t:${it.id}", it.name, if (b) "Xiaomi · built-in" else "Imported · hold to delete", !b)
            }
        addGrid(col, themes, withImport = true)

        col.addView(spacer(24))
        col.addView(tv(
            "Works with Xiaomi / MIUI / HyperOS clock themes (.zip with manifest.xml). Import as many as you like.",
            12f, Pal.MUTED
        ))
        show(sv)
    }

    private class Card(val kind: String, val clockId: String, val name: String, val caption: String, val isTheme: Boolean)

    private fun addGrid(col: LinearLayout, cards: List<Card>, withImport: Boolean = false) {
        val views = ArrayList<View>()
        for (c in cards) views.add(clockCard(c))
        if (withImport) views.add(importCard())
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(this)
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(if (j == 0) 0 else dp(6), dp(6), if (j == 0) dp(6) else 0, dp(6))
                if (i + j < views.size) row.addView(views[i + j], lp)
                else row.addView(View(this), lp)
            }
            col.addView(row)
            i += 2
        }
    }

    private fun clockCard(c: Card): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Pal.SURFACE, 26, Pal.STROKE, 1)
            setPadding(dp(10), dp(10), dp(10), dp(14))
        }
        val iv = ImageView(this).apply {
            background = previewBackdrop(18)
            clipToOutline = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setImageBitmap(ClockEngine.render(this@MainActivity, Cfg(c.clockId), 480, 360))
        }
        card.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(124)))
        card.addView(spacer(10))
        card.addView(tv(c.name, 14f, Pal.CHAMPAGNE, Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply {
            setPadding(dp(4), 0, dp(4), 0)
            maxLines = 1
        })
        card.addView(spacer(3))
        card.addView(tv(c.caption, 11f, Pal.MUTED).apply { setPadding(dp(4), 0, dp(4), 0) })
        card.setOnClickListener { showEditor(c.clockId, null) }
        if (c.isTheme) {
            card.setOnLongClickListener {
                AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Delete theme?")
                    .setMessage("“${c.name}” will be removed. Widgets using it will fall back to a built-in clock.")
                    .setPositiveButton("Delete") { _, _ ->
                        ThemeStore.delete(this, c.clockId.substring(2))
                        ClockWidgetProvider.refresh(this)
                        showGallery()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
        return card
    }

    private fun importCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0, 26, Pal.GOLD, 1, dashed = true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        card.addView(tv("＋", 30f, Pal.GOLD, Typeface.create("sans-serif-thin", Typeface.NORMAL)))
        card.addView(spacer(8))
        card.addView(tv("IMPORT THEME", 12f, Pal.GOLD, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.18f))
        card.addView(spacer(4))
        card.addView(tv(".zip file", 11f, Pal.MUTED))
        card.minimumHeight = dp(190)
        card.setOnClickListener { pickFile() }
        return card
    }

    private fun showHelp() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("How it works")
            .setMessage(
                "1. Pick a clock and customise it.\n" +
                    "2. Tap “Add to home screen” (or long-press your home screen › Widgets › Aurum Clock).\n" +
                    "3. Resize the widget by long-pressing it — the clock scales automatically.\n" +
                    "4. Tap a widget any time to edit it.\n\n" +
                    "Tip (ColorOS): Settings › Battery › Aurum Clock › Unrestricted, and allow auto-launch, so the time keeps updating."
            )
            .setPositiveButton("Got it", null)
            .show()
    }

    // ───────────────────────── Active widgets ─────────────────────────

    private fun showActive() {
        screen = Screen.ACTIVE
        val (sv, col) = page()
        col.addView(topBar("Active widgets") { showGallery() })
        col.addView(spacer(20))
        val mgr = AppWidgetManager.getInstance(this)
        val ids = ClockWidgetProvider.ids(this)
        if (ids.isEmpty()) {
            col.addView(tv("No widgets on your home screen yet.\nPick a clock and tap “Add to home screen”.", 14f, Pal.MUTED))
        }
        for (id in ids) {
            val cfg = Prefs.widget(this, id) ?: Prefs.draft(this)
            val (w, h) = ClockWidgetProvider.sizeFor(this, mgr, id)
            val pw = 480
            val ph = (pw.toFloat() * h / w).toInt().coerceIn(160, 480)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Pal.SURFACE, 24, Pal.STROKE, 1)
                setPadding(dp(12), dp(12), dp(16), dp(12))
            }
            val iv = ImageView(this).apply {
                background = previewBackdrop(16)
                clipToOutline = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(ClockEngine.render(this@MainActivity, cfg, pw, ph))
            }
            row.addView(iv, LinearLayout.LayoutParams(dp(150), dp(90)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(tv(ClockEngine.nameOf(this, cfg.clockId), 15f, Pal.CHAMPAGNE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
            info.addView(spacer(4))
            info.addView(tv("Size ${cfg.scale}%  ·  Tap to edit", 12f, Pal.MUTED))
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
            row.addView(tv("›", 24f, Pal.GOLD))
            row.setOnClickListener { showEditor(cfg.clockId, id) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            col.addView(row, lp)
        }
        show(sv)
    }

    // ───────────────────────── Editor ─────────────────────────

    private fun topBar(title: String, onBack: () -> Unit): View {
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(circleButton("‹") { onBack() })
        bar.addView(serif(title, 24f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(14) })
        return bar
    }

    private fun showEditor(clockId: String, boundId: Int?) {
        screen = Screen.EDITOR
        editorBoundId = boundId
        val isTheme = clockId.startsWith("t:")
        var cfg = (if (boundId != null) Prefs.widget(this, boundId) ?: Prefs.draft(this) else Prefs.draft(this))
            .copy(clockId = clockId)

        val mgr = AppWidgetManager.getInstance(this)
        val (ww, wh) = if (boundId != null) ClockWidgetProvider.sizeFor(this, mgr, boundId) else Pair(960, 480)
        val pw = 900
        val ph = (pw.toFloat() * wh / ww).toInt().coerceIn(300, 900)

        val (sv, col) = page()
        col.addView(topBar(ClockEngine.nameOf(this, clockId)) {
            if (boundId != null) showActive() else showGallery()
        })
        col.addView(spacer(20))

        val preview = ImageView(this).apply {
            background = previewBackdrop(28)
            clipToOutline = true
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(tv(
            if (boundId != null) "Preview matches your widget's current shape" else "Preview · widget size follows how you resize it",
            11f, Pal.MUTED
        ).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun commit() {
            preview.setImageBitmap(ClockEngine.render(this, cfg, pw, ph))
            if (boundId != null) {
                Prefs.setWidget(this, boundId, cfg)
                ClockWidgetProvider.refreshOne(this, mgr, boundId)
            } else {
                Prefs.setDraft(this, cfg)
            }
        }

        // Size
        col.addView(spacer(24))
        val sizeHead = LinearLayout(this)
        sizeHead.addView(label("Size"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sizeVal = tv("${cfg.scale}%", 13f, Pal.CHAMPAGNE)
        sizeHead.addView(sizeVal)
        col.addView(sizeHead)
        col.addView(spacer(8))
        val seek = SeekBar(this).apply {
            max = 70                // 30% .. 100%
            progress = (cfg.scale - 30).coerceIn(0, 70)
            progressTintList = android.content.res.ColorStateList.valueOf(Pal.GOLD)
            thumbTintList = android.content.res.ColorStateList.valueOf(Pal.CHAMPAGNE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(scale = p + 30)
                    sizeVal.text = "${cfg.scale}%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(seek)
        col.addView(tv("100% fills the widget. To make the clock bigger, resize the widget on your home screen (long-press the widget).", 11f, Pal.MUTED))

        // Effects
        col.addView(spacer(24))
        col.addView(label("Effects"))
        col.addView(spacer(12))
        val fluxChip = chip("FLUX GLOW · COLOROS 17")
        fun restyleFlux() = styleChip(fluxChip, cfg.flux)
        fluxChip.setOnClickListener { cfg = cfg.copy(flux = !cfg.flux); restyleFlux(); commit() }
        restyleFlux()
        col.addView(fluxChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(spacer(6))
        col.addView(tv("Soft white-to-tint gradient fill with a wallpaper-coloured aura. Font and shape stay untouched. When ON it replaces Frosted glass and Glow below.", 11f, Pal.MUTED))
        col.addView(spacer(16))
        val glassChip = chip("FROSTED GLASS")
        fun restyleGlass() = styleChip(glassChip, cfg.glass)
        glassChip.setOnClickListener { cfg = cfg.copy(glass = !cfg.glass); restyleGlass(); commit() }
        restyleGlass()
        col.addView(glassChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(spacer(18))
        val glowHead = LinearLayout(this)
        glowHead.addView(tv("Inner glow", 13f, Pal.CHAMPAGNE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val glowVal = tv("${cfg.glow}%", 13f, Pal.CHAMPAGNE)
        glowHead.addView(glowVal)
        col.addView(glowHead)
        col.addView(spacer(8))
        col.addView(SeekBar(this).apply {
            max = 100
            progress = cfg.glow
            progressTintList = android.content.res.ColorStateList.valueOf(Pal.GOLD)
            thumbTintList = android.content.res.ColorStateList.valueOf(Pal.CHAMPAGNE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg = cfg.copy(glow = p)
                    glowVal.text = "$p%"
                    if (fromUser) commit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(spacer(16))
        col.addView(tv("Inner glow colour", 13f, Pal.CHAMPAGNE))
        col.addView(spacer(10))
        val gsw = LinearLayout(this)
        val gdots = ArrayList<View>()
        fun restyleGlow() {
            for ((i, d) in gdots.withIndex()) {
                val sel = Pal.glowColors[i] == cfg.glowColor
                d.background = rounded(Pal.glowColors[i], 18, if (sel) Pal.IVORY else Pal.STROKE, if (sel) 2 else 1)
            }
        }
        for (colr in Pal.glowColors) {
            val d = View(this)
            gdots.add(d)
            d.setOnClickListener { cfg = cfg.copy(glowColor = colr); restyleGlow(); commit() }
            gsw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
        restyleGlow()
        col.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(gsw)
        })

        if (!isTheme) {
            // Accent
            col.addView(spacer(24))
            col.addView(label("Accent colour"))
            col.addView(spacer(12))
            val sw = LinearLayout(this)
            val dots = ArrayList<View>()
            fun restyle() {
                for ((i, d) in dots.withIndex()) {
                    val sel = Pal.accents[i] == cfg.accent
                    d.background = rounded(Pal.accents[i], 18, if (sel) Pal.IVORY else Pal.STROKE, if (sel) 2 else 1)
                }
            }
            for (colr in Pal.accents) {
                val d = View(this)
                dots.add(d)
                d.setOnClickListener { cfg = cfg.copy(accent = colr); restyle(); commit() }
                sw.addView(d, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
            }
            restyle()
            col.addView(android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(sw)
            })

            // 12 / 24h
            col.addView(spacer(24))
            col.addView(label("Time format"))
            col.addView(spacer(12))
            val chips = LinearLayout(this)
            val chip24 = chip("24 HOUR")
            val chip12 = chip("12 HOUR")
            fun restyleChips() {
                styleChip(chip24, !cfg.use12h)
                styleChip(chip12, cfg.use12h)
            }
            chip24.setOnClickListener { cfg = cfg.copy(use12h = false); restyleChips(); commit() }
            chip12.setOnClickListener { cfg = cfg.copy(use12h = true); restyleChips(); commit() }
            restyleChips()
            chips.addView(chip24, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            chips.addView(chip12)
            col.addView(chips)
        } else {
            col.addView(spacer(20))
            col.addView(tv("Colours and fonts come from the imported theme.", 12f, Pal.MUTED))
        }

        col.addView(spacer(32))
        if (boundId != null) {
            col.addView(pill("Done", true) { showActive() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        } else {
            col.addView(pill("Add to home screen", true) { pin() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        show(sv)
        commit()
    }

    private fun chip(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.16f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(18), dp(10), dp(18), dp(10))
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        t.setTextColor(if (selected) Pal.BG else Pal.CHAMPAGNE)
        t.background = if (selected) rounded(Pal.GOLD, 20) else rounded(Pal.SURFACE2, 20, Pal.STROKE, 1)
    }

    private fun pin() {
        val mgr = getSystemService(AppWidgetManager::class.java)
        if (mgr != null && mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
            toast("Confirm the widget on your home screen")
        } else {
            toast("Long-press your home screen › Widgets › Aurum Clock")
        }
    }

    // ───────────────────────── Import ─────────────────────────

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            // kuch phones par Documents picker nahi hota -> simple picker try karo
            try {
                val g = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(g, "Choose theme zip"), REQ_PICK)
            } catch (e2: Exception) {
                toast("No file picker found on this phone")
            }
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "theme"
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "theme"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = displayName(uri)
        toast("Importing…")
        Thread {
            val r = runCatching { ThemeStore.import(this, uri, name) }
            runOnUiThread {
                if (r.isSuccess) {
                    toast("Theme imported")
                    showGallery()
                } else {
                    toast("Import failed: ${r.exceptionOrNull()?.message}")
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.GALLERY -> super.onBackPressed()
            Screen.ACTIVE -> showGallery()
            Screen.EDITOR -> if (editorBoundId != null) showActive() else showGallery()
        }
    }

    companion object {
        const val EXTRA_WIDGET_ID = "widget_id"
        private const val REQ_PICK = 1
    }
}
